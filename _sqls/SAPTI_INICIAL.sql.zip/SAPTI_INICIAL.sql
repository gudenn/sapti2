-- phpMyAdmin SQL Dump
-- version 4.2.11
-- http://www.phpmyadmin.net
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 21-10-2015 a las 13:14:34
-- Versión del servidor: 5.6.21
-- Versión de PHP: 5.6.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de datos: `sapti`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `administrador`
--

DROP TABLE IF EXISTS `administrador`;
CREATE TABLE IF NOT EXISTS `administrador` (
`id` int(11) NOT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `estado` varchar(2) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `administrador`
--

INSERT INTO `administrador` (`id`, `usuario_id`, `estado`) VALUES
(1, 1, 'AC');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `apoyo`
--

DROP TABLE IF EXISTS `apoyo`;
CREATE TABLE IF NOT EXISTS `apoyo` (
`id` int(11) NOT NULL,
  `area_id` int(11) DEFAULT NULL,
  `sub_area_id` int(11) NOT NULL,
  `docente_id` int(11) DEFAULT NULL,
  `estado` varchar(2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `area`
--

DROP TABLE IF EXISTS `area`;
CREATE TABLE IF NOT EXISTS `area` (
`id` int(11) NOT NULL,
  `nombre` varchar(45) DEFAULT NULL,
  `descripcion` varchar(45) DEFAULT NULL,
  `estado` varchar(2) DEFAULT NULL COMMENT 'Activo sera AC, No activo NC, Eliminado DE'
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `area`
--

INSERT INTO `area` (`id`, `nombre`, `descripcion`, `estado`) VALUES
(1, 'Ingeniería de Software', 'Ingeniería de Software', 'AC'),
(2, 'Programación Web', 'Programación Web Descripción', 'AC');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `automatico`
--

DROP TABLE IF EXISTS `automatico`;
CREATE TABLE IF NOT EXISTS `automatico` (
`id` int(11) NOT NULL,
  `docente_id` int(11) DEFAULT NULL,
  `area_id` int(11) DEFAULT NULL,
  `valor` int(11) DEFAULT NULL,
  `numero_aceptados` int(11) DEFAULT NULL,
  `estado` varchar(2) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=1017 DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `automatico`
--

INSERT INTO `automatico` (`id`, `docente_id`, `area_id`, `valor`, `numero_aceptados`, `estado`) VALUES
(890, 1, 0, 50, 0, 'AC'),
(891, 2, 0, 50, 0, 'AC'),
(892, 3, 0, 50, 0, 'AC'),
(893, 4, 0, 50, 0, 'AC'),
(894, 5, 0, 50, 0, 'AC'),
(895, 6, 0, 50, 0, 'AC'),
(896, 7, 0, 50, 0, 'AC'),
(897, 8, 0, 50, 0, 'AC'),
(898, 9, 0, 50, 0, 'AC'),
(899, 10, 0, 50, 0, 'AC'),
(900, 11, 0, 50, 0, 'AC'),
(901, 12, 0, 50, 0, 'AC'),
(902, 13, 0, 50, 0, 'AC'),
(903, 14, 0, 50, 0, 'AC'),
(904, 15, 0, 50, 0, 'AC'),
(905, 16, 0, 50, 0, 'AC'),
(906, 17, 0, 50, 0, 'AC'),
(907, 18, 0, 50, 0, 'AC'),
(908, 19, 0, 50, 0, 'AC'),
(909, 20, 0, 50, 0, 'AC'),
(910, 21, 0, 50, 0, 'AC'),
(911, 22, 0, 50, 0, 'AC'),
(912, 23, 0, 50, 0, 'AC'),
(913, 24, 0, 50, 0, 'AC'),
(914, 25, 0, 50, 0, 'AC'),
(915, 26, 0, 50, 0, 'AC'),
(916, 27, 0, 50, 0, 'AC'),
(917, 28, 0, 50, 0, 'AC'),
(918, 29, 0, 50, 0, 'AC'),
(919, 30, 0, 50, 0, 'AC'),
(920, 31, 0, 50, 0, 'AC'),
(921, 32, 0, 50, 0, 'AC'),
(922, 33, 0, 50, 0, 'AC'),
(923, 34, 0, 50, 0, 'AC'),
(924, 35, 0, 50, 0, 'AC'),
(925, 36, 0, 50, 0, 'AC'),
(926, 37, 0, 50, 0, 'AC'),
(927, 38, 0, 50, 0, 'AC'),
(928, 39, 0, 50, 0, 'AC'),
(929, 40, 0, 50, 0, 'AC'),
(930, 41, 0, 50, 0, 'AC'),
(931, 42, 0, 50, 0, 'AC'),
(932, 43, 0, 50, 0, 'AC'),
(933, 44, 0, 50, 0, 'AC'),
(934, 45, 0, 50, 0, 'AC'),
(935, 46, 0, 50, 0, 'AC'),
(936, 47, 0, 50, 0, 'AC'),
(937, 48, 0, 50, 0, 'AC'),
(938, 49, 0, 50, 0, 'AC'),
(939, 50, 0, 50, 0, 'AC'),
(940, 51, 0, 50, 0, 'AC'),
(941, 52, 0, 50, 0, 'AC'),
(942, 53, 0, 50, 0, 'AC'),
(943, 54, 0, 50, 0, 'AC'),
(944, 55, 0, 50, 0, 'AC'),
(945, 56, 0, 50, 0, 'AC'),
(946, 57, 0, 50, 0, 'AC'),
(947, 58, 0, 50, 0, 'AC'),
(948, 59, 0, 50, 0, 'AC'),
(949, 60, 0, 50, 0, 'AC'),
(950, 61, 0, 50, 0, 'AC'),
(951, 62, 0, 50, 0, 'AC'),
(952, 63, 0, 50, 0, 'AC'),
(953, 64, 0, 50, 0, 'AC'),
(954, 65, 0, 50, 0, 'AC'),
(955, 66, 0, 50, 0, 'AC'),
(956, 67, 0, 50, 0, 'AC'),
(957, 68, 0, 50, 0, 'AC'),
(958, 69, 0, 50, 0, 'AC');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `avance`
--

DROP TABLE IF EXISTS `avance`;
CREATE TABLE IF NOT EXISTS `avance` (
`id` int(11) NOT NULL,
  `proyecto_id` int(11) DEFAULT NULL,
  `fecha_avance` date DEFAULT NULL,
  `detalle` varchar(1500) DEFAULT NULL,
  `porcentaje` int(11) DEFAULT NULL,
  `directorio` varchar(45) DEFAULT NULL,
  `descripcion` text,
  `estado_avance` varchar(2) DEFAULT NULL COMMENT 'estado 1 creado (CR), estado 2 visto (VI), estado 3 aprobado (AP)',
  `estado` varchar(2) DEFAULT NULL COMMENT 'Activo sera AC, No activo NC, Eliminado DE'
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `avance`
--

INSERT INTO `avance` (`id`, `proyecto_id`, `fecha_avance`, `detalle`, `porcentaje`, `directorio`, `descripcion`, `estado_avance`, `estado`) VALUES
(1, 40, '2015-10-11', NULL, 21, 'avance1444585210', '&lt;p&gt;Lic. estoy subiendo el perfil para su revision&lt;/p&gt;', 'CR', 'AC'),
(2, 40, '2015-10-11', NULL, 100, 'avance1444586000', '&lt;p&gt;Envio datos de mi correo&lt;/p&gt;', 'VI', 'AC'),
(3, 40, '2015-10-11', NULL, 29, 'avance1444586037', '&lt;p&gt;Vesrion final adjunto el documento&lt;/p&gt;', 'VI', 'AC'),
(4, 40, '2015-10-11', NULL, 100, 'avance1444587946', '&lt;p&gt;Version Final V&lt;/p&gt;', 'CO', 'AC'),
(5, 43, '2015-11-01', NULL, 50, 'avance1446409143', '&lt;p&gt;Marco teorico completado&lt;/p&gt;', 'CO', 'AC'),
(6, 43, '2015-11-01', NULL, 50, 'avance1446409312', '&lt;p&gt;50% de avance&amp;nbsp;&lt;/p&gt;', 'CR', 'AC'),
(7, 43, '2015-11-01', NULL, 100, 'avance1446409458', '&lt;p&gt;Proyecto final completado&lt;/p&gt;', 'CO', 'AC'),
(8, 44, '2015-10-21', NULL, 48, 'avance1445387034', '&lt;p&gt;zsaewfawefa &amp;nbsp;awfawef awf&lt;/p&gt;', 'CR', 'AC'),
(9, 44, '2015-10-21', NULL, 63, 'avance1445387052', '&lt;p&gt;afwef awef awfawef af&lt;/p&gt;', 'CO', 'AC'),
(10, 44, '2015-10-21', NULL, 63, 'avance1445387184', '&lt;p&gt;zfvzs se sf zsfzes f&lt;/p&gt;', 'VI', 'AC');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `avance_objetivo_especifico`
--

DROP TABLE IF EXISTS `avance_objetivo_especifico`;
CREATE TABLE IF NOT EXISTS `avance_objetivo_especifico` (
`id` int(11) NOT NULL,
  `avance_id` int(11) NOT NULL,
  `objetivo_especifico_id` int(11) NOT NULL,
  `porcentaje_avance` int(11) DEFAULT NULL,
  `estado_avance` varchar(2) DEFAULT NULL,
  `estado` varchar(2) DEFAULT NULL COMMENT 'Activo sera AC, No activo NC, Eliminado DE'
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `avance_objetivo_especifico`
--

INSERT INTO `avance_objetivo_especifico` (`id`, `avance_id`, `objetivo_especifico_id`, `porcentaje_avance`, `estado_avance`, `estado`) VALUES
(1, 5, 14, 100, 'CR', 'AC'),
(2, 6, 14, 100, 'CR', 'AC'),
(3, 6, 15, 56, 'CR', 'AC'),
(4, 5, 15, 56, 'CR', 'AC'),
(5, 7, 14, 100, 'CR', 'AC'),
(6, 7, 15, 100, 'CR', 'AC'),
(7, 7, 16, 100, 'CR', 'AC');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `bitacora`
--

DROP TABLE IF EXISTS `bitacora`;
CREATE TABLE IF NOT EXISTS `bitacora` (
`id` int(11) NOT NULL,
  `operacion` varchar(10) DEFAULT NULL,
  `host` varchar(30) NOT NULL,
  `modificado` datetime DEFAULT NULL,
  `tabla` varchar(40) NOT NULL,
  `tupla_antes` varchar(1000) DEFAULT NULL,
  `tupla_despues` varchar(1000) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `bitacora`
--

INSERT INTO `bitacora` (`id`, `operacion`, `host`, `modificado`, `tabla`, `tupla_antes`, `tupla_despues`) VALUES
(2, 'INSERTAR', 'localhost', '2015-09-08 23:57:09', 'USUARIO', '', '94 Alberto Buddy Coal  tarubazu@hotmail.com 2015-09-10 200015'),
(3, 'INSERTAR', 'localhost', '2015-09-08 23:57:09', 'PROYECTO', '', '39    0000-00-00 PE IN'),
(4, 'INSERTAR', 'localhost', '2015-10-10 13:19:14', 'USUARIO', '', '95 Carlos Medina Medina  tarubazu@hotmail.com 2015-10-21 2000125'),
(5, 'INSERTAR', 'localhost', '2015-10-11 13:33:00', 'USUARIO', '', '96 Alberto Gutierres Gutierres  guyencu@gmail.com 1989-10-19 salavi'),
(6, 'INSERTAR', 'localhost', '2015-10-11 13:33:00', 'PROYECTO', '', '40    0000-00-00 PE IN'),
(7, 'INSERTAR', 'localhost', '2015-10-11 15:38:50', 'USUARIO', '', '97 Richiard Poul Poul  guyencu-buyer@gmail.com 1994-10-12 200017'),
(8, 'INSERTAR', 'localhost', '2015-10-11 15:38:50', 'PROYECTO', '', '41    0000-00-00 PE IN'),
(9, 'INSERTAR', 'localhost', '2015-10-11 15:44:11', 'USUARIO', '', '98 Luis Cardozo Cardozo  um.mary@gmail.com 1986-10-16 200018'),
(10, 'INSERTAR', 'localhost', '2015-10-11 15:44:11', 'PROYECTO', '', '42    0000-00-00 PE IN'),
(11, 'MODIFICAR', 'localhost', '2015-10-11 15:50:32', 'USUARIO', '96 Alberto Gutierres Gutierres  guyencu@gmail.com 1989-10-19 salavi', '96 Pepito Perez Garnica  guyencu@gmail.com 1989-10-19 salavi'),
(12, 'MODIFICAR', 'localhost', '2015-10-11 15:59:48', 'PROYECTO', '40    0000-00-00 PE IN', '40    0000-00-00 PE VB'),
(13, 'MODIFICAR', 'localhost', '2015-10-11 16:02:45', 'PROYECTO', '40    0000-00-00 PE VB', '40 Desarrollo aplicaciones mobiles O1 Perfil de prueba 2015-10-11 PE PD'),
(14, 'MODIFICAR', 'localhost', '2015-10-11 16:02:46', 'PROYECTO', '40 Desarrollo aplicaciones mobiles O1 Perfil de prueba 2015-10-11 PE PD', '40 Desarrollo aplicaciones mobiles O1 Perfil de prueba 2015-10-11 PE PD'),
(15, 'MODIFICAR', 'localhost', '2015-10-11 16:02:46', 'PROYECTO', '40 Desarrollo aplicaciones mobiles O1 Perfil de prueba 2015-10-11 PE PD', '40 Desarrollo aplicaciones mobiles O1 Perfil de prueba 2015-10-11 PE PD'),
(16, 'MODIFICAR', 'localhost', '2015-10-11 16:02:46', 'USUARIO', '96 Pepito Perez Garnica  guyencu@gmail.com 1989-10-19 salavi', '96 Pepito Perez Garnica 4444 guyencu@gmail.com 1989-10-19 salavi'),
(17, 'INSERTAR', 'localhost', '2015-10-11 16:05:10', 'PROYECTO', '', '43 Desarrollo aplicaciones mobiles O1 Perfil de prueba 2015-10-11 PR IN'),
(18, 'MODIFICAR', 'localhost', '2015-10-11 16:05:10', 'PROYECTO', '40 Desarrollo aplicaciones mobiles O1 Perfil de prueba 2015-10-11 PE PD', '40 Desarrollo aplicaciones mobiles O1 Perfil de prueba 2015-10-11 PE CO'),
(19, 'MODIFICAR', 'localhost', '2015-11-01 16:15:53', 'PROYECTO', '43 Desarrollo aplicaciones mobiles O1 Perfil de prueba 2015-10-11 PR IN', '43 Desarrollo aplicaciones mobiles O1 Perfil de prueba 0000-00-00 PR IN'),
(20, 'MODIFICAR', 'localhost', '2015-11-01 16:15:53', 'PROYECTO', '39    0000-00-00 PE IN', '39    0000-00-00 PE IN'),
(21, 'MODIFICAR', 'localhost', '2015-11-01 16:15:53', 'PROYECTO', '41    0000-00-00 PE IN', '41    0000-00-00 PE IN'),
(22, 'MODIFICAR', 'localhost', '2015-11-01 16:15:53', 'PROYECTO', '42    0000-00-00 PE IN', '42    0000-00-00 PE IN'),
(23, 'MODIFICAR', 'localhost', '2015-11-01 16:41:09', 'PROYECTO', '43 Desarrollo aplicaciones mobiles O1 Perfil de prueba 0000-00-00 PR IN', '43 Desarrollo aplicaciones mobiles O1 Perfil de prueba 0000-00-00 PR VA'),
(24, 'MODIFICAR', 'localhost', '2015-11-01 17:01:28', 'PROYECTO', '43 Desarrollo aplicaciones mobiles O1 Perfil de prueba 0000-00-00 PR VA', '43 Desarrollo aplicaciones mobiles O1 Perfil de prueba 0000-00-00 PR TA'),
(25, 'MODIFICAR', 'localhost', '2015-11-01 17:20:35', 'PROYECTO', '43 Desarrollo aplicaciones mobiles O1 Perfil de prueba 0000-00-00 PR TA', '43 Desarrollo aplicaciones mobiles O1 Perfil de prueba 0000-00-00 PR TV'),
(27, 'INSERTAR', 'localhost', '2015-10-20 20:19:56', 'USUARIO', '', '100 Avance Acance Acence  guyencu@gmail.com 1989-10-19 200020'),
(28, 'INSERTAR', 'localhost', '2015-10-20 20:19:56', 'PROYECTO', '', '44    0000-00-00 PE IN'),
(29, 'MODIFICAR', 'localhost', '2015-10-20 21:07:20', 'PROYECTO', '44    0000-00-00 PE IN', '44    0000-00-00 PE VB'),
(30, 'MODIFICAR', 'localhost', '2015-10-20 21:13:15', 'PROYECTO', '43 Desarrollo aplicaciones mobiles O1 Perfil de prueba 0000-00-00 PR TV', '43 Desarrollo aplicaciones mobiles O1 Perfil de prueba 0000-00-00 PR LD');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cambio`
--

DROP TABLE IF EXISTS `cambio`;
CREATE TABLE IF NOT EXISTS `cambio` (
`id` int(11) NOT NULL,
  `proyecto_id` int(11) NOT NULL,
  `tipo` varchar(45) DEFAULT NULL COMMENT 'Leve (LE), Total (TO), Proroga (PO)',
  `fecha_cambio` date DEFAULT NULL,
  `estado` varchar(2) DEFAULT NULL COMMENT 'Activo sera AC, No activo NC, Eliminado DE'
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `cambio`
--

INSERT INTO `cambio` (`id`, `proyecto_id`, `tipo`, `fecha_cambio`, `estado`) VALUES
(9, 32, 'LE', '2013-11-10', 'AC'),
(11, 34, 'TO', '2013-11-10', 'AC'),
(12, 40, 'LE', '2013-11-10', 'AC');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `carrera`
--

DROP TABLE IF EXISTS `carrera`;
CREATE TABLE IF NOT EXISTS `carrera` (
`id` int(11) NOT NULL,
  `nombre` varchar(200) DEFAULT NULL,
  `estado` varchar(2) DEFAULT NULL COMMENT 'Activo sera AC, No activo NC, Eliminado DE'
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `carrera`
--

INSERT INTO `carrera` (`id`, `nombre`, `estado`) VALUES
(1, 'Ingenieria de Sistemas', 'AC');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `carta`
--

DROP TABLE IF EXISTS `carta`;
CREATE TABLE IF NOT EXISTS `carta` (
`id` int(11) NOT NULL,
  `proyecto_id` int(11) DEFAULT NULL,
  `modelo_carta_id` int(11) DEFAULT NULL,
  `estado_impresion` varchar(2) DEFAULT NULL COMMENT 'Pendiente (PE), Impreso (IP)',
  `fecha_impresion` date DEFAULT NULL,
  `estado` varchar(2) DEFAULT NULL COMMENT 'Activo sera AC, No activo NC, Eliminado DE'
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `carta`
--

INSERT INTO `carta` (`id`, `proyecto_id`, `modelo_carta_id`, `estado_impresion`, `fecha_impresion`, `estado`) VALUES
(1, 43, 3, 'PE', '0000-00-00', 'AC');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `codigo_grupo`
--

DROP TABLE IF EXISTS `codigo_grupo`;
CREATE TABLE IF NOT EXISTS `codigo_grupo` (
`id` int(11) NOT NULL,
  `nombre` varchar(200) DEFAULT NULL,
  `estado` varchar(2) DEFAULT NULL COMMENT 'Activo sera AC, No activo NC, Eliminado DE'
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `codigo_grupo`
--

INSERT INTO `codigo_grupo` (`id`, `nombre`, `estado`) VALUES
(1, 'Grupo 01', 'AC'),
(2, 'Grupo 6', 'AC');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `configuracion_semestral`
--

DROP TABLE IF EXISTS `configuracion_semestral`;
CREATE TABLE IF NOT EXISTS `configuracion_semestral` (
`id` int(11) NOT NULL,
  `semestre_id` int(11) NOT NULL,
  `nombre` varchar(100) DEFAULT NULL,
  `valor` varchar(300) DEFAULT NULL,
  `estado` varchar(2) DEFAULT NULL COMMENT 'Activo sera AC, No activo NC, Eliminado DE'
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `configuracion_semestral`
--

INSERT INTO `configuracion_semestral` (`id`, `semestre_id`, `nombre`, `valor`, `estado`) VALUES
(5, 1, 'M&aacute;ximo Tutores Activos', '2', 'CR'),
(6, 1, 'M&aacute;ximo Tutor&iacute;as Activas', '5', 'CR'),
(7, 1, 'Lapso de tiempo para el rechazo a ser tribunal hras.', '72', 'CR'),
(8, 1, 'Número mínimo de avances', '3', 'CR'),
(9, 1, 'Director carrera Sistemas', 'Director Sistemas', 'CR'),
(10, 1, 'M&iacute;nimo n&uacute;mero de &aacute;reas asignadas al proyecto', '1', 'CR'),
(11, 1, 'M&iacute;nimo n&uacute;mero de sub &Aacute;reas', '1', 'CR'),
(12, 1, 'M&iacute;nimo de objetivos especificos', '2', 'CR'),
(13, 2, 'M&aacute;ximo Tutores Activos', '2', 'AC'),
(14, 2, 'M&aacute;ximo Tutor&iacute;as Activas', '5', 'AC'),
(15, 2, 'Lapso de tiempo para el rechazo a ser tribunal hras.', '72', 'AC'),
(16, 2, 'Número mínimo de avances', '3', 'AC'),
(17, 2, 'Director carrera Sistemas', 'Director Sistemas', 'AC'),
(18, 2, 'M&iacute;nimo n&uacute;mero de &aacute;reas asignadas al proyecto', '1', 'AC'),
(19, 2, 'M&iacute;nimo n&uacute;mero de sub &Aacute;reas', '1', 'AC'),
(20, 2, 'M&iacute;nimo de objetivos especificos', '2', 'AC'),
(21, 2, 'Cantidad máximo de asignación de tribunales a docentes', '10', 'AC'),
(22, 2, 'Tiempo de espera de revisión de tribunal  (Semanas).', '3', 'AC'),
(23, 2, 'Puntos por &aacute;rea', '100', 'AC'),
(24, 2, 'Puntos por horario', '10', 'AC'),
(25, 2, 'Puntos por no asignado', '50', 'AC'),
(26, 2, 'Puntos menos por ya asignado', '-6', 'AC'),
(27, 2, 'Número máximo de tribunal', '3', 'AC'),
(28, 2, 'Iniciar Horarios', '0', 'AC');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `consejo`
--

DROP TABLE IF EXISTS `consejo`;
CREATE TABLE IF NOT EXISTS `consejo` (
`id` int(11) NOT NULL,
  `usuario_id` int(11) NOT NULL,
  `fecha_inicio` date DEFAULT NULL,
  `fecha_fin` date DEFAULT NULL,
  `activo` varchar(10) DEFAULT NULL,
  `estado` varchar(2) DEFAULT NULL COMMENT 'Activo sera AC, No activo NC, Eliminado DE'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `consejo_estudiante`
--

DROP TABLE IF EXISTS `consejo_estudiante`;
CREATE TABLE IF NOT EXISTS `consejo_estudiante` (
`id` int(11) NOT NULL,
  `codigo` varchar(100) DEFAULT NULL,
  `estado` varchar(2) DEFAULT NULL COMMENT 'Activo sera AC, No activo NC, Eliminado DE'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cronograma`
--

DROP TABLE IF EXISTS `cronograma`;
CREATE TABLE IF NOT EXISTS `cronograma` (
`id` int(11) NOT NULL,
  `semestre_id` int(11) NOT NULL,
  `nombre_evento` varchar(150) DEFAULT NULL,
  `detalle_evento` varchar(300) DEFAULT NULL,
  `fecha_evento` date DEFAULT NULL,
  `estado` varchar(2) DEFAULT NULL COMMENT 'Activo sera AC, No activo NC, Eliminado DE'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `defensa`
--

DROP TABLE IF EXISTS `defensa`;
CREATE TABLE IF NOT EXISTS `defensa` (
`id` int(11) NOT NULL,
  `lugar_id` int(11) NOT NULL,
  `proyecto_id` int(11) NOT NULL,
  `fecha_asignacion` date DEFAULT NULL,
  `hora_asignacion` time DEFAULT NULL,
  `fecha_defensa` date DEFAULT NULL,
  `hora_inicio` varchar(50) DEFAULT NULL,
  `hora_final` varchar(50) DEFAULT NULL,
  `tipo_defensa` varchar(50) DEFAULT NULL,
  `semestre` varchar(45) DEFAULT NULL,
  `estado` varchar(2) DEFAULT NULL COMMENT 'Activo sera AC, No activo NC, Eliminado DE'
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `defensa`
--

INSERT INTO `defensa` (`id`, `lugar_id`, `proyecto_id`, `fecha_asignacion`, `hora_asignacion`, `fecha_defensa`, `hora_inicio`, `hora_final`, `tipo_defensa`, `semestre`, `estado`) VALUES
(1, 1, 43, '2015-10-21', '03:13:15', '2015-10-22', '09:45', '10:15', 'DPU', '', 'AC');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `departamento`
--

DROP TABLE IF EXISTS `departamento`;
CREATE TABLE IF NOT EXISTS `departamento` (
`id` int(11) NOT NULL,
  `institucion_id` int(11) NOT NULL,
  `nombre` varchar(45) DEFAULT NULL,
  `descripcion` varchar(45) DEFAULT NULL,
  `estado` varchar(2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `dia`
--

DROP TABLE IF EXISTS `dia`;
CREATE TABLE IF NOT EXISTS `dia` (
`id` int(11) NOT NULL,
  `nombre` varchar(45) DEFAULT NULL,
  `descripcion` varchar(45) DEFAULT NULL,
  `orden` smallint(6) DEFAULT NULL COMMENT 'el orden de los dias',
  `estado` varchar(2) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `dia`
--

INSERT INTO `dia` (`id`, `nombre`, `descripcion`, `orden`, `estado`) VALUES
(1, 'L', '', 1, 'AC'),
(2, 'M', '', 2, 'AC'),
(3, 'Mi', '', 3, 'AC'),
(4, 'J', '', 4, 'AC'),
(5, 'V', '', 5, 'AC');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `dicta`
--

DROP TABLE IF EXISTS `dicta`;
CREATE TABLE IF NOT EXISTS `dicta` (
`id` int(11) NOT NULL,
  `docente_id` int(11) DEFAULT NULL,
  `materia_id` int(11) DEFAULT NULL,
  `semestre_id` int(11) DEFAULT NULL,
  `codigo_grupo_id` int(11) DEFAULT NULL,
  `estado` varchar(2) DEFAULT NULL COMMENT 'Activo sera AC, No activo NC, Eliminado DE'
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `dicta`
--

INSERT INTO `dicta` (`id`, `docente_id`, `materia_id`, `semestre_id`, `codigo_grupo_id`, `estado`) VALUES
(1, 2, 1, 1, 1, 'CR'),
(2, 7, 2, 1, 1, 'CR'),
(3, 21, 2, 1, 2, 'CR'),
(4, 2, 1, 2, 1, 'AC'),
(5, 7, 2, 2, 1, 'AC'),
(6, 21, 2, 2, 2, 'AC'),
(7, 11, 1, 2, 2, 'AC');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `docente`
--

DROP TABLE IF EXISTS `docente`;
CREATE TABLE IF NOT EXISTS `docente` (
`id` int(11) NOT NULL,
  `usuario_id` int(11) NOT NULL,
  `codigo_sis` varchar(20) DEFAULT NULL,
  `numero_horas` int(11) DEFAULT NULL,
  `configuracion_area` tinyint(1) DEFAULT NULL,
  `configuracion_horario` tinyint(1) DEFAULT NULL,
  `estado` varchar(2) DEFAULT NULL COMMENT 'Activo sera AC, No activo NC, Eliminado DE'
) ENGINE=InnoDB AUTO_INCREMENT=74 DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `docente`
--

INSERT INTO `docente` (`id`, `usuario_id`, `codigo_sis`, `numero_horas`, `configuracion_area`, `configuracion_horario`, `estado`) VALUES
(1, 2, '500001', 0, 0, 0, 'AC'),
(2, 3, '500002', 0, 0, 0, 'AC'),
(3, 4, '500003', 0, 0, 0, 'AC'),
(4, 5, '500004', 0, 0, 0, 'AC'),
(5, 6, '500005', 0, 0, 0, 'AC'),
(6, 7, '500006', 0, 0, 0, 'AC'),
(7, 8, '500007', 0, 0, 0, 'AC'),
(8, 9, '500008', 0, 0, 0, 'AC'),
(9, 10, '500009', 0, 0, 0, 'AC'),
(10, 11, '500010', 0, 0, 0, 'AC'),
(11, 12, '500011', 0, 0, 0, 'AC'),
(12, 13, '500012', 0, 0, 0, 'AC'),
(13, 14, '500013', 0, 0, 0, 'AC'),
(14, 15, '500014', 0, 0, 0, 'AC'),
(15, 16, '500015', 0, 0, 0, 'AC'),
(16, 17, '500016', 0, 0, 0, 'AC'),
(17, 18, '500017', 0, 0, 0, 'AC'),
(18, 19, '500018', 0, 0, 0, 'AC'),
(19, 20, '500019', 0, 0, 0, 'AC'),
(20, 21, '500020', 0, 0, 0, 'AC'),
(21, 22, '500021', 0, 0, 0, 'AC'),
(22, 23, '500022', 0, 0, 0, 'AC'),
(23, 24, '500023', 0, 0, 0, 'AC'),
(24, 25, '500024', 0, 0, 0, 'AC'),
(25, 26, '500025', 0, 0, 0, 'AC'),
(26, 27, '500026', 0, 0, 0, 'AC'),
(27, 28, '500027', 0, 0, 0, 'AC'),
(28, 29, '500028', 0, 0, 0, 'AC'),
(29, 30, '500029', 0, 0, 0, 'AC'),
(30, 31, '500030', 0, 0, 0, 'AC'),
(31, 32, '500031', 0, 0, 0, 'AC'),
(32, 33, '500032', 0, 0, 0, 'AC'),
(33, 34, '500033', 0, 0, 0, 'AC'),
(34, 35, '500034', 0, 0, 0, 'AC'),
(35, 36, '500035', 0, 0, 0, 'AC'),
(36, 37, '500036', 0, 0, 0, 'AC'),
(37, 38, '500037', 0, 0, 0, 'AC'),
(38, 39, '500038', 0, 0, 0, 'AC'),
(39, 40, '500039', 0, 0, 0, 'AC'),
(40, 41, '500040', 0, 0, 0, 'AC'),
(41, 42, '500041', 0, 0, 0, 'AC'),
(42, 43, '500042', 0, 0, 0, 'AC'),
(43, 44, '500043', 0, 0, 0, 'AC'),
(44, 45, '500044', 0, 0, 0, 'AC'),
(45, 46, '500045', 0, 0, 0, 'AC'),
(46, 47, '500046', 0, 0, 0, 'AC'),
(47, 48, '500047', 0, 0, 0, 'AC'),
(48, 49, '500048', 0, 0, 0, 'AC'),
(49, 50, '500049', 0, 0, 0, 'AC'),
(50, 51, '500050', 0, 0, 0, 'AC'),
(51, 52, '500051', 0, 0, 0, 'AC'),
(52, 53, '500052', 0, 0, 0, 'AC'),
(53, 54, '500053', 0, 0, 0, 'AC'),
(54, 55, '500054', 0, 0, 0, 'AC'),
(55, 56, '500055', 0, 0, 0, 'AC'),
(56, 57, '500056', 0, 0, 0, 'AC'),
(57, 58, '500057', 0, 0, 0, 'AC'),
(58, 59, '500058', 0, 0, 0, 'AC'),
(59, 60, '500059', 0, 0, 0, 'AC'),
(60, 61, '500060', 0, 0, 0, 'AC'),
(61, 62, '500061', 0, 0, 0, 'AC'),
(62, 63, '500062', 0, 0, 0, 'AC'),
(63, 64, '500063', 0, 0, 0, 'AC'),
(64, 65, '500064', 0, 0, 0, 'AC'),
(65, 66, '500065', 0, 0, 0, 'AC'),
(66, 67, '500066', 0, 0, 0, 'AC'),
(67, 68, '500067', 0, 0, 0, 'AC'),
(68, 69, '500068', 0, 0, 0, 'AC'),
(69, 70, '500069', 0, 0, 0, 'AC'),
(70, 71, '500070', 0, 0, 0, 'AC'),
(71, 72, '500071', 0, 0, 0, 'AC'),
(72, 73, '500072', 0, 0, 0, 'AC'),
(73, 74, '500073', 0, 0, 0, 'AC');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `estudiante`
--

DROP TABLE IF EXISTS `estudiante`;
CREATE TABLE IF NOT EXISTS `estudiante` (
`id` int(11) NOT NULL,
  `usuario_id` int(11) NOT NULL,
  `codigo_sis` varchar(20) DEFAULT NULL,
  `numero_cambio_leve` tinyint(4) DEFAULT NULL,
  `numero_cambio_total` tinyint(4) DEFAULT NULL,
  `estado` varchar(2) DEFAULT NULL COMMENT 'Activo sera AC, No activo NC, Eliminado DE'
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `estudiante`
--

INSERT INTO `estudiante` (`id`, `usuario_id`, `codigo_sis`, `numero_cambio_leve`, `numero_cambio_total`, `estado`) VALUES
(1, 75, '20008101', 0, 0, 'AC'),
(2, 76, '20008102', 0, 0, 'AC'),
(3, 77, '20008103', 0, 0, 'AC'),
(4, 78, '20008104', 0, 0, 'AC'),
(5, 79, '20008105', 0, 0, 'AC'),
(6, 80, '20008106', 0, 0, 'AC'),
(7, 81, '20008107', 0, 0, 'AC'),
(8, 82, '20008108', 0, 0, 'AC'),
(9, 83, '20008109', 0, 0, 'AC'),
(10, 84, '20008110', 0, 0, 'AC'),
(11, 85, '20008111', 0, 0, 'AC'),
(12, 86, '20008112', 0, 0, 'AC'),
(13, 87, '20008114', 0, 0, 'AC'),
(14, 88, '20008115', 0, 0, 'AC'),
(15, 89, '20008116', 0, 0, 'AC'),
(16, 90, '20008117', 0, 0, 'AC'),
(17, 91, '20008118', 0, 0, 'AC'),
(18, 92, '20008119', 0, 0, 'AC'),
(19, 93, '20008120', 0, 0, 'AC'),
(20, 94, '200015', 0, 0, 'AC'),
(21, 96, '200016', 0, 0, 'AC'),
(22, 97, '200017', 0, 0, 'AC'),
(23, 98, '200018', 0, 0, 'AC'),
(24, 100, '200020', 0, 0, 'AC');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `evaluacion`
--

DROP TABLE IF EXISTS `evaluacion`;
CREATE TABLE IF NOT EXISTS `evaluacion` (
`id` int(11) NOT NULL,
  `evaluacion_1` int(11) DEFAULT NULL,
  `evaluacion_2` int(11) DEFAULT NULL,
  `evaluacion_3` int(11) DEFAULT NULL,
  `promedio` int(11) DEFAULT NULL,
  `rfinal` varchar(45) DEFAULT NULL,
  `estado` varchar(2) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `evaluacion`
--

INSERT INTO `evaluacion` (`id`, `evaluacion_1`, `evaluacion_2`, `evaluacion_3`, `promedio`, `rfinal`, `estado`) VALUES
(1, 0, 0, 0, 0, '', 'CR'),
(2, 0, 0, 0, 0, '', 'CR'),
(3, 0, 0, 0, 0, '', 'CR'),
(4, 0, 0, 0, 0, '', 'CR'),
(5, 0, 0, 0, 0, '', 'CR'),
(6, 0, 0, 0, 0, '', 'CR'),
(7, 0, 0, 0, 0, '', 'CR'),
(8, 0, 0, 0, 0, '', 'CR'),
(9, 0, 0, 0, 0, '', 'CR'),
(10, 0, 0, 0, 0, '', 'CR'),
(11, 0, 0, 0, 0, '', 'CR'),
(12, 0, 0, 0, 0, '', 'CR'),
(13, 0, 0, 0, 0, '', 'CR'),
(14, 0, 0, 0, 0, '', 'CR'),
(15, 0, 0, 0, 0, '', 'CR'),
(16, 0, 0, 0, 0, '', 'CR'),
(17, 0, 0, 0, 0, '', 'CR'),
(18, 0, 0, 0, 0, '', 'CR'),
(19, 0, 0, 0, 0, '', 'CR'),
(20, 0, 0, 0, 0, '', 'CR'),
(21, 60, 60, 60, 60, '', 'CR'),
(22, 0, 0, 0, 0, '', 'CR'),
(23, 0, 0, 0, 0, '', 'CR'),
(24, 0, 0, 0, 0, '', 'AC'),
(25, 0, 0, 0, 0, '', 'AC'),
(26, 0, 0, 0, 0, '', 'AC'),
(27, 0, 0, 0, 0, '', 'AC'),
(28, 0, 0, 0, 0, '', 'AC');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `evento`
--

DROP TABLE IF EXISTS `evento`;
CREATE TABLE IF NOT EXISTS `evento` (
`id` int(11) NOT NULL,
  `dicta_id` int(11) NOT NULL,
  `asunto` varchar(100) DEFAULT NULL,
  `descripcion` varchar(1500) DEFAULT NULL,
  `fecha_evento` date DEFAULT NULL,
  `estado` varchar(2) DEFAULT NULL COMMENT 'Activo sera AC, No activo NC, Eliminado DE'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `fecha_registro`
--

DROP TABLE IF EXISTS `fecha_registro`;
CREATE TABLE IF NOT EXISTS `fecha_registro` (
`id` int(11) NOT NULL,
  `semestre_id` int(100) NOT NULL,
  `fecha_inicio` date DEFAULT NULL,
  `fecha_fin` date DEFAULT NULL,
  `descripcion` varchar(100) DEFAULT NULL,
  `estado` varchar(20) DEFAULT NULL
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `fecha_registro`
--

INSERT INTO `fecha_registro` (`id`, `semestre_id`, `fecha_inicio`, `fecha_fin`, `descripcion`, `estado`) VALUES
(7, 1, '2014-06-02', '2014-06-24', 'Fecha de registro de Perfil', 'AC');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `fororespuesta`
--

DROP TABLE IF EXISTS `fororespuesta`;
CREATE TABLE IF NOT EXISTS `fororespuesta` (
`id` int(11) NOT NULL,
  `forotema_id` int(11) DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `nombre` varchar(100) DEFAULT NULL,
  `descripcion` text,
  `estado` varchar(2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `forotema`
--

DROP TABLE IF EXISTS `forotema`;
CREATE TABLE IF NOT EXISTS `forotema` (
`id` int(11) NOT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `nombre` varchar(100) DEFAULT NULL,
  `descripcion` text,
  `estado` varchar(2) DEFAULT NULL COMMENT 'AB abierto, CE cerrado, NP no publicado'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `grupo`
--

DROP TABLE IF EXISTS `grupo`;
CREATE TABLE IF NOT EXISTS `grupo` (
`id` int(11) NOT NULL,
  `codigo` varchar(40) DEFAULT NULL,
  `descripcion` varchar(300) DEFAULT NULL,
  `estado` varchar(2) DEFAULT NULL COMMENT 'Activo sera AC, No activo NC, Eliminado DE'
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `grupo`
--

INSERT INTO `grupo` (`id`, `codigo`, `descripcion`, `estado`) VALUES
(1, 'SUPER-ADMIN', 'grupo para el super administrador del sistema', 'AC'),
(2, 'ESTUDIANTES', 'estudiantes', 'AC'),
(3, 'DOCENTES', 'docentes', 'AC'),
(4, 'TUTORES', 'tutores', 'AC'),
(5, 'TRIBUNALES', 'tribunales', 'AC'),
(6, 'CONSEJOS', 'consejos', 'AC'),
(7, 'AUTORIDADES', 'autoridades', 'AC');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `helpdesk`
--

DROP TABLE IF EXISTS `helpdesk`;
CREATE TABLE IF NOT EXISTS `helpdesk` (
`id` int(11) NOT NULL,
  `modulo_id` int(11) DEFAULT NULL,
  `codigo` varchar(100) DEFAULT NULL,
  `directorio` varchar(300) DEFAULT NULL,
  `titulo` varchar(300) DEFAULT NULL,
  `descripcion` varchar(500) DEFAULT NULL,
  `keywords` varchar(500) DEFAULT NULL,
  `estado_helpdesk` varchar(2) DEFAULT NULL COMMENT 'Recien creado RC , Editado ED, Aprobado AP',
  `estado` varchar(2) DEFAULT NULL COMMENT 'Activo sera AC, No activo NC, Eliminado DE'
) ENGINE=InnoDB AUTO_INCREMENT=252 DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `helpdesk`
--

INSERT INTO `helpdesk` (`id`, `modulo_id`, `codigo`, `directorio`, `titulo`, `descripcion`, `keywords`, `estado_helpdesk`, `estado`) VALUES
(1, 9, '94fcba4f84335cd9108c542d573a95c1e4286bcf', '/index.php', 'Inicio Sapti', 'ventana principal des sistema', 'sapti,index,ayuda,inicio', 'ED', 'AC'),
(2, 1, 'a53291cd80ef64046912e832a07267d16b1a0f33', '/autoridad/index.php', 'Modulo Administrador', 'Entorno de Trabajo del Administrador', 'sapti,autoridad,index,ayuda', 'ED', 'AC'),
(3, 9, '47a83624c45361d4eb8f3b7cd9a027bdfbf7b552', '/autoridad/login.php', 'Acceso del Administrador', 'Ingreso de Autoridad', 'sapti,autoridad,login,ayuda', 'ED', 'AC'),
(4, 4, 'de1bf9f2bece92f3a3d85dc88b2ef0814fc2ec72', '/autoridad/docente/index.php', 'Administraci&oacute;n de Docente', 'Gesti&oacute;n de docentes registro, reportes y asignaci&oacute;n de materias.', 'sapti,autoridad,docente,index,ayuda', 'ED', 'AC'),
(5, 4, 'fd009ff64ef74de8411d1b9a72866b4e9846fa38', '/autoridad/docente/docente.gestion.php', 'Gesti&oacute;n Docente', 'Buscar ,Eliminar y Editar docente.', 'sapti,autoridad,docente,docente,gestion,ayuda', 'ED', 'AC'),
(6, 7, '72d4803f94107faae9a840541a051b497b725a86', '/autoridad/estudiante/index.php', 'Men&uacute; de Gesti&oacute;n Estudiantes', 'Administraci&oacute;n de Estudiantes en el Sistema', 'sapti,autoridad,estudiante,index,ayuda', 'ED', 'AC'),
(7, 8, '9090c8257ee2569572deccde2e795d469d334d6e', '/autoridad/estudiante/estudiante.gestion.php', 'Estudiante Gesti&oacute;n', 'Lista de Estudiantes', 'sapti,autoridad,estudiante,estudiante,gestion,ayuda', 'ED', 'AC'),
(8, 12, 'd4b0416c95484bf61f038189a4ca10e0fe43781b', '/autoridad/autoridad/index.php', 'Gesti&oacute;n de Autoridades', 'Asignar Director de carrera y Consejeros.', 'sapti,autoridad,autoridad,index,ayuda', 'ED', 'AC'),
(9, 13, 'ea70f5ad90eefbbff627bc4bd5c417d085294552', '/autoridad/autoridad/autoridad.gestion.php', 'Gesti&oacute;n Autoridad', 'Lista de Autoridades designadas.', 'sapti,autoridad,autoridad,autoridad,gestion,ayuda', 'ED', 'AC'),
(10, 13, '9807ae8d98c3a32b800166cee9d63fe003d25193', '/autoridad/autoridad/autoridad.registro.php', 'Asignar Autoridad', 'Lista de usuarios para asignar como autoridad.', 'sapti,autoridad,autoridad,autoridad,registro,ayuda', 'ED', 'AC'),
(11, 11, 'f7882b3c19c1943b252c9798ea16cbc1879777b8', '/autoridad/seguridad/index.php', 'Modulo De Seguridad', 'Gesti&oacute;n de Permisos a Usuarios', 'sapti,autoridad,seguridad,index,ayuda', 'ED', 'AC'),
(12, 11, '880195ae789e31f2f36119439d1cb282aef05e0d', '/autoridad/seguridad/grupo.asignarpermiso.php', 'Gesti&oacute;n De Permisos', 'Otorgar permisos de Acceso a diferentes m&oacute;dulos', 'sapti,autoridad,seguridad,grupo,asignarpermiso,ayuda', 'ED', 'AC'),
(13, 11, '105d7575fdd0ad460a12209e9157a4845ec8056b', '/autoridad/seguridad/grupo.permiso.php', 'Asignaci&oacute;n De Permisos', 'Se muestra una lista de m&oacute;dulos para la asignaci&oacute;n del permiso.', 'sapti,autoridad,seguridad,grupo,permiso,ayuda', 'ED', 'AC'),
(14, 14, 'd74c32f3d091eb063e59f1a08171f95118af8671', '/autoridad/estudiante/reporte/index.php', 'Reportes Estudiantes', 'Generar Reportes Estudiantes en Pdf y Excel', 'sapti,autoridad,estudiante,reporte,index,ayuda', 'ED', 'AC'),
(15, 15, '5823e0be227347f8cafa187b16faa63b9dc50e5a', '/docente/index.php', 'Modulo de Docente', 'Ambiente de trabajo de docente.', 'sapti,docente,index,ayuda', 'ED', 'AC'),
(16, 9, 'a159a0455603a84176824fe57c37748e2f280831', '/docente/login.php', 'Usuario Acceso', 'Ingreso de Usuario al sistema', 'sapti,docente,login,ayuda', 'ED', 'AC'),
(17, 16, '7ef3d2bca5c94a67b201c773307c26e7cadf3f9e', '/consejo/login.php', 'Login Usuario', 'Login y Password de acceso Usuario', 'sapti,consejo,login,ayuda', 'ED', 'AC'),
(18, 15, '0863c1522ea51c4a71b74475f5944912f5ee6acd', '/docente/tutor/index.php', 'Modulo Tutor', 'El modulo tutor este modulo se le presenta a todos los docentes que fueron asignados como tutor', 'sapti,docente,tutor,index,ayuda', 'ED', 'AC'),
(19, 15, '4661cc508cf568c62b0072a027f59e6cd0206391', '/docente/tribunal/index.php', 'Modulo Tribunal', 'Seguimiento y Observacion', 'sapti,docente,tribunal,index,ayuda', 'ED', 'AC'),
(20, 10, 'cc87ea3093339c3934817152f227803cd587d432', '/estudiante/index.php', 'Entorno de Trabajo Estudiante', 'Modulo estudiante', 'sapti,estudiante,index,ayuda', 'ED', 'AC'),
(21, 9, '50fd0ff35ba80c49657b0990f63c351d55f60eb1', '/estudiante/login.php', 'Modulo  Estudiante', 'ventana de inicio de sesi&oacute;n del estudiante.', 'sapti,estudiante,login,ayuda,ingreso', 'ED', 'AC'),
(22, 17, 'a0b27ad422ff85fc5badb829efc382398422e37d', '/estudiante/notificacion/index.php', 'Modulo Gesti&oacute;n de Notificaciones', 'En es te modulo se ven las notificaciones que le llegan al estudiante.', 'sapti,estudiante,notificacion,index,ayuda', 'ED', 'AC'),
(23, 17, '332218468ac55f2b5bbb9499609bf9cb543323d0', '/autoridad/notificacion/index.php', 'Notificaciones', 'Gesti&oacute;n de notificaciones', 'sapti,autoridad,notificacion,index,ayuda', 'ED', 'AC'),
(24, 18, '55b6c7bf579d6fb1a4dda913ee9d0f3ca2f56c34', '/autoridad/configuracion/modelo_carta.gestion.php', 'Gesti&oacute;n de Cartas', 'Lista de cartas y ediciones.', 'sapti,autoridad,configuracion,modelo_carta,gestion,ayuda', 'ED', 'AC'),
(25, 18, 'c22d5fef97d554c7e52970cafafd0b36305e6875', '/autoridad/configuracion/modelo_carta.registro.php', 'Registro Modelos de Cartas.', 'Registro mediante formulario de Modelos de Cartas.', 'sapti,autoridad,configuracion,modelo_carta,registro,ayuda', 'ED', 'AC'),
(26, 5, 'bdb7b1b5981b348bf6c021fb93b59d8648cb8cb8', '/autoridad/pendientes/index.php', 'Gesti&oacute;n de Perfiles', 'Confirmar el registro Perfil.', 'sapti,autoridad,pendientes,index,ayuda', 'ED', 'AC'),
(27, 9, 'fd6beefedf06a3f7c13e12fe63ed8b818d1f1136', '/autoridad/pendientes/pendientes.gestion.php', 'Lista de Perfiles Registrados Pendientes', 'Lista de Perfiles a confirmar.', 'sapti,autoridad,pendientes,pendientes,gestion,ayuda', 'ED', 'AC'),
(28, 9, 'ddfc06f99a548d184395fd75821aedfacafd8584', '/autoridad/reportes/index.php', 'Reportes de Perfil', 'Generar Reportes de Perfil', 'sapti,autoridad,reportes,index,ayuda', 'ED', 'AC'),
(29, 14, 'f1ed1bc37433ec171f2c66e0d34b5eaf469090f3', '/autoridad/reportes/vencido.lista.php', 'Reportes Vencidos', 'Generar Reportes de  Proyectos Vencidos en Pdf y Excel.', 'sapti,autoridad,reportes,vencido,lista,ayuda', 'ED', 'AC'),
(30, 14, '072ddd78f96a02d3f3f112c61aa6b7a2db058501', '/autoridad/reportes/modalidad.php', 'Reporte Modalidad de Proyecto', 'Generar Reporte en Pdf y Excel', 'sapti,autoridad,reportes,modalidad,ayuda', 'ED', 'AC'),
(32, 14, 'bfafd8600775878994784e287a88783132021617', '/autoridad/docente/reporte/index.php', 'Reportes de Docente', 'Generar Reportes en Pdf y excel.', 'sapti,autoridad,docente,reporte,index,ayuda', 'ED', 'AC'),
(33, 14, '2441a72aa6864a73b62ab9606b393006e5f806e9', '/autoridad/docente/reporte/docente.reporte.php', 'Reporte Docente', 'Generar reportes docente.', 'sapti,autoridad,docente,reporte,docente,reporte,ayuda', 'ED', 'AC'),
(34, 14, '0377ab4567a57fef2ee45f089f0d1b5c3dbd1907', '/autoridad/estudiante/reporte/estudiante.reporte.php', 'Reporte Estudiantes.', 'Reporte de estudiantes con el semestre la materia y si aprobado y reprobados.', 'sapti,autoridad,estudiante,reporte,estudiante,reporte,ayuda', 'ED', 'AC'),
(35, 14, '90986323075d2f65ff024d3fde68edd48e61995a', '/autoridad/tutor/reporte/index.php', 'Reportes Tutor', 'Reportes de tutor los Aceptados y rechazados.', 'sapti,autoridad,tutor,reporte,index,ayuda', 'ED', 'AC'),
(40, 14, '5281110e45cc9e5bd64b7d31ecf007ad0e9ebba5', '/autoridad/tutor/reporte/reporte.php', 'Gr&aacute;fico Estad&&Iacute;acute;stico', 'gr&aacute;fico estad&&Iacute;acute;stico de tutor.', 'sapti,autoridad,tutor,reporte,reporte,ayuda', 'ED', 'AC'),
(41, 14, '7817947730dc25f503d0f834119f19c500300923', '/autoridad/usuario/reporte/index.php', 'Reportes de Usuario', 'Generar reportes en pdf y excel.', 'sapti,autoridad,usuario,reporte,index,ayuda', 'ED', 'AC'),
(42, 14, 'e5a52d682ee169bc698a71b901a61f8336319448', '/autoridad/reportes/postergados.php', 'Reportes Postergados', 'Generar Reportes Postergados en Pdf y Excel.', 'sapti,autoridad,reportes,postergados,ayuda', 'ED', 'AC'),
(43, 14, '998f5fc9683d340b913e2313156e230d24d05f06', '/autoridad/reportes/prorroga.php', 'Reportes Prorroga', 'Generar Reportes Prorroga en Pdf y Excel', 'sapti,autoridad,reportes,prorroga,ayuda', 'ED', 'AC'),
(44, 14, '1be31cc0d0bbf1185fa4517b9c741733bbc67fa8', '/autoridad/proyecto/reporte/index.php', 'Reporte De Proyectos Finales', 'Generar en Pdf y Excel.', 'sapti,autoridad,proyecto,reporte,index,ayuda', 'ED', 'AC'),
(45, 14, '3f1934f5bd917153233c4d1e50ffed659cba13bc', '/autoridad/reportes/proceso.php', 'Reportes Proceso', 'Generar Reporte Pdf y Excel.', 'sapti,autoridad,reportes,proceso,ayuda', 'ED', 'AC'),
(46, 14, '23fc91c3be6c2bbb0004291b43864bb5db6fa688', '/autoridad/reportes/defensa.php', 'Reporte Proyectos con Tribunal', 'Generar Reportes en Pdf y Excel', 'sapti,autoridad,reportes,defensa,ayuda', 'ED', 'AC'),
(47, 14, 'c78025d3533457ef4985dc20e43f7cbbb405e437', '/autoridad/proyecto/reporte/reporte.php', 'Reporte Estad&&Iacute;acute;stico', 'Reporte Proyecto', 'sapti,autoridad,proyecto,reporte,reporte,ayuda', 'ED', 'AC'),
(48, 14, '46fc3aaea186f2f36902cd4b0ae2dc9bcfec6954', '/autoridad/reportes/reporte.php', 'Reporte Estad&&Iacute;acute;stico', 'Generar gr&aacute;fico estad&&Iacute;acute;stico', 'sapti,autoridad,reportes,reporte,ayuda', 'ED', 'AC'),
(49, 14, '6aa653b10b35115f849d53e2a1537f29c469a8b5', '/autoridad/estudiante/reporte/reporte.php', 'Reporte estudiante.', 'Generar reporte gr&aacute;fico.', 'sapti,autoridad,estudiante,reporte,reporte,ayuda', 'ED', 'AC'),
(50, 14, '55726b99c9274821b9b45ed552869cd3c7aa8f7d', '/autoridad/reportes/reportemodalidad.php', 'Reporte Estad&&Iacute;acute;stico Modalidad.', 'Generar gr&aacute;fico Estad&&Iacute;acute;stico', 'sapti,autoridad,reportes,reportemodalidad,ayuda', 'ED', 'AC'),
(51, 14, '482397f3456119f58422f75010b2109d531b33de', '/autoridad/reportes/cambio.php', 'Reporte de Cambios de Tema', 'Generar Reporte en Excel Y Pdf', 'sapti,autoridad,reportes,cambio,ayuda', 'ED', 'AC'),
(52, 9, '987e18cdd614a84e051f582e3ea303e03f129d46', '/buscarperfil/buscajax.php', 'Buscador de Perfiles', 'Buscar proyectos.', 'sapti,buscarperfil,buscajax,ayuda', 'ED', 'AC'),
(53, 9, '9ae4ed8a60ee14d8496c3def15490bccad3577b6', '/buscarperfil/perfil.detalle.php', 'Detalle Perfil', 'Detalle Perfil', 'sapti,buscarperfil,perfil,detalle,ayuda', 'ED', 'AC'),
(54, 7, 'f5ca85e26626fbd1e79c8562fe0bbde8ede14f28', '/autoridad/estudiante/estudiante.registro.php', 'Registro estudiante', 'Formulario de registro Estudiante', 'sapti,autoridad,estudiante,estudiante,registro,ayuda', 'ED', 'AC'),
(55, 2, 'ef9c1d0635f4889b716e2e67684e4eae6367b5ca', '/autoridad/configuracion/index.php', 'Modulo de Configuraci&oacute;n', 'Gesti&oacute;n de Configuraci&oacute;n del sistema', 'sapti,autoridad,configuracion,index,ayuda', 'ED', 'AC'),
(56, 2, '6bd9b94ded1353f9db8347305c98ecc3e14e688b', '/autoridad/configuracion/materia.registro.php', 'Registro Materia', 'Formulario de Registro Materia', 'sapti,autoridad,configuracion,materia,registro,ayuda', 'ED', 'AC'),
(57, 2, 'f39f9485043d7b1876b5cbb55999ef15b30027a9', '/autoridad/configuracion/materia.gestion.php', 'Gesti&oacute;n Materia', 'Lista de Materias', 'sapti,autoridad,configuracion,materia,gestion,ayuda', 'ED', 'AC'),
(58, 4, '939d5718df5b86d6e8d3bbb3ef14c8c651ab14ca', '/autoridad/docente/configuracion.dicta.php', 'Asignar Materias', 'Asignaci&oacute;n de materias y grupos a docentes de la carrera de sistemas.', 'sapti,autoridad,docente,configuracion,dicta,ayuda', 'ED', 'AC'),
(59, 19, '0d9ab849f8d43c70801667d3d9086aba269151cb', '/autoridad/tutor/index.php', 'Gesti&oacute;n Tutor', 'Administraci&oacute;n de Tutores', 'sapti,autoridad,tutor,index,ayuda', 'ED', 'AC'),
(60, 7, '2ac2e4d9eae4dc5af9ff69f9aae2e9a55fe3a38a', '/autoridad/estudiante/estudiante.asignartutor.php', 'Lista de Estudiantes', 'Asignar tutor a los estudiantes que se muestran en la lista.', 'sapti,autoridad,estudiante,estudiante,asignartutor,ayuda', 'ED', 'AC'),
(61, 19, '011fdd0e8c17eda4feebdd6666f2a4e3d593dee6', '/autoridad/tutor/tutor.gestion.php', 'Lista de Tutores del Estudiante', 'Tutores del estudiante.', 'sapti,autoridad,tutor,tutor,gestion,ayuda', 'ED', 'AC'),
(62, 19, 'c7d86346bce7bf4c1927c3ba2810dd35114ae945', '/autoridad/tutor/tutor.asignar.php', 'Lista de Tutores Disponibles', 'Se muestra la lista de tutores a Designar.', 'sapti,autoridad,tutor,tutor,asignar,ayuda', 'ED', 'AC'),
(63, 17, '3e34997eb302e592814d66ae8ce7dba0ef43c9a4', '/docente/notificacion/notificacion.gestion.php', 'Lista de Notificaciones.', 'notificaciones pendientes', 'sapti,docente,notificacion,notificacion,gestion,ayuda', 'ED', 'AC'),
(64, 17, '8964069943089146e7c1728befe9e7f3b0965392', '/docente/notificacion/notificacion.detalle.php', 'Detalle de la Notificacion', 'Ver en detalle la notificacion', 'sapti,docente,notificacion,notificacion,detalle,ayuda', 'ED', 'AC'),
(65, 17, '8d09192b9a23760864bf2fb3fd44312aa4807224', '/docente/notificacion/index.php', 'Notificaciones y Mensajes', 'El docente recibe notificaciones y mensajes del estudiante .', 'sapti,docente,notificacion,index,ayuda', 'ED', 'AC'),
(66, 15, 'c0676df355d66971391f6fff0b7145a839a76d79', '/docente/tutor/perfil.estudiante.lista.php', 'Visto Bueno a un Proyecto', 'Aqui se realiza el visto bueno al estudiante .', 'sapti,docente,tutor,perfil,estudiante,lista,ayuda', 'ED', 'AC'),
(67, 15, '9d27a580ff65c5f32766e59397b333ddf08ca479', '/docente/tutor/perfil.vistobueno.php', 'Grabar el visto bueno', 'Grabamos el visto bueno al estudiante.', 'sapti,docente,tutor,perfil,vistobueno,ayuda', 'ED', 'AC'),
(68, 15, 'a470d115e700bb882b924c97d78a4c0dddf3a6f9', '/docente/tutor/perfil.vistobueno.lista.php', 'Lista de Estudiante.', 'Se muestra la lista de estudiantes con vistos buenos.', 'sapti,docente,tutor,perfil,vistobueno,lista,ayuda', 'ED', 'AC'),
(69, 17, '98ac3bfbb5536a4d44de828e205700fff0c1b676', '/estudiante/notificacion/notificacion.gestion.php', 'Archivo de Notificaciones Pendientes', 'Se muestran todas las notificaciones en una tabla', 'sapti,estudiante,notificacion,notificacion,gestion,ayuda', 'ED', 'AC'),
(70, 15, 'b25a956a376731d3be847523c10cb300e3945e57', '/docente/index.materias.php', 'Modulo Materias Asignadas', 'Tenemos las materias y grupos asignados al docente.', 'sapti,docente,index,materias,ayuda', 'ED', 'AC'),
(71, 15, 'fbe5b6cba52abc318efb47b870a4bb48734f76fa', '/docente/index.proyecto-final.php', 'Modulo Docente', 'Entorno de Trabajo Docente.', 'sapti,docente,index,proyecto-final,ayuda', 'ED', 'AC'),
(72, 15, 'a141cadcf555f8643c383baf4fbcb18bd4d48ec8', '/docente/estudiante/estudiante.lista.php', 'Modulo lista de Estudiantes.', 'Aqu&&Iacute;acute; se muestra la lista de Estudiantes inscritos con el docente.', 'sapti,docente,estudiante,estudiante,lista,ayuda', 'ED', 'AC'),
(73, 15, 'd6e41f5c5863c5d6747733792376ac4fe3cc4de8', '/docente/estudiante/estudiante.vistobueno.php', 'Visto Bueno', 'Tenemos una lista de estudiantes inscritos .', 'sapti,docente,estudiante,estudiante,vistobueno,ayuda', 'ED', 'AC'),
(74, 15, '67dac099db4a64184ec01104ecd739cbf023296d', '/docente/estudiante/vistobueno.php', 'Grabar Visto Bueno', 'Registro del visto bueno.', 'sapti,docente,estudiante,vistobueno,ayuda', 'ED', 'AC'),
(75, 10, '70c76639ec2458302f195247aa6362a3212582b3', '/estudiante/proyecto/proyecto.registro.php', 'Registro Perfil', 'Formulario de Registro de Proyecto', 'sapti,estudiante,proyecto,proyecto,registro,ayuda', 'ED', 'AC'),
(76, 9, 'cf2ae167693aabff7a6a0c1351ba82819bf0adf1', '/autoridad/configuracion/cerrarsemestre.php', 'Modulo de Cierre de Semestre', 'Cerrar Semestre Actual', 'sapti,autoridad,configuracion,cerrarsemestre,ayuda', 'ED', 'AC'),
(77, 2, '29ba8bc9ec04e71450775c9f76a5c22a871897a0', '/autoridad/configuracion/semestre.registro.php', 'Registro de Semestre', 'Registro mediante formulario de Semestre.', 'sapti,autoridad,configuracion,semestre,registro,ayuda', 'ED', 'AC'),
(78, 2, '04076b87cc07dc7f7f30e823dd54ad3e818dd5f9', '/autoridad/configuracion/semestre.gestion.php', 'Gesti&oacute;n de Semestre', 'Lista de Semestres', 'sapti,autoridad,configuracion,semestre,gestion,ayuda', 'ED', 'AC'),
(79, 15, '8453e8bdd2102d4cc272a1dfb102b32c5ed3c68b', '/docente/estudiante/inscripcion.estudiante-cvs.php', 'Inscripci&oacute;n del Estudiante Mediante Cvs', 'Registro mediante Cvs', 'sapti,docente,estudiante,inscripcion,estudiante-cvs,ayuda', 'ED', 'AC'),
(81, 15, 'bebfa6dc8e6338d7ab2def6b617f329209765db3', '/docente/estudiante/estudiante.lista.vistobueno.php', 'Lista con Visto bueno', 'Se muestra la lista de Estudiantes.', 'sapti,docente,estudiante,estudiante,lista,vistobueno,ayuda', 'ED', 'AC'),
(82, 15, 'e21d1dcf1d8a325c45cd5a7c9ffa6158f842aaab', '/docente/tutor/seguimiento.lista.php', 'Seguimiento', 'Seguimiento de avance', 'sapti,docente,tutor,seguimiento,lista,ayuda', 'ED', 'AC'),
(83, 15, 'c1e96b2fb236788482b74c2573bc8141a6a93abe', '/docente/tutor/estudiante.lista.php', 'Visto Bueno', 'lista de estudiantes a los cuales se les dara visto bueno', 'sapti,docente,tutor,estudiante,lista,ayuda', 'ED', 'AC'),
(84, 15, '0d879d3bb023439d6aa1463d27596ce840d08a38', '/docente/tutor/proyecto.vistobueno.php', 'Lista Visto Bueno', 'Mostramos la lista de visto bueno', 'sapti,docente,tutor,proyecto,vistobueno,ayuda', 'ED', 'AC'),
(85, 20, '35b9d0564c67e23e3dfb3ead8c325327e3cc818d', '/autoridad/usuario/index.php', 'Modulo Usuarios', 'Gesti&oacute;n de Usuarios y Grupos', 'sapti,autoridad,usuario,index,ayuda', 'ED', 'AC'),
(86, 20, '619e44cfbd29a494113376c497a49e09e67b28be', '/autoridad/usuario/usuario.gestion.php', 'Gesti&oacute;n de Usuario', 'Lista de usuarios registrados en el sistema', 'sapti,autoridad,usuario,usuario,gestion,ayuda', 'ED', 'AC'),
(87, 13, '30a46770fee764fbe57a1aca760a0fadff9fb781', '/autoridad/autoridad/consejo.gestion.php', 'Gesti&oacute;n Consejo', 'Agregar a Usuarios como concejo de la Universidad.', 'sapti,autoridad,autoridad,consejo,gestion,ayuda', 'ED', 'AC'),
(88, 13, '05516407da5ddc595d48e5948a6d61b16fd4170f', '/autoridad/autoridad/consejo.registro.php', 'Agregar Consejero', 'Designar a un Usuario como consejo.', 'sapti,autoridad,autoridad,consejo,registro,ayuda', 'ED', 'AC'),
(89, 16, '2038d019e8ab19acf5092ba0b6b8adb983aed5d7', '/consejo/lista.estudiante.php', 'Asignar Tribunales', 'Lista de Estudiantes para asignar tribunales', 'sapti,consejo,lista,estudiante,ayuda', 'ED', 'AC'),
(91, 7, 'd6b0dc72a2a44307eefda4df4d2bd3b31aaf8de8', '/autoridad/estudiante/estudiante.asignarproyecto.php', 'Registro Perfil.', 'Registro de formulario de perfil.', 'sapti,autoridad,estudiante,estudiante,asignarproyecto,ayuda', 'ED', 'AC'),
(92, 15, '768ffe8ad26b87a3f46c051270f028177d5a3732', '/docente/tutor/perfil.seguimiento.lista.php', 'Modulo De seguimiento de Tutor', 'Este modulo permite al tutor hacer seguimiento respecto al proyecto de tesis del estudiante.', 'sapti,docente,tutor,perfil,seguimiento,lista,ayuda', 'ED', 'AC'),
(93, 10, 'a3cf6376cf830da576745f19296952b89f4e914d', '/estudiante/proyecto-final/index.php', 'Proyecto', 'Entorno de trabajo del estudiante', 'sapti,estudiante,proyecto-final,index,ayuda', 'ED', 'AC'),
(94, 15, 'c1694c6b7525dce032c394004a6b3e921319185d', '/docente/tutor/revision.corregido.lista.php', 'Correcciones', 'lista de correcciones realizadas por el estudiante.', 'sapti,docente,tutor,revision,corregido,lista,ayuda', 'ED', 'AC'),
(95, 15, '12e90a2dc66b790fb8b8429043e1f1af050b3850', '/docente/tutor/revision.lista.php', 'Seguimiento Estudiante', 'Aqu&&Iacute;acute; se puede ver la lista de avances del estudiante.', 'sapti,docente,tutor,revision,lista,ayuda', 'ED', 'AC'),
(96, 9, '49ab9fe589fab10b3579ecf17ccbe5362a80cdf6', '/cronograma/index.php', 'Calendario Sapti', 'Eventos Sapti', 'sapti,cronograma,index,ayuda', 'ED', 'AC'),
(97, 2, '67ec7440e03dc6acc8c4badd32efd6ad2bd5c2b5', '/autoridad/configuracion/cronograma.gestion.php', 'Gesti&oacute;n Cronograma', 'Lista de eventos del sistema.', 'sapti,autoridad,configuracion,cronograma,gestion,ayuda', 'ED', 'AC'),
(98, 2, 'f65bf41ee21a9a472dcb186aaebca4c4a050ec47', '/autoridad/configuracion/cronograma.registro.php', 'Registro de Evento', 'Formulario de registro de un evento para el sistema', 'sapti,autoridad,configuracion,cronograma,registro,ayuda', 'ED', 'AC'),
(99, 15, '08b251400c401d41f84cda8433ef1959026ab106', '/docente/calendario/evento.registro.php', 'Registro de un Evento', 'Creando un evento', 'sapti,docente,calendario,evento,registro,ayuda', 'ED', 'AC'),
(100, 15, '5c135a68dc5ca11248124e8abe5c5a975e9c7d4a', '/docente/calendario/calendario.evento.php', 'Calendario de Eventos', 'Se muestra los eventos pr&oacute;ximos.', 'sapti,docente,calendario,calendario,evento,ayuda', 'ED', 'AC'),
(101, 4, '878b6f2c2d21c34f4994a273bca57f8c6e8aca18', '/autoridad/docente/docente.registro.cvs.php', 'Registro de Docente archivo cvs.', 'Registro de docentes por medio de un archivo Cvs.', 'sapti,autoridad,docente,docente,registro,cvs,ayuda', 'ED', 'AC'),
(102, 9, '02b87e74418195f083c8cf1084ed3c52848a3d2d', '/descripcion.php', 'Descripci&oacute;n de la Carrera de Ingenier&&Iacute;acute;a de Sistemas', 'Detalle sobre la Carrera de Ingenier&&Iacute;acute;a de Sistemas', 'sapti,descripcion,ayuda', 'ED', 'AC'),
(107, 15, '9b6ea272f55e50abb5058fafb1871e7f0d35a46a', '/docente/revision/revision.corregido.lista.php', 'Lista de Correcciones y Avances', 'Aqu&&Iacute;acute; se realiza las correcciones seg&uacute;n el avance del estudiante.', 'sapti,docente,revision,revision,corregido,lista,ayuda', 'ED', 'AC'),
(108, 15, '3bd7a9d92d2f19a2cdae31c5467b4f636d58e9a3', '/docente/revision/revision.lista.php', 'Modulo Seguimiento Estudiante.', 'Aqu&&Iacute;acute; se realiza el seguimiento correspondiente.', 'sapti,docente,revision,revision,lista,ayuda', 'ED', 'AC'),
(109, 15, 'bc602d97d5ee39619d1792c1f45a206d1de7a173', '/docente/evaluacion/proyecto.evaluacion.php', 'Modulo Evaluaciones', 'Registro de las evaluaciones.', 'sapti,docente,evaluacion,proyecto,evaluacion,ayuda', 'ED', 'AC'),
(110, 10, '376e2eccb194324e2db86af547cf89e6c5494ddd', '/estudiante/proyecto-final/avance.registro.php', 'Enviar Avance', 'Envi&oacute; de avances del proyecto del estudiante.', 'sapti,estudiante,proyecto-final,avance,registro,ayuda', 'ED', 'AC'),
(111, 10, 'f002a258c6345f3cc1680bd437a611b2ebdba895', '/estudiante/proyecto-final/avance.gestion.php', 'Archivo de Avances', 'Los archivos de avance es donde se muestran los avances que realiza el estudiante.', 'sapti,estudiante,proyecto-final,avance,gestion,ayuda', 'ED', 'AC'),
(112, 15, '5bb560f2dbe9b2bdce56083dd60c738e34ad181f', '/docente/revision/avance.detalle.php', 'Detalle de Avance', 'Se muestra en detalle el avance del Estudiante.', 'sapti,docente,revision,avance,detalle,ayuda', 'ED', 'AC'),
(113, 10, 'a7e2f236d3dc3cf4f959601a30b83b982cac0311', '/estudiante/proyecto-final/revision.gestion.php', 'Archivo de correcciones', 'Los archivos pendientes para la correcion.', 'sapti,estudiante,proyecto-final,revision,gestion,ayuda', 'ED', 'AC'),
(114, 4, 'fead08d9eba44f0503ccc33ee83cd6ea316fedbf', '/autoridad/docente/docente.registro.php', 'Registro Docente', 'Formulario de registro docente.', 'sapti,autoridad,docente,docente,registro,ayuda', 'ED', 'AC'),
(115, 2, 'c8bf91145f3a83281d59fdb983cc593c86bec984', '/autoridad/configuracion/area.registro.php', 'Registro &aacute;rea', 'Registro mediante formulario del &aacute;rea', 'sapti,autoridad,configuracion,area,registro,ayuda', 'ED', 'AC'),
(117, 20, '95a20904e43a20e712ce7aab3789b0bf4ae980ef', '/autoridad/usuario/usuario.asignargrupo.php', 'Asignar Grupo', 'Asignar al Usuario al grupo correspondiente.', 'sapti,autoridad,usuario,usuario,asignargrupo,ayuda', 'ED', 'AC'),
(118, 15, '1949eafd8fe44878f14e27c78319a50b32dbfa2d', '/docente/reportes.sistema.php', 'Reportes del Sistema', 'Ver reportes q se genera en las materias q imparte el docente.', 'sapti,docente,reportes,sistema,ayuda', 'ED', 'AC'),
(119, 15, '4ba0123f093721743295e23124ee1e7d635a9b12', '/docente/evaluacion/estudiante.evaluacion-editar.php', 'Evaluaci&oacute;n de Estudiantes', 'Registro de Evaluaciones e Historial de Notas', 'sapti,docente,evaluacion,estudiante,evaluacion-editar,ayuda', 'ED', 'AC'),
(120, 10, 'cb82997556ac20221a31f528cb3e673c45793fe0', '/estudiante/proyecto-final/observacion.gestion.php', 'Detalle de correcion', 'Ver en detalle las observaciones que hizo el docente.', 'sapti,estudiante,proyecto-final,observacion,gestion,ayuda', 'ED', 'AC'),
(121, 10, '8109173d2d37763a511e686f877b57bca9b4b20a', '/estudiante/proyecto-final/avance.detalle.php', 'Detalle de Avance', 'Mostrando el detalle del avance', 'sapti,estudiante,proyecto-final,avance,detalle,ayuda', 'ED', 'AC'),
(122, 6, 'bf6b08f07561c98c56f3923becc6ac7b4aa3a4a0', '/autoridad/detalle/proyecto.detalle.php', 'Detalle del Proyecto', 'Datos Registrados del Perfil', 'sapti,autoridad,detalle,proyecto,detalle,ayuda', 'ED', 'AC'),
(123, 7, '64d314e187f6ef7d7aa1c99799d97bfe649c0ecd', '/autoridad/estudiante/estudiante.cambiotema.php', 'Lista de Estudiantes', 'Buscamos al estudiante para realizar el camio de tema.', 'sapti,autoridad,estudiante,estudiante,cambiotema,ayuda', 'ED', 'AC'),
(124, 22, 'fb6d9d4ec88abe86297b9948fd07e54ccedaa063', '/autoridad/proyectocambio/proyecto.registro.php', 'Cambio Leve', 'Realizamos los cambios que corresponda.', 'sapti,autoridad,proyectocambio,proyecto,registro,ayuda', 'ED', 'AC'),
(127, 15, 'c40e7f8a9dd480710ead2c012fcda2b8dc63e58f', '/docente/tribunal/estudiante.lista.php', 'Tribunal Visto bueno', 'Dar visto bueno Tribunal', 'sapti,docente,tribunal,estudiante,lista,ayuda', 'ED', 'AC'),
(129, 15, 'fde0bb6417fb92320189f383f172c218bcb82c63', '/docente/tribunal/privada.estudiante.lista.php', 'Revicion y Observaciones', 'Observaciones al la Defensa.', 'sapti,docente,tribunal,privada,estudiante,lista,ayuda', 'ED', 'AC'),
(130, 2, '25b746b1961065f5f300ca95cc193354dcf830f9', '/autoridad/configuracion/lugar.registro.php', 'Registro  Lugar de Defensa de Proyecto Final', 'Formulario de Registro  Lugar de Defensa de Proyecto Final', 'sapti,autoridad,configuracion,lugar,registro,ayuda', 'ED', 'AC'),
(131, 2, '66a505a4d040b8038e3e7f06fa225037d3d42b02', '/autoridad/configuracion/lugar.gestion.php', 'Gesti&oacute;n de Lugar de defensa de proyecto', 'Lista de Lugar de defensa de proyecto', 'sapti,autoridad,configuracion,lugar,gestion,ayuda', 'ED', 'AC'),
(148, 3, '0255c01372e722d2d24f1fc84b3a3b8b50751f18', '/autoridad/helpdesk/index.php', 'Gesti&oacute;n de Temas de Ayuda', 'Edici&oacute;n el linea registros de temas de Ayuda', 'sapti,autoridad,helpdesk,index,ayuda', 'ED', 'AC'),
(149, 3, '55a3a1acd30b1c5117eb01a4a80a5e970d44ff49', '/autoridad/helpdesk/helpdesk.gestion.php', 'Gesti&oacute;n de Ayuda Pendiente', 'Editar, Activar Temas de Ayuda', 'sapti,autoridad,helpdesk,helpdesk,gestion,ayuda', 'ED', 'AC'),
(150, 3, '795aa96d7a57449b544a0c25ea098b5a01b9ca72', '/autoridad/helpdesk/helpdesk.registro.php', 'Registro de Temas de Ayuda', 'Formulario de Registro de Temas de Ayuda', 'sapti,autoridad,helpdesk,helpdesk,registro,ayuda', 'ED', 'AC'),
(151, 6, '305b77a500823f2e2effa7ea70bbcf24592c3bbe', '/autoridad/proyecto/proyecto.registro.php', 'Formulario de Perfil', 'Registro de los datos del Perfil de Proyecto de tesis.', 'sapti,autoridad,proyecto,proyecto,registro,ayuda', 'ED', 'AC'),
(153, 6, '5419ac6fe276894b9747e3cc1ceb8f8299abada1', '/autoridad/proyecto/index.php', 'Modulo Proyecto final.', 'Gesti&oacute;n de Proyectos finales.', 'sapti,autoridad,proyecto,index,ayuda', 'ED', 'AC'),
(154, 19, 'bf16b3a8de2ebd808616ce818de3dbfe7b5d579c', '/autoridad/tutor/tutor.registro.php', 'Registro Tutor', 'Formulario de Registro de tutor', 'sapti,autoridad,tutor,tutor,registro,ayuda', 'ED', 'AC'),
(155, 11, 'a8d37b35d4681d1cd3f7f15a5df23639d33bef6e', '/autoridad/seguridad/grupo.gestion.php', 'Gesti&oacute;n de  Grupos', 'Lista de grupos De Usuarios', 'sapti,autoridad,seguridad,grupo,gestion,ayuda', 'ED', 'AC'),
(156, 11, 'd452fea38ae7cdb12e44561d889ab62200d8baf0', '/autoridad/seguridad/grupo.registro.php', 'Grupo Registro', 'Formulario de registro de un Grupo de usuario.', 'sapti,autoridad,seguridad,grupo,registro,ayuda', 'ED', 'AC'),
(157, 9, 'c4a8f77efbe89ae23dbb2c9267759ff1b026da44', '/autoridad/reprogramacion/index.php', 'Modulo Reprogramaciones', 'Proyectos en Prorroga o postergados,', 'sapti,autoridad,reprogramacion,index,ayuda', 'ED', 'AC'),
(158, 24, 'b8592127da22db476628f3d14caf10d1a137cef4', '/autoridad/reprogramacion/lista.estudiantes.php', 'Gesti&oacute;n de Reprogramacion', 'Re-programar un proyecto  ya sea para postergar o dar prorroga.', 'sapti,autoridad,reprogramacion,lista,estudiantes,ayuda', 'ED', 'AC'),
(159, 6, '40cc1fe93fef6b492f13b7772db4501ac61a8cec', '/autoridad/detalle/index.php', 'Detalle del Proyecto', 'Descripci&oacute;n del detalle del Proyecto.', 'sapti,autoridad,detalle,index,ayuda', 'ED', 'AC'),
(160, 3, '18f8c7e2da1703bd09fa8fc9d5590418e78bce31', '/autoridad/helpdesk/helpdesk.tooltips.php', 'Tooltips Sapti', 'Gesti&oacute;n de Tooltips', 'sapti,autoridad,helpdesk,helpdesk,tooltips,ayuda', 'ED', 'AC'),
(161, 18, '7a07e79febb9670bd0d3ee51e95f97db26de3169', '/autoridad/carta/carta.gestion.php', 'Gesti&oacute;n de Cartas Pendientes', 'Lista de Cartas del sistema para generar.', 'sapti,autoridad,carta,carta,gestion,ayuda', 'ED', 'AC'),
(162, 18, '5fbdad92c47682c8f408825f5b00ce9b9b2ab90f', '/autoridad/carta/index.php', 'Modulo de Cartas', 'Gesti&oacute;n de Cartas', 'sapti,autoridad,carta,index,ayuda', 'ED', 'AC'),
(163, 17, '1e044fea70227cf67093bdb3ec18846412990c87', '/autoridad/notificacion/notificacion.gestion.php', 'Gesti&oacute;n de Notificaciones Pendientes', 'Notificaciones recibidas.', 'sapti,autoridad,notificacion,notificacion,gestion,ayuda', 'ED', 'AC'),
(164, 2, '51895ab6dd0e4b05d7c346dfdb1090df55d7f25d', '/autoridad/configuracion/configuracion_semestral.gestion.php', 'Configuraci&oacute;n Semestre', 'Variables del semestre actual.', 'sapti,autoridad,configuracion,configuracion_semestral,gestion,ayuda', 'ED', 'AC'),
(165, 2, 'cfb9b05cc6d53dd3d149cbc7849eebd59f1393a4', '/autoridad/configuracion/ordenarsemestre.php', 'Modulo Ordenar Semestre', 'Ordenar Semestres', 'sapti,autoridad,configuracion,ordenarsemestre,ayuda', 'ED', 'AC'),
(166, 2, 'e65ba7ece1abd362c9470f4518b6e0f0420fbe45', '/autoridad/configuracion/area.gestion.php', 'Gesti&oacute;n de &aacute;reas', 'Lista de &aacute;reas del', 'sapti,autoridad,configuracion,area,gestion,ayuda', 'ED', 'AC'),
(167, 2, '6a5078e14a30748afd8e812b561366fc50cab809', '/autoridad/configuracion/carrera.gestion.php', 'Gesti&oacute;n de Carreras', 'Lista de Carreras', 'sapti,autoridad,configuracion,carrera,gestion,ayuda', 'ED', 'AC'),
(168, 2, 'f45df5737328f30cb88fd3c562dc758d9ac2897f', '/autoridad/configuracion/carrera.registro.php', 'Registro Carrera', 'Formulario de Registro de Carrera', 'sapti,autoridad,configuracion,carrera,registro,ayuda', 'ED', 'AC'),
(169, 2, '3e317f54f642f01d8cf0d80ad1a975ef7538afb2', '/autoridad/configuracion/institucion.gestion.php', 'Gesti&oacute;n Instituci&oacute;n', 'Lista Instituciones', 'sapti,autoridad,configuracion,institucion,gestion,ayuda', 'ED', 'AC'),
(170, 2, 'e0641227aeba98359ff1c4ef0573c7a3fcab67c4', '/autoridad/configuracion/institucion.registro.php', 'Registro de Instituci&oacute;n', 'Formulario de Registro de Instituci&oacute;n', 'sapti,autoridad,configuracion,institucion,registro,ayuda', 'ED', 'AC'),
(171, 2, 'db162822e6d66bcddeed6bb9f60ed2b2efbca3e1', '/autoridad/configuracion/modalidad.gestion.php', 'Gestiona Modalidades', 'Lista de Modalidad', 'sapti,autoridad,configuracion,modalidad,gestion,ayuda', 'ED', 'AC'),
(172, 2, '6a4c6c9dbf23706c93f5bc6a13e1ba81100c5b20', '/autoridad/configuracion/modalidad.registro.php', 'Registro Modalidad.', 'Formulario de Registro Modalidad.', 'sapti,autoridad,configuracion,modalidad,registro,ayuda', 'ED', 'AC'),
(173, 2, 'd6f3eab6bfe334e9d06a430d35d530145dc7a295', '/autoridad/configuracion/titulo_honorifico.gestion.php', 'Gesti&oacute;n de T&&Iacute;acute;tulos Honor&&Iacute;acute;ficos', 'Lista de T&&Iacute;acute;tulos Honor&&Iacute;acute;ficos', 'sapti,autoridad,configuracion,titulo_honorifico,gestion,ayuda', 'ED', 'AC'),
(174, 2, 'b5905a1b761bd1eeeec2daa7df4336d102b8580a', '/autoridad/configuracion/titulo_honorifico.registro.php', 'Registro Titulo Honorifico', 'Registro mediante formulario Titulo Honorifico', 'sapti,autoridad,configuracion,titulo_honorifico,registro,ayuda', 'ED', 'AC'),
(175, 2, '8d899a503ef6e2e2620f2c36b0aae77780b5573d', '/autoridad/configuracion/codigo_grupo.gestion.php', 'Gesti&oacute;n de Grupos.', 'Lista de grupos registrados.', 'sapti,autoridad,configuracion,codigo_grupo,gestion,ayuda', 'ED', 'AC'),
(176, 2, '45a76fe0f6b8dcd0e27eaad151e2c9ba315be717', '/autoridad/configuracion/codigo_grupo.registro.php', 'Registro Grupo', 'Formulario Registro de Grupo', 'sapti,autoridad,configuracion,codigo_grupo,registro,ayuda', 'ED', 'AC'),
(179, 0, '', '', 'INICIO', 'El inicio del sistema sapti', 'inicio,buscador, fechas de defensa', 'AP', 'AC'),
(184, 15, '4721965cbcfc5a12dab2b6298b772a5118d75bd9', '/docente/configuracion/generar.horario.php', 'Horarios Disponibles', 'Registro de horarios en las que el docente dospone para las defensas si este es tribbunal.', 'sapti,docente,configuracion,generar,horario,ayuda', 'ED', 'AC'),
(185, 15, 'de2d073a4a94e75787c1c9a08845cd941bc39b0a', '/docente/tutor/avance.detalle.php', 'Revicion', 'Aqui se hace la revicion correspondiente al avance del estudiante.', 'sapti,docente,tutor,avance,detalle,ayuda', 'ED', 'AC'),
(186, 15, 'da47a4e687cce3d7e03d0342e2008511360a14a2', '/docente/configuracion/configuracion.php', '&aacute;reas de Especializaci&oacute;n', '&aacute;reas en las que el docente se especializa.', 'sapti,docente,configuracion,configuracion,ayuda', 'AP', 'AC'),
(187, 15, 'c97e0b2d827437b932b84db983c37932e102fcd3', '/docente/calendario/evento.lista.php', 'Edici&oacute;n de Eventos.', 'Se muestra la lista de Eventos .', 'sapti,docente,calendario,evento,lista,ayuda', 'ED', 'AC'),
(188, 15, 'bdcc191245eae6b97ef2140e0c3a28df91758af3', '/docente/tribunal/seguimiento.lista.php', 'Tribunal Lista Estudiantes', 'Se muestra una lista de Estudiantes.', 'sapti,docente,tribunal,seguimiento,lista,ayuda', 'ED', 'AC'),
(189, 16, '7fe0df20e26b7611d63837d64864380a206bca87', '/consejo/reporte.php', 'Reportes Consejo', 'Generar Reportes para Consejo', 'sapti,consejo,reporte,ayuda', 'ED', 'AC'),
(190, 15, '85f62744738ec5981d20fd40ec6ff2abba2a003e', '/docente/tribunal/revision.lista.php', 'Seguimiento al Proyecto', 'Lista de Seguimiento .', 'sapti,docente,tribunal,revision,lista,ayuda', 'ED', 'AC'),
(191, 15, '2f85e65215fccd20b1292bff1844a2823a7abb59', '/docente/tribunal/revision.corregido.lista.php', 'Correcciones', 'Correcciones hechas al proyecto del Estudiante', 'sapti,docente,tribunal,revision,corregido,lista,ayuda', 'ED', 'AC'),
(192, 15, '4e172a4c8535c3b7ef2b777137c1563aa265aae3', '/docente/tribunal/visto.estudiante.lista.php', 'Lista de Vistos buenos.', 'Estudiantes con visto Bueno', 'sapti,docente,tribunal,visto,estudiante,lista,ayuda', 'ED', 'AC'),
(193, 15, '6863ade7173c5c5c2bbf5c211b7361f67f6e655e', '/docente/tribunal/publica.estudiante.lista.php', 'Observaciones y modificaciones', 'Observar y modificar', 'sapti,docente,tribunal,publica,estudiante,lista,ayuda', 'ED', 'AC'),
(194, 25, 'e50ee50a7213bf57237c77981e0f0741ab8c98bc', '/autoridad/reprogramacion/estado.gestion.php', 'Gesti&oacute;n de Reprogramacion', 'Reprogramaciones', 'sapti,autoridad,reprogramacion,estado,gestion,ayuda', 'ED', 'AC'),
(195, 6, '9553d2375b45ef79b98fc8c945ad8fb6ff3bcc62', '/autoridad/detalle/estudiante.detalleproyecto.php', 'Detalle Proyecto', 'Se muestra en detalle el registro del proyecto.', 'sapti,autoridad,detalle,estudiante,detalleproyecto,ayuda', 'ED', 'AC'),
(196, 14, '313336cb08a13eefdd62788e5307c7b20aceda30', '/autoridad/reportes/tribunales.php', 'Reporte de Tribunales', 'Generar reportes en Pdf y Excel', 'sapti,autoridad,reportes,tribunales,ayuda', 'ED', 'AC'),
(197, 2, 'c82d3aa1c8497ea8ed745ca37a66c2344cc8d653', '/autoridad/configuracion/subarea.gestion.php', 'Gesti&oacute;n de Sub-&aacute;reas', 'Lista de Sub-&aacute;reas', 'sapti,autoridad,configuracion,subarea,gestion,ayuda', 'ED', 'AC'),
(198, 2, 'bb7a537d5996a2319a6a1d0675c85e0948fb49aa', '/autoridad/configuracion/subarea.registro.php', 'Registro Sub-&aacute;rea', 'Formulario de Registro Sub-&aacute;rea', 'sapti,autoridad,configuracion,subarea,registro,ayuda', 'ED', 'AC'),
(200, 2, '20302a2ff88779772bfdc73053494955956d9849', '/autoridad/configuracion/cronograma.crear.deleted.php', 'Editar cronograma', 'Modificar datos de Cornograma', 'sapti,autoridad,configuracion,cronograma,crear,deleted,ayuda', 'ED', 'AC'),
(202, 4, '27ba2295f582b3f7eb0a44302df82c28e506ece3', '/autoridad/docente/docente.detalle.php', 'Docente detalle', 'Descripci&oacute;n de los datos', 'sapti,autoridad,docente,docente,detalle,ayuda', 'ED', 'AC'),
(203, 7, 'f8e02cb0731a3924ad909ba7b3f6a9715a755045', '/autoridad/estudiante/estudiante.detalle.php', 'Detalle Estudiante', 'Ver en Estudiante', 'sapti,autoridad,estudiante,estudiante,detalle,ayuda', 'ED', 'AC'),
(204, 17, '3a69858ed959a3f66fd9727da2bb1d27ad511229', '/autoridad/notificacion/notificacion.detalle.php', 'Gesti&oacute;n notificaci&oacute;n', 'Aceptar o rechazar la notificaci&oacute;n.', 'sapti,autoridad,notificacion,notificacion,detalle,ayuda', 'ED', 'AC'),
(211, 4, '5ccba72b37c6944f4ab4053879b3ba0b3f08cb21', '/autoridad/tribunal/index.php', 'Gesti&oacute;n Tribunales', 'Gestionar Tribunales', 'sapti,autoridad,tribunal,index,ayuda', 'ED', 'AC'),
(213, 15, '0f7d3fd1300ece115a72102d195fabf6c8cbf861', '/docente//foro/index.php', 'Foro Docentes', 'Foro de docentes', 'sapti,docente,,foro,index,ayuda', 'ED', 'AC'),
(215, 15, '0d4876a22b60f0829c38a642d900fdda39f10fcd', '/docente//foro/respuesta.gestion.php', 'Respuesta a Temas de los Foros', 'Foros', 'sapti,docente,,foro,respuesta,gestion,ayuda', 'ED', 'AC'),
(220, 15, '7af2bd691347ceaec964750207618f584e4f6dc3', '/docente/email/index.php', 'Envi&oacute; de e-mail', 'Envi&oacute; de correos electronicos', 'sapti,docente,email,index,ayuda', 'ED', 'AC'),
(223, 1, '524e6fc089a89f679dbb584cccdde97d3eebb08a', '/autoridad/respaldo/index.php', 'Respaldo del Sistema', 'Bakup del Sistema Sapti', 'sapti,autoridad,respaldo,index,ayuda', 'ED', 'AC'),
(227, 22, '75cad943369124026a2623998f5d3f0a61df62b8', '/autoridad/bitacora/index.php', 'Bit&aacute;coras', 'Bit&aacute;coras de Usuario del Sistema sapti', 'sapti,autoridad,bitacora,index,ayuda', 'ED', 'AC'),
(228, 4, '299568acc5d159c2ab0538bc1cc2368d34a74575', '/autoridad/Tribunal/docente.gestion.php', 'Gesti&oacute;n tribunales', 'Registrar un tribunal mediante formualrio', 'sapti,autoridad,Tribunal,docente,gestion,ayuda', 'ED', 'AC'),
(229, 16, '5d7f669cdeb6ce25c2e4a5e8c8a54294f83c2cbd', '/consejo/listatribunal.php', '/sapti/consejo/listatribunal.php', '/sapti/consejo/listatribunal.php', 'sapti,consejo,listatribunal,ayuda', 'RC', 'AC'),
(230, 16, 'a2661c34dd6cde1b5b6cdc7da4b2641f5aec4bd7', '/consejo/listadefensa.php', '/sapti/consejo/listadefensa.php', '/sapti/consejo/listadefensa.php', 'sapti,consejo,listadefensa,ayuda', 'RC', 'AC'),
(231, 16, '463bad35d13b1d42a84f2647a2c76d635e5c8154', '/consejo/proyecto.defensa.php', '/sapti/consejo/proyecto.defensa.php', '/sapti/consejo/proyecto.defensa.php', 'sapti,consejo,proyecto,defensa,ayuda', 'RC', 'AC'),
(232, 15, '38536f8869a1b956a71af0d43cb800d1c43e057e', '/docente//foro/respuesta.registro.php', 'Respuesta al Foro', 'Responder al foro del tema planteado', 'sapti,docente,,foro,respuesta,registro,ayuda', 'ED', 'AC'),
(233, 14, '598fb5a900712da496078baa4b35098e9d2df83d', '/autoridad/bitacora/index.php', '/sapti/autoridad/bitacora/index.php', '/sapti/autoridad/bitacora/index.php', 'sapti,autoridad,bitacora,index,ayuda', 'RC', 'AC'),
(234, 14, 'b142fc4b149a2bdbdbb28853de5f31056bac0617', '/autoridad//bitacora/index.php', '/sapti/autoridad//bitacora/index.php', '/sapti/autoridad//bitacora/index.php', 'sapti,autoridad,,bitacora,index,ayuda', 'RC', 'AC'),
(235, 22, 'a60677a906a3c4d70ab315ff6e3b8dbe20431a69', '/autoridad/bitacora/bitacora.php', '/sapti/autoridad/bitacora/bitacora.php', '/sapti/autoridad/bitacora/bitacora.php', 'sapti,autoridad,bitacora,bitacora,ayuda', 'RC', 'AC'),
(236, 12, '86179e03d9bfab91b3b0259163a6a0a036265206', '/autoridad/bitacora/bitacora.php', '/sapti/autoridad/bitacora/bitacora.php', '/sapti/autoridad/bitacora/bitacora.php', 'sapti,autoridad,bitacora,bitacora,ayuda', 'RC', 'AC'),
(237, 4, 'a3390ef6bf7aec44b94c8094e4340ecd95ef019b', '/autoridad/bitacora/bitacora.php', '/sapti/autoridad/bitacora/bitacora.php', '/sapti/autoridad/bitacora/bitacora.php', 'sapti,autoridad,bitacora,bitacora,ayuda', 'RC', 'AC'),
(238, 4, '75cad943369124026a2623998f5d3f0a61df62b8', '/autoridad/bitacora/index.php', 'Bitacora', 'Lista de Bit&aacute;coras del Sistema', 'sapti,autoridad,bitacora,index,ayuda', 'ED', 'AC'),
(239, 15, 'fad45c696d7b5fc642ad28b72552f0824330d3fe', '/docente//foro/tema.registro.php', 'Tema Registro', 'Registro de temas para el Foro docente', 'sapti,docente,,foro,tema,registro,ayuda', 'ED', 'AC'),
(240, 9, '94fcba4f84335cd9108c542d573a95c1e4286bcf', '/index.php', '/index.php', '/index.php', 'index,ayuda', 'RC', 'AC'),
(241, 1, 'a53291cd80ef64046912e832a07267d16b1a0f33', '/autoridad/index.php', '/autoridad/index.php', '/autoridad/index.php', 'autoridad,index,ayuda', 'RC', 'AC'),
(242, 9, '47a83624c45361d4eb8f3b7cd9a027bdfbf7b552', '/autoridad/login.php', '/autoridad/login.php', '/autoridad/login.php', 'autoridad,login,ayuda', 'RC', 'AC'),
(243, 7, '3d8916c97faf8974391c74b6a6600846797416ce', '/autoridad/tutor/estudiante.asignartutor.php', '/autoridad/tutor/estudiante.asignartutor.php', '/autoridad/tutor/estudiante.asignartutor.php', 'autoridad,tutor,estudiante,asignartutor,ayuda', 'RC', 'AC'),
(244, 15, '1e0bb5f4e57c1a5cd343a43dc0a59f7796bbd361', '/docente/tutor/observacion.editar.revision.php', '/docente/tutor/observacion.editar.revision.php', '/docente/tutor/observacion.editar.revision.php', 'docente,tutor,observacion,editar,revision,ayuda', 'RC', 'AC'),
(245, 17, '2615cce62b0e78e8cfb487db8f8b69bd2569ab00', '/estudiante/notificacion/notificacion.detalle.php', '/estudiante/notificacion/notificacion.detalle.php', '/estudiante/notificacion/notificacion.detalle.php', 'estudiante,notificacion,notificacion,detalle,ayuda', 'RC', 'AC'),
(246, 9, 'af7c3bebf60cc6a59e3d7794e00eef486d6e3a9d', '/autoridad/configuracion/cerrar.semestre.php', '/autoridad/configuracion/cerrar.semestre.php', '/autoridad/configuracion/cerrar.semestre.php', 'autoridad,configuracion,cerrar,semestre,ayuda', 'RC', 'AC'),
(247, 15, 'e182000fa90b79029c332bd49c5649151e5e4732', '/docente/estudiante/inscripcion.estudiante-cvs-lista.php', '/docente/estudiante/inscripcion.estudiante-cvs-lista.php', '/docente/estudiante/inscripcion.estudiante-cvs-lista.php', 'docente,estudiante,inscripcion,estudiante-cvs-lista,ayuda', 'RC', 'AC'),
(248, 2, '8d4a4efefbf7383e057635841a9813430c518863', '/autoridad/configuracion/configuracion_semestral.registro.php', '/autoridad/configuracion/configuracion_semestral.registro.php', '/autoridad/configuracion/configuracion_semestral.registro.php', 'autoridad,configuracion,configuracion_semestral,registro,ayuda', 'RC', 'AC'),
(249, 16, '698c0f27b77da3a33ae8a7cc936a382cf5b75d9a', '/consejo/mostrartribunal.php', '/consejo/mostrartribunal.php', '/consejo/mostrartribunal.php', 'consejo,mostrartribunal,ayuda', 'RC', 'AC'),
(250, 15, '308ac224bb9e923ceb33e6101d3d0eef48e1c898', '/docente/tribunal/avance.detalle.php', '/docente/tribunal/avance.detalle.php', '/docente/tribunal/avance.detalle.php', 'docente,tribunal,avance,detalle,ayuda', 'RC', 'AC'),
(251, 15, '02342d37210fc4383c8db5e2a7d858e5fab6fc44', '/docente/tribunal/proyecto.vistobueno.php', '/docente/tribunal/proyecto.vistobueno.php', '/docente/tribunal/proyecto.vistobueno.php', 'docente,tribunal,proyecto,vistobueno,ayuda', 'RC', 'AC');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `hora`
--

DROP TABLE IF EXISTS `hora`;
CREATE TABLE IF NOT EXISTS `hora` (
`id` int(11) NOT NULL,
  `dia_id` int(11) DEFAULT NULL,
  `hora_inicio` varchar(45) DEFAULT NULL,
  `hora_fin` varchar(45) DEFAULT NULL,
  `estado` varchar(2) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `hora`
--

INSERT INTO `hora` (`id`, `dia_id`, `hora_inicio`, `hora_fin`, `estado`) VALUES
(1, 1, '08:15', '09:45', 'AC'),
(2, 1, '09:45', '11:15', 'AC'),
(3, 1, '11:15', '12:45', 'AC'),
(4, 1, '12:45', '14:15', 'AC'),
(5, 1, '14:15', '15:45', 'AC'),
(6, 1, '15:45', '17:15', 'AC'),
(7, 1, '17:15', '18:45', 'AC'),
(8, 1, '18:45', '20:15', 'AC'),
(9, 2, '08:15', '09:45', 'AC'),
(10, 2, '09:45', '11:15', 'AC'),
(11, 2, '11:15', '12:45', 'AC'),
(12, 2, '12:45', '14:15', 'AC'),
(13, 2, '14:15', '15:45', 'AC'),
(14, 2, '15:45', '17:15', 'AC'),
(15, 2, '17:15', '18:45', 'AC'),
(16, 2, '18:45', '20:15', 'AC'),
(17, 3, '08:15', '09:45', 'AC'),
(18, 3, '09:45', '11:15', 'AC'),
(19, 3, '11:15', '12:45', 'AC'),
(20, 3, '12:45', '14:15', 'AC'),
(21, 3, '14:15', '15:45', 'AC'),
(22, 3, '15:45', '17:15', 'AC'),
(23, 3, '17:15', '18:45', 'AC'),
(24, 3, '18:45', '20:15', 'AC'),
(25, 4, '08:15', '09:45', 'AC'),
(26, 4, '09:45', '11:15', 'AC'),
(27, 4, '11:15', '12:45', 'AC'),
(28, 4, '12:45', '14:15', 'AC'),
(29, 4, '14:15', '15:45', 'AC'),
(30, 4, '15:45', '17:15', 'AC'),
(31, 4, '17:15', '18:45', 'AC'),
(32, 4, '18:45', '20:15', 'AC'),
(33, 5, '08:15', '09:45', 'AC'),
(34, 5, '09:45', '11:15', 'AC'),
(35, 5, '11:15', '12:45', 'AC'),
(36, 5, '12:45', '14:15', 'AC'),
(37, 5, '14:15', '15:45', 'AC'),
(38, 5, '15:45', '17:15', 'AC'),
(39, 5, '17:15', '18:45', 'AC'),
(40, 5, '18:45', '20:15', 'AC');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `horario_docente`
--

DROP TABLE IF EXISTS `horario_docente`;
CREATE TABLE IF NOT EXISTS `horario_docente` (
`id` int(11) NOT NULL,
  `docente_id` int(11) DEFAULT NULL,
  `hora_id` int(11) DEFAULT NULL,
  `estado` varchar(2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `inscrito`
--

DROP TABLE IF EXISTS `inscrito`;
CREATE TABLE IF NOT EXISTS `inscrito` (
`id` int(11) NOT NULL,
  `evaluacion_id` int(11) DEFAULT NULL,
  `dicta_id` int(11) DEFAULT NULL,
  `estudiante_id` int(11) DEFAULT NULL,
  `semestre_id` int(11) DEFAULT NULL,
  `estado_inscrito` varchar(2) DEFAULT NULL COMMENT 'cerrado si paso(CR), activo si es que es la activa (AC)',
  `estado` varchar(2) DEFAULT NULL COMMENT 'Activo sera AC, No activo NC, Eliminado DE'
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `inscrito`
--

INSERT INTO `inscrito` (`id`, `evaluacion_id`, `dicta_id`, `estudiante_id`, `semestre_id`, `estado_inscrito`, `estado`) VALUES
(1, 1, 1, 1, 1, 'CR', 'AC'),
(2, 2, 1, 2, 1, 'CR', 'AC'),
(3, 3, 1, 3, 1, 'CR', 'AC'),
(4, 4, 1, 4, 1, 'CR', 'AC'),
(5, 5, 1, 5, 1, 'CR', 'AC'),
(6, 6, 1, 6, 1, 'CR', 'AC'),
(7, 7, 1, 7, 1, 'CR', 'AC'),
(8, 8, 1, 8, 1, 'CR', 'AC'),
(9, 9, 1, 9, 1, 'CR', 'AC'),
(10, 10, 1, 10, 1, 'CR', 'AC'),
(11, 11, 1, 11, 1, 'CR', 'AC'),
(12, 12, 1, 12, 1, 'CR', 'AC'),
(13, 13, 1, 13, 1, 'CR', 'AC'),
(14, 14, 1, 14, 1, 'CR', 'AC'),
(15, 15, 1, 15, 1, 'CR', 'AC'),
(16, 16, 1, 16, 1, 'CR', 'AC'),
(17, 17, 1, 17, 1, 'CR', 'AC'),
(18, 18, 1, 18, 1, 'CR', 'AC'),
(19, 19, 1, 19, 1, 'CR', 'AC'),
(20, 20, 2, 20, 1, 'CR', 'AC'),
(21, 21, 2, 21, 1, 'CR', 'AC'),
(22, 22, 2, 22, 1, 'CR', 'AC'),
(23, 23, 3, 23, 1, 'CR', 'AC'),
(24, 24, 7, 21, 2, 'AC', 'AC'),
(25, 25, 7, 20, 2, 'AC', 'AC'),
(26, 26, 7, 22, 2, 'AC', 'AC'),
(27, 27, 7, 23, 2, 'AC', 'AC'),
(28, 28, 5, 24, 2, 'AC', 'AC');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `institucion`
--

DROP TABLE IF EXISTS `institucion`;
CREATE TABLE IF NOT EXISTS `institucion` (
`id` int(11) NOT NULL,
  `nombre` varchar(45) DEFAULT NULL,
  `descripcion` varchar(45) DEFAULT NULL,
  `estado` varchar(2) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `institucion`
--

INSERT INTO `institucion` (`id`, `nombre`, `descripcion`, `estado`) VALUES
(1, 'UNIVERSIDAD MAYOR DE SAN SIMON', 'universidad de cochabamba', 'AC');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `lugar`
--

DROP TABLE IF EXISTS `lugar`;
CREATE TABLE IF NOT EXISTS `lugar` (
`id` int(11) NOT NULL,
  `nombre` varchar(100) DEFAULT NULL,
  `estado` varchar(2) DEFAULT NULL COMMENT 'Activo sera AC, No activo NC, Eliminado DE',
  `descripcion` varchar(100) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `lugar`
--

INSERT INTO `lugar` (`id`, `nombre`, `estado`, `descripcion`) VALUES
(1, 'MEMI', 'AC', 'Solo sabados'),
(2, 'SALON DE INDUSTRIAL', 'AC', 'salon de industrial');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `materia`
--

DROP TABLE IF EXISTS `materia`;
CREATE TABLE IF NOT EXISTS `materia` (
`id` int(11) NOT NULL,
  `nombre` varchar(200) DEFAULT NULL,
  `estado` varchar(2) DEFAULT NULL COMMENT 'Activo sera AC, No activo NC, Eliminado DE',
  `sigla` varchar(20) DEFAULT NULL,
  `codigo` varchar(20) DEFAULT NULL,
  `carrera_id` int(11) NOT NULL DEFAULT '1',
  `tipo` varchar(4) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `materia`
--

INSERT INTO `materia` (`id`, `nombre`, `estado`, `sigla`, `codigo`, `carrera_id`, `tipo`) VALUES
(1, 'Proyecto Final', 'AC', 'Proyecto Final', NULL, 1, 'PR'),
(2, 'METODOL. Y PLANIF. DE PROYECTO DE GRADO', 'AC', 'MET-205', '231654', 1, 'PE');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `modalidad`
--

DROP TABLE IF EXISTS `modalidad`;
CREATE TABLE IF NOT EXISTS `modalidad` (
`id` int(11) NOT NULL,
  `nombre` varchar(45) DEFAULT NULL,
  `descripcion` varchar(45) DEFAULT NULL,
  `datos_adicionales` tinyint(1) DEFAULT NULL COMMENT 'si es que un proyecto en esta modalidad requiere institucion y responsable',
  `estado` varchar(2) DEFAULT NULL COMMENT 'Activo sera AC, No activo NC, Eliminado DE'
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `modalidad`
--

INSERT INTO `modalidad` (`id`, `nombre`, `descripcion`, `datos_adicionales`, `estado`) VALUES
(1, 'Proyecto de Grado', 'modalidad en proyecto de grado', 0, 'AC'),
(2, 'Adcripcion', 'proyectos para la Universidad', 1, 'AC'),
(3, 'Trabajo Dirijido', 'proyectos para instituciones', 0, 'AC');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `modelo_carta`
--

DROP TABLE IF EXISTS `modelo_carta`;
CREATE TABLE IF NOT EXISTS `modelo_carta` (
`id` int(11) NOT NULL,
  `codigo` varchar(100) DEFAULT NULL,
  `titulo` varchar(300) DEFAULT NULL,
  `descripcion` varchar(500) DEFAULT NULL,
  `tipo_proyecto` varchar(2) DEFAULT NULL COMMENT 'TIPO_PERFIL =  PE, TIPO_PROYECTO =  PR',
  `estado_proyecto` varchar(2) DEFAULT NULL COMMENT 'Iniciado (IN), Form Perfil Pendiente (PD), Form Perfil Confirmaddo (CO), Visto Bueno de Docente Tutores y Revisores (VB), Estado de proyecto con tribunal (TA), Tribunales Visto Bueno (TV), Con defensa Asignada(LD), Estado Proyecto  finalizado (PF)',
  `estado` varchar(2) DEFAULT NULL COMMENT 'Activo sera AC, No activo NC, Eliminado DE'
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `modelo_carta`
--

INSERT INTO `modelo_carta` (`id`, `codigo`, `titulo`, `descripcion`, `tipo_proyecto`, `estado_proyecto`, `estado`) VALUES
(1, 'f0c7ab609df8a213956b8a78d5c6e354413876a1', 'Aprobación Proyecto de Grado para nombramiento de tribunales', 'Aprobación Proyecto de Grado para nombramiento de tribunales', 'PR', 'VB', 'AC'),
(2, '10affa5539072c7d8cab3a580c946ecec0ab673a', 'Aprobación Proyecto de Grado', 'Aprobación Proyecto de Grado', 'PR', 'PF', 'AC'),
(3, 'ba5c299fd71ae48e2488563a77b0c7869876b139', 'Carta Asignacion Tribunales', 'Carta Asignacion Tribunales', 'PR', 'LD', 'AC');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `modulo`
--

DROP TABLE IF EXISTS `modulo`;
CREATE TABLE IF NOT EXISTS `modulo` (
`id` int(11) NOT NULL,
  `codigo` varchar(100) DEFAULT NULL,
  `descripcion` varchar(300) DEFAULT NULL,
  `estado` varchar(2) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `modulo`
--

INSERT INTO `modulo` (`id`, `codigo`, `descripcion`, `estado`) VALUES
(1, 'ADMIN-INDEX', 'M&oacute;dulo: ADMIN-INDEX', 'AC'),
(2, 'ADMIN-CONFIGURACION', 'M&oacute;dulo: ADMIN-CONFIGURACION', 'AC'),
(3, 'ADMIN-HELPDESK', 'M&oacute;dulo: ADMIN-HELPDESK', 'AC'),
(4, 'ADMIN-DOCENTE', 'M&oacute;dulo: ADMIN-DOCENTE', 'AC'),
(5, 'ADMIN-ESTUDIANTE-INDEX', 'M&oacute;dulo: ADMIN-ESTUDIANTE-INDEX', 'AC'),
(6, 'ADMIN-PROYECTO', 'M&oacute;dulo: ADMIN-PROYECTO', 'AC'),
(7, 'ADMIN-ESTUDIANTE', 'M&oacute;dulo: ADMIN-ESTUDIANTE', 'AC'),
(8, 'ADMIN-ESTUDIANTE-GESTION', 'M&oacute;dulo: ADMIN-ESTUDIANTE-GESTION', 'AC'),
(9, 'VISITA', 'M&oacute;dulo: VISITA', 'AC'),
(10, 'ESTUDIANTE', 'M&oacute;dulo: ESTUDIANTE', 'AC'),
(11, 'ADMIN-SEGURIDAD', 'M&oacute;dulo: ADMIN-SEGURIDAD', 'AC'),
(12, 'ADMIN-AUTORIDADES', 'M&oacute;dulo: ADMIN-AUTORIDADES', 'AC'),
(13, 'ADMIN-AUTORIDAD', 'M&oacute;dulo: ADMIN-AUTORIDAD', 'AC'),
(14, 'REPORTE', 'M&oacute;dulo: REPORTE', 'AC'),
(15, 'DOCENTE', 'M&oacute;dulo: DOCENTE', 'AC'),
(16, 'CONSEJO', 'M&oacute;dulo: CONSEJO', 'AC'),
(17, 'NOTIFICACION', 'M&oacute;dulo: NOTIFICACION', 'AC'),
(18, 'ADMIN-CARTAS', 'M&oacute;dulo: ADMIN-CARTAS', 'AC'),
(19, 'ADMIN-TUTOR', 'M&oacute;dulo: ADMIN-TUTOR', 'AC');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `nota`
--

DROP TABLE IF EXISTS `nota`;
CREATE TABLE IF NOT EXISTS `nota` (
`id` int(11) NOT NULL,
  `proyecto_id` int(11) NOT NULL,
  `nota_proyecto` int(11) DEFAULT NULL COMMENT 'nota del proyecto final',
  `nota_defensa` varchar(45) DEFAULT NULL COMMENT 'nota del defensa del proyecto',
  `nota_final` tinyint(1) DEFAULT NULL COMMENT 'nota final del proyecto',
  `estado` varchar(2) DEFAULT NULL COMMENT 'Activo sera AC, No activo NC, Eliminado DE'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `nota_tribunal`
--

DROP TABLE IF EXISTS `nota_tribunal`;
CREATE TABLE IF NOT EXISTS `nota_tribunal` (
`id` int(11) NOT NULL,
  `tribunal_id` int(11) DEFAULT NULL,
  `proyecto_id` int(11) DEFAULT NULL,
  `estado` varchar(2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `notificacion`
--

DROP TABLE IF EXISTS `notificacion`;
CREATE TABLE IF NOT EXISTS `notificacion` (
`id` int(11) NOT NULL,
  `proyecto_id` int(11) NOT NULL,
  `tipo` varchar(3) DEFAULT NULL COMMENT 'Mensaje normal, Mensaje de tiempo se acaba,Solicitud  y otros ',
  `fecha_envio` date DEFAULT NULL,
  `asunto` varchar(200) DEFAULT NULL,
  `detalle` text,
  `prioridad` tinyint(4) DEFAULT NULL COMMENT 'prioridad: 1 baja, 5 media, 10 maxima',
  `estado` varchar(2) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=64 DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `notificacion`
--

INSERT INTO `notificacion` (`id`, `proyecto_id`, `tipo`, `fecha_envio`, `asunto`, `detalle`, `prioridad`, `estado`) VALUES
(1, 39, 'N03', '2015-10-10', 'Petici&oacute;n de Tutor', 'El estudiante EST. ALBERTO BUDDY COAL solicita que MSC. ING. JORGE WALTER ORELLANA ARAOZ sea su tutor para el proyecto  ', 5, 'AC'),
(2, 39, 'N01', '2015-10-10', 'Nombramiento de tutor', 'Aceptamos', 7, 'AC'),
(3, 39, 'N01', '2015-10-10', 'Visto bueno del Tutor', '', 7, 'AC'),
(4, 40, 'N03', '2015-10-11', 'Petici&oacute;n de Tutor', 'El estudiante EST. ALBERTO GUTIERRES GUTIERRES solicita que MSC. ING. JORGE WALTER ORELLANA ARAOZ sea su tutor para el proyecto  ', 5, 'AC'),
(5, 40, 'N03', '2015-10-11', 'Petici&oacute;n de Tutor', 'El estudiante EST. ALBERTO GUTIERRES GUTIERRES solicita que MSC. LIC. K. ROLANDO JALDIN ROSALES sea su tutor para el proyecto  ', 5, 'AC'),
(6, 40, 'N03', '2015-10-11', 'Petici&oacute;n de Tutor', 'El estudiante EST. ALBERTO GUTIERRES GUTIERRES solicita que MSC. ING. AMERICO FIORILO LOZADA sea su tutor para el proyecto  ', 5, 'AC'),
(7, 40, 'N03', '2015-10-11', 'Petici&oacute;n de Tutor', 'El estudiante EST. ALBERTO GUTIERRES GUTIERRES solicita que MSC. ING. WALTER COSIO CABRERA sea su tutor para el proyecto  ', 5, 'AC'),
(8, 40, 'N01', '2015-10-11', 'Nombramiento de tutor', 'Aceptamos', 7, 'AC'),
(9, 40, 'N01', '2015-10-11', 'Nombramiento de tutor', 'acepta', 7, 'AC'),
(10, 40, 'N01', '2015-10-11', 'Nombramiento de tutor', 'Acettar', 7, 'AC'),
(11, 40, 'N01', '2015-10-11', 'Nombramiento de tutor', 'Aceptamos', 7, 'AC'),
(12, 40, 'N01', '2015-10-11', 'Avance: EST. ALBERTO GUTIERRES GUTIERRES', 'El estudiante EST. ALBERTO GUTIERRES GUTIERRES realizó un avance en su proyecto , en la fecha 11/10/2015 ', 3, 'AC'),
(13, 40, 'N01', '2015-10-11', 'Avance: EST. ALBERTO GUTIERRES GUTIERRES', 'El estudiante EST. ALBERTO GUTIERRES GUTIERRES realizó un avance en su proyecto , en la fecha 11/10/2015 ', 3, 'AC'),
(14, 40, 'N01', '2015-10-11', 'Avance: EST. ALBERTO GUTIERRES GUTIERRES', 'El estudiante EST. ALBERTO GUTIERRES GUTIERRES realizó un avance en su proyecto , en la fecha 11/10/2015 ', 3, 'AC'),
(15, 40, 'N01', '2015-10-11', 'Revision de Avance', 'Revision de Avance con observaciones realizadas por MSC. ING. JORGE WALTER ORELLANA ARAOZ para su consideracion.', 3, 'AC'),
(16, 40, 'N01', '2015-10-11', 'Avance: EST. ALBERTO GUTIERRES GUTIERRES', 'El estudiante EST. ALBERTO GUTIERRES GUTIERRES realizó un avance en su proyecto , en la fecha 11/10/2015 ', 3, 'AC'),
(17, 40, 'N01', '2015-10-11', 'Revision de Avance', 'Revision de Avance con observaciones realizadas por MSC. ING. JORGE WALTER ORELLANA ARAOZ para su consideracion.', 3, 'AC'),
(18, 40, 'N01', '2015-10-11', 'Avance: EST. ALBERTO GUTIERRES GUTIERRES', 'El estudiante EST. ALBERTO GUTIERRES GUTIERRES realizó un avance en su proyecto , en la fecha 11/10/2015 ', 3, 'AC'),
(19, 40, 'N01', '2015-10-11', 'Revision de Avance', 'Revision de Avance con observaciones realizadas por MSC. ING. JORGE WALTER ORELLANA ARAOZ para su consideracion.', 3, 'AC'),
(20, 40, 'N01', '2015-10-11', 'Avance: EST. ALBERTO GUTIERRES GUTIERRES', 'El estudiante EST. ALBERTO GUTIERRES GUTIERRES realizó un avance en su proyecto , en la fecha 11/10/2015 ', 3, 'AC'),
(21, 40, 'N01', '2015-10-11', 'Revision de Avance', 'Revision de Avance con observaciones realizadas por MSC. ING. JORGE WALTER ORELLANA ARAOZ para su consideracion.', 3, 'AC'),
(22, 40, 'N01', '2015-10-11', 'Avance: EST. ALBERTO GUTIERRES GUTIERRES', 'El estudiante EST. ALBERTO GUTIERRES GUTIERRES realizó un avance en su proyecto , en la fecha 11/10/2015 ', 3, 'AC'),
(23, 40, 'N01', '2015-10-11', 'Visto bueno del Tutor', '', 7, 'AC'),
(24, 40, 'N01', '2015-10-11', 'Visto bueno del Tutor', '', 7, 'AC'),
(25, 40, 'N01', '2015-10-11', 'Visto bueno del Tutor', '', 7, 'AC'),
(26, 40, 'N01', '2015-10-11', 'Visto bueno del Tutor', '', 7, 'AC'),
(27, 40, 'N01', '2015-10-11', ' Visto bueno del Docente', '', 7, 'AC'),
(28, 40, 'N01', '2015-10-11', 'Esta Habilitado tu Formulario', '', 7, 'AC'),
(29, 43, 'N01', '2015-11-01', 'Avance: EST. PEPITO PEREZ GARNICA', 'El estudiante EST. PEPITO PEREZ GARNICA realizó un avance en su proyecto Desarrollo aplicaciones mobiles, en la fecha 01/11/2015 ', 3, 'AC'),
(30, 43, 'N01', '2015-11-01', 'Revision de Avance', 'Revision de Avance con observaciones realizadas por MSC. ING. JORGE WALTER ORELLANA ARAOZ para su consideracion.', 3, 'AC'),
(31, 43, 'N01', '2015-11-01', 'Avance: EST. PEPITO PEREZ GARNICA', 'El estudiante EST. PEPITO PEREZ GARNICA realizó un avance en su proyecto Desarrollo aplicaciones mobiles, en la fecha 01/11/2015 ', 3, 'AC'),
(32, 43, 'N01', '2015-11-01', 'Avance: EST. PEPITO PEREZ GARNICA', 'El estudiante EST. PEPITO PEREZ GARNICA realizó un avance en su proyecto Desarrollo aplicaciones mobiles, en la fecha 01/11/2015 ', 3, 'AC'),
(33, 43, 'N01', '2015-11-01', 'Avance: EST. PEPITO PEREZ GARNICA', 'El estudiante EST. PEPITO PEREZ GARNICA realizó un avance en su proyecto Desarrollo aplicaciones mobiles, en la fecha 01/11/2015 ', 3, 'AC'),
(34, 43, 'N01', '2015-11-01', 'Visto bueno del Tutor', '', 7, 'AC'),
(35, 43, 'N01', '2015-11-01', 'Visto bueno del Tutor', '', 7, 'AC'),
(36, 43, 'N01', '2015-11-01', 'Visto bueno del Tutor', '', 7, 'AC'),
(37, 43, 'N01', '2015-11-01', 'Visto bueno del Tutor', '', 7, 'AC'),
(38, 43, 'N01', '2015-11-01', ' Visto bueno del Docente', '', 7, 'AC'),
(39, 43, 'N01', '2015-11-01', 'Estas Habilitado para tus Defensas', '', 7, 'AC'),
(40, 43, 'N01', '2015-11-01', 'Asignacion de Tribunales', 'Se le Asigno Tribunales', 5, 'AC'),
(41, 43, 'N03', '2015-11-01', 'Asignacion de Tribunales', '<p>Se le Asign&oacute; los Tribunales correspondientes al proyecto:Desarrollo aplicaciones mobiles del estudiante:EST. PEPITO PEREZ GARNICA para que usted realize las funciones como tribunal al proyecto ya mencionado esperamos su pronta respuesta</p>\r\n', 5, 'AC'),
(42, 43, 'N03', '2015-11-01', 'Asignacion de Tribunales', '<p>Se le Asign&oacute; los Tribunales correspondientes al proyecto:Desarrollo aplicaciones mobiles del estudiante:EST. PEPITO PEREZ GARNICA para que usted realize las funciones como tribunal al proyecto ya mencionado esperamos su pronta respuesta</p>\r\n', 5, 'AC'),
(43, 43, 'N03', '2015-11-01', 'Asignacion de Tribunales', '<p>Se le Asign&oacute; los Tribunales correspondientes al proyecto:Desarrollo aplicaciones mobiles del estudiante:EST. PEPITO PEREZ GARNICA para que usted realize las funciones como tribunal al proyecto ya mencionado esperamos su pronta respuesta</p>\r\n', 5, 'AC'),
(44, 43, 'N01', '2015-11-01', 'Revision de Avance', 'Revision de Avance con observaciones realizadas por LIC. JUAN MARCELO FLORES SOLIZ para su consideracion.', 3, 'AC'),
(45, 43, 'N01', '2015-11-01', 'Avance: EST. PEPITO PEREZ GARNICA', 'El estudiante EST. PEPITO PEREZ GARNICA realizó un avance en su proyecto Desarrollo aplicaciones mobiles, en la fecha 01/11/2015 ', 3, 'AC'),
(46, 44, 'N03', '2015-10-21', 'Petici&oacute;n de Tutor&iacute;a', 'El estudiante EST. AVANCE ACANCE ACENCE solicita que PH.D. CARLOS MEDINA MEDINA sea su tutor en su proyecto  ', 5, 'AC'),
(47, 44, 'N01', '2015-10-21', 'Finalizacion de Tutoria', 'El estudiante EST. AVANCE ACANCE ACENCE agradece a PH.D. CARLOS MEDINA MEDINA toda su colaboraci&ocaute;n en el proyecto  y da por concluida su tutoria', 3, 'AC'),
(48, 44, 'N03', '2015-10-21', 'Petici&oacute;n de Tutor&iacute;a', 'El estudiante EST. AVANCE ACANCE ACENCE solicita que MSC. ING. JORGE WALTER ORELLANA ARAOZ sea su tutor en su proyecto  ', 5, 'AC'),
(49, 44, 'N03', '2015-10-21', 'Petici&oacute;n de Tutor&iacute;a', 'El estudiante EST. AVANCE ACANCE ACENCE solicita que MSC. LIC. K. ROLANDO JALDIN ROSALES sea su tutor en su proyecto  ', 5, 'AC'),
(50, 44, 'N04', '2015-10-21', 'Nombramiento de tutor: Acepto', 'Tutor : MSC. LIC. K. ROLANDO JALDIN ROSALES, ', 7, 'AC'),
(51, 44, 'N04', '2015-10-21', 'Nombramiento de tutor: Acepto', 'Tutor : MSC. ING. JORGE WALTER ORELLANA ARAOZ, ', 7, 'AC'),
(52, 44, 'N01', '2015-10-21', 'Avance: EST. AVANCE ACANCE ACENCE', 'El estudiante EST. AVANCE ACANCE ACENCE realizó un avance en su proyecto , en la fecha 21/10/2015 ;SPT;8;SPT;AV', 3, 'AC'),
(53, 44, 'N01', '2015-10-21', 'Avance: EST. AVANCE ACANCE ACENCE', 'El estudiante EST. AVANCE ACANCE ACENCE realizó un avance en su proyecto , en la fecha 21/10/2015 ;SPT;9;SPT;AV', 3, 'AC'),
(54, 44, 'N01', '2015-10-20', 'Revisión de Avance', 'Revisión de Avance con observaciones realizadas por MSC. ING. JORGE WALTER ORELLANA ARAOZ para su consideracion. ;SPT;7;SPT;CR', 3, 'AC'),
(55, 44, 'N01', '2015-10-21', 'Avance: EST. AVANCE ACANCE ACENCE', 'El estudiante EST. AVANCE ACANCE ACENCE realizó un avance en su proyecto , en la fecha 21/10/2015 ;SPT;10;SPT;AV', 3, 'AC'),
(56, 44, 'N01', '2015-10-21', 'Correccion: EST. AVANCE ACANCE ACENCE', 'El estudiante EST. AVANCE ACANCE ACENCE realizó una Correccion en su proyecto , en la fecha 21/10/2015 ;SPT;9;SPT;CO', 3, 'AC'),
(57, 44, 'N01', '2015-10-20', 'Revisión de Avance', 'Revisión de Avance con observaciones realizadas por MSC. ING. JORGE WALTER ORELLANA ARAOZ para su consideracion. ;SPT;8;SPT;CR', 3, 'AC'),
(58, 44, 'N01', '2015-10-21', 'Correccion: EST. AVANCE ACANCE ACENCE', 'El estudiante EST. AVANCE ACANCE ACENCE realizó una Correccion en su proyecto , en la fecha 21/10/2015 ;SPT;9;SPT;CO', 3, 'AC'),
(59, 44, 'N04', '2015-10-21', 'VoBo Perfil, Tutor', 'Aprobado por: MSC. ING. JORGE WALTER ORELLANA ARAOZ', 7, 'AC'),
(60, 44, 'N04', '2015-10-21', 'VoBo Perfil, Tutor', 'Aprobado por: MSC. LIC. K. ROLANDO JALDIN ROSALES', 7, 'AC'),
(61, 44, 'N04', '2015-10-21', 'VoBo Perfil, Docente', 'Aprobado por: ING. SAMUEL ROBERTO ACHá PEREZ', 7, 'AC'),
(62, 44, 'N04', '2015-10-21', 'VoBo Perfil, Docente', 'Aprobado por: ING. SAMUEL ROBERTO ACHá PEREZ', 7, 'AC'),
(63, 43, 'N04', '2015-10-21', 'Asignación de Fechas de Defensa', 'Se le asignó la fecha de defensa  fecha : 21/10/2015 hora  : 09:45 Lungar de defensa  : MEMI', 5, 'AC');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `notificacion_consejo`
--

DROP TABLE IF EXISTS `notificacion_consejo`;
CREATE TABLE IF NOT EXISTS `notificacion_consejo` (
`id` int(11) NOT NULL,
  `notificacion_id` int(11) NOT NULL,
  `consejo_id` int(11) NOT NULL,
  `accion` varchar(45) DEFAULT NULL COMMENT 'Aceptar , rechazar ',
  `fecha_visto` date DEFAULT NULL,
  `estado_notificacion` varchar(2) DEFAULT NULL COMMENT 'Sin ver (SV), Visto (VI) , archivado (AR)',
  `estado` varchar(2) DEFAULT NULL COMMENT 'Activo sera AC, No activo NC, Eliminado DE'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `notificacion_dicta`
--

DROP TABLE IF EXISTS `notificacion_dicta`;
CREATE TABLE IF NOT EXISTS `notificacion_dicta` (
`id` int(11) NOT NULL,
  `notificacion_id` int(11) DEFAULT NULL,
  `dicta_id` int(11) DEFAULT NULL,
  `fecha_visto` date DEFAULT NULL,
  `estado_notificacion` varchar(2) DEFAULT NULL COMMENT 'Sin ver (SV), Visto (VI) , archivado (AR)',
  `estado` varchar(2) DEFAULT NULL COMMENT 'Activo sera AC, No activo NC, Eliminado DE'
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `notificacion_dicta`
--

INSERT INTO `notificacion_dicta` (`id`, `notificacion_id`, `dicta_id`, `fecha_visto`, `estado_notificacion`, `estado`) VALUES
(1, 12, 2, '2015-10-11', 'VI', 'AC'),
(2, 13, 2, '2015-10-11', 'VI', 'AC'),
(3, 14, 2, '2015-10-11', 'VI', 'AC'),
(4, 16, 2, '2015-10-11', 'VI', 'AC'),
(5, 18, 2, '2015-10-11', 'VI', 'AC'),
(6, 20, 2, '2015-10-11', 'VI', 'AC'),
(7, 22, 2, '2015-11-01', 'VI', 'AC'),
(8, 29, 7, '2015-11-01', 'VI', 'AC'),
(9, 31, 7, '2015-11-01', 'VI', 'AC'),
(10, 32, 7, '2015-11-01', 'VI', 'AC'),
(11, 33, 7, '2015-11-01', 'VI', 'AC'),
(12, 45, 7, '2015-11-01', 'VI', 'AC'),
(13, 52, 5, '0000-00-00', 'SV', 'AC'),
(14, 53, 5, '0000-00-00', 'SV', 'AC'),
(15, 55, 5, '0000-00-00', 'SV', 'AC'),
(16, 56, 5, '2015-10-21', 'VI', 'AC'),
(17, 58, 5, '0000-00-00', 'SV', 'AC');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `notificacion_estudiante`
--

DROP TABLE IF EXISTS `notificacion_estudiante`;
CREATE TABLE IF NOT EXISTS `notificacion_estudiante` (
`id` int(11) NOT NULL,
  `notificacion_id` int(11) NOT NULL,
  `estudiante_id` int(11) NOT NULL,
  `fecha_visto` date DEFAULT NULL,
  `estado_notificacion` varchar(2) DEFAULT NULL COMMENT 'Sin ver (SV), Visto (VI) , archivado (AR)',
  `estado` varchar(2) DEFAULT NULL COMMENT 'Activo sera AC, No activo NC, Eliminado DE'
) ENGINE=InnoDB AUTO_INCREMENT=53 DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `notificacion_estudiante`
--

INSERT INTO `notificacion_estudiante` (`id`, `notificacion_id`, `estudiante_id`, `fecha_visto`, `estado_notificacion`, `estado`) VALUES
(1, 2, 20, '0000-00-00', 'SV', 'AC'),
(2, 3, 20, '0000-00-00', 'SV', 'AC'),
(3, 8, 21, '2015-10-11', 'VI', 'AC'),
(4, 9, 21, '2015-10-11', 'VI', 'AC'),
(5, 10, 21, '2015-10-11', 'VI', 'AC'),
(6, 11, 21, '2015-10-11', 'VI', 'AC'),
(7, 12, 21, '2015-10-11', 'VI', 'AC'),
(8, 13, 21, '2015-10-11', 'VI', 'AC'),
(9, 14, 21, '2015-10-11', 'VI', 'AC'),
(10, 15, 21, '2015-10-11', 'VI', 'AC'),
(11, 16, 21, '2015-10-11', 'VI', 'AC'),
(12, 17, 21, '2015-10-11', 'VI', 'AC'),
(13, 18, 21, '2015-10-11', 'VI', 'AC'),
(14, 19, 21, '2015-10-11', 'VI', 'AC'),
(15, 20, 21, '2015-10-11', 'VI', 'AC'),
(16, 21, 21, '2015-10-11', 'VI', 'AC'),
(17, 22, 21, '2015-11-01', 'VI', 'AC'),
(18, 23, 21, '2015-10-11', 'VI', 'AC'),
(19, 24, 21, '2015-11-01', 'VI', 'AC'),
(20, 25, 21, '2015-11-01', 'VI', 'AC'),
(21, 26, 21, '2015-11-01', 'VI', 'AC'),
(22, 27, 21, '2015-11-01', 'VI', 'AC'),
(23, 28, 21, '2015-11-01', 'VI', 'AC'),
(24, 29, 21, '2015-11-01', 'VI', 'AC'),
(25, 30, 21, '2015-11-01', 'VI', 'AC'),
(26, 31, 21, '2015-11-01', 'VI', 'AC'),
(27, 32, 21, '2015-11-01', 'VI', 'AC'),
(28, 33, 21, '2015-11-01', 'VI', 'AC'),
(29, 34, 21, '2015-11-01', 'VI', 'AC'),
(30, 35, 21, '2015-11-01', 'VI', 'AC'),
(31, 36, 21, '2015-11-01', 'VI', 'AC'),
(32, 37, 21, '2015-11-01', 'VI', 'AC'),
(33, 38, 21, '2015-11-01', 'VI', 'AC'),
(34, 39, 21, '2015-11-01', 'VI', 'AC'),
(35, 40, 21, '2015-11-01', 'VI', 'AC'),
(36, 44, 21, '2015-11-01', 'VI', 'AC'),
(37, 45, 21, '2015-11-01', 'VI', 'AC'),
(38, 47, 24, '0000-00-00', 'SV', 'AC'),
(39, 50, 24, '0000-00-00', 'SV', 'AC'),
(40, 51, 24, '0000-00-00', 'SV', 'AC'),
(41, 52, 24, '0000-00-00', 'SV', 'AC'),
(42, 53, 24, '0000-00-00', 'SV', 'AC'),
(43, 54, 24, '0000-00-00', 'SV', 'AC'),
(44, 55, 24, '0000-00-00', 'SV', 'AC'),
(45, 56, 24, '2015-10-21', 'VI', 'AC'),
(46, 57, 24, '0000-00-00', 'SV', 'AC'),
(47, 58, 24, '0000-00-00', 'SV', 'AC'),
(48, 59, 24, '0000-00-00', 'SV', 'AC'),
(49, 60, 24, '0000-00-00', 'SV', 'AC'),
(50, 61, 24, '0000-00-00', 'SV', 'AC'),
(51, 62, 24, '0000-00-00', 'SV', 'AC'),
(52, 63, 21, '0000-00-00', 'SV', 'AC');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `notificacion_revisor`
--

DROP TABLE IF EXISTS `notificacion_revisor`;
CREATE TABLE IF NOT EXISTS `notificacion_revisor` (
`id` int(11) NOT NULL,
  `notificacion_id` int(11) NOT NULL,
  `revisor_id` int(11) NOT NULL,
  `accion` varchar(45) DEFAULT NULL COMMENT 'Aceptar , rechazar ',
  `fecha_visto` date DEFAULT NULL,
  `estado_notificacion` varchar(2) DEFAULT NULL COMMENT 'Sin ver (SV), Visto (VI) , archivado (AR)',
  `estado` varchar(2) DEFAULT NULL COMMENT 'Activo sera AC, No activo NC, Eliminado DE'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `notificacion_tribunal`
--

DROP TABLE IF EXISTS `notificacion_tribunal`;
CREATE TABLE IF NOT EXISTS `notificacion_tribunal` (
`id` int(11) NOT NULL,
  `notificacion_id` int(11) NOT NULL,
  `tribunal_id` int(11) NOT NULL,
  `accion` varchar(45) DEFAULT NULL COMMENT 'Aceptar , rechazar ',
  `fecha_visto` date DEFAULT NULL,
  `estado_notificacion` varchar(2) DEFAULT NULL COMMENT 'Sin ver (SV), Visto (VI) , archivado (AR)',
  `estado` varchar(2) DEFAULT NULL COMMENT 'Activo sera AC, No activo NC, Eliminado DE'
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `notificacion_tribunal`
--

INSERT INTO `notificacion_tribunal` (`id`, `notificacion_id`, `tribunal_id`, `accion`, `fecha_visto`, `estado_notificacion`, `estado`) VALUES
(1, 41, 52, NULL, '2015-11-01', 'VI', 'AC'),
(2, 42, 53, NULL, '2015-11-01', 'VI', 'AC'),
(3, 43, 54, NULL, '2015-11-01', 'VI', 'AC'),
(4, 45, 52, NULL, '2015-11-01', 'VI', 'AC'),
(5, 45, 53, NULL, '2015-11-01', 'VI', 'AC'),
(6, 45, 54, NULL, '2015-11-01', 'VI', 'AC');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `notificacion_tutor`
--

DROP TABLE IF EXISTS `notificacion_tutor`;
CREATE TABLE IF NOT EXISTS `notificacion_tutor` (
`id` int(11) NOT NULL,
  `notificacion_id` int(11) DEFAULT NULL,
  `tutor_id` int(11) DEFAULT NULL,
  `proyecto_tutor_id` int(11) DEFAULT NULL,
  `fecha_visto` date DEFAULT NULL,
  `estado_notificacion` varchar(2) DEFAULT NULL COMMENT 'Sin ver (SV), Visto (VI) , archivado (AR)',
  `estado` varchar(2) DEFAULT NULL COMMENT 'Activo sera AC, No activo NC, Eliminado DE'
) ENGINE=InnoDB AUTO_INCREMENT=73 DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `notificacion_tutor`
--

INSERT INTO `notificacion_tutor` (`id`, `notificacion_id`, `tutor_id`, `proyecto_tutor_id`, `fecha_visto`, `estado_notificacion`, `estado`) VALUES
(1, 1, 2, 1, '2015-10-10', 'VI', 'AC'),
(2, 4, 2, 2, '2015-10-11', 'VI', 'AC'),
(3, 5, 3, 3, '2015-10-11', 'VI', 'AC'),
(4, 6, 4, 4, '2015-10-11', 'VI', 'AC'),
(5, 7, 5, 5, '2015-10-11', 'VI', 'AC'),
(6, 12, 2, 0, '2015-10-11', 'VI', 'AC'),
(7, 12, 3, 0, '2015-10-11', 'VI', 'AC'),
(8, 12, 4, 0, '2015-10-11', 'VI', 'AC'),
(9, 12, 5, 0, '2015-10-11', 'VI', 'AC'),
(10, 13, 2, 0, '2015-10-11', 'VI', 'AC'),
(11, 13, 3, 0, '2015-10-11', 'VI', 'AC'),
(12, 13, 4, 0, '2015-10-11', 'VI', 'AC'),
(13, 13, 5, 0, '2015-10-11', 'VI', 'AC'),
(14, 14, 2, 0, '2015-10-11', 'VI', 'AC'),
(15, 14, 3, 0, '2015-10-11', 'VI', 'AC'),
(16, 14, 4, 0, '2015-10-11', 'VI', 'AC'),
(17, 14, 5, 0, '2015-10-11', 'VI', 'AC'),
(18, 16, 2, 0, '2015-10-11', 'VI', 'AC'),
(19, 16, 3, 0, '2015-10-11', 'VI', 'AC'),
(20, 16, 4, 0, '2015-10-11', 'VI', 'AC'),
(21, 16, 5, 0, '2015-10-11', 'VI', 'AC'),
(22, 18, 2, 0, '2015-10-11', 'VI', 'AC'),
(23, 18, 3, 0, '2015-10-11', 'VI', 'AC'),
(24, 18, 4, 0, '2015-10-11', 'VI', 'AC'),
(25, 18, 5, 0, '2015-10-11', 'VI', 'AC'),
(26, 20, 2, 0, '2015-10-11', 'VI', 'AC'),
(27, 20, 3, 0, '2015-10-11', 'VI', 'AC'),
(28, 20, 4, 0, '2015-10-11', 'VI', 'AC'),
(29, 20, 5, 0, '2015-10-11', 'VI', 'AC'),
(30, 22, 2, 0, '2015-11-01', 'VI', 'AC'),
(31, 22, 3, 0, '2015-11-01', 'VI', 'AC'),
(32, 22, 4, 0, '2015-11-01', 'VI', 'AC'),
(33, 22, 5, 0, '2015-11-01', 'VI', 'AC'),
(34, 29, 2, 0, '2015-11-01', 'VI', 'AC'),
(35, 29, 3, 0, '2015-11-01', 'VI', 'AC'),
(36, 29, 4, 0, '2015-11-01', 'VI', 'AC'),
(37, 29, 5, 0, '2015-11-01', 'VI', 'AC'),
(38, 31, 2, 0, '2015-11-01', 'VI', 'AC'),
(39, 31, 3, 0, '2015-11-01', 'VI', 'AC'),
(40, 31, 4, 0, '2015-11-01', 'VI', 'AC'),
(41, 31, 5, 0, '2015-11-01', 'VI', 'AC'),
(42, 32, 2, 0, '2015-11-01', 'VI', 'AC'),
(43, 32, 3, 0, '2015-11-01', 'VI', 'AC'),
(44, 32, 4, 0, '2015-11-01', 'VI', 'AC'),
(45, 32, 5, 0, '2015-11-01', 'VI', 'AC'),
(46, 33, 2, 0, '2015-11-01', 'VI', 'AC'),
(47, 33, 3, 0, '2015-11-01', 'VI', 'AC'),
(48, 33, 4, 0, '2015-11-01', 'VI', 'AC'),
(49, 33, 5, 0, '2015-11-01', 'VI', 'AC'),
(50, 45, 2, 0, '2015-11-01', 'VI', 'AC'),
(51, 45, 3, 0, '2015-11-01', 'VI', 'AC'),
(52, 45, 4, 0, '2015-11-01', 'VI', 'AC'),
(53, 45, 5, 0, '2015-11-01', 'VI', 'AC'),
(54, 46, 1, 6, '0000-00-00', 'SV', 'AC'),
(55, 47, 1, 0, '0000-00-00', 'SV', 'AC'),
(56, 48, 2, 7, '2015-10-21', 'VI', 'AC'),
(57, 49, 3, 8, '2015-10-21', 'VI', 'AC'),
(58, 52, 1, 0, '0000-00-00', 'SV', 'AC'),
(59, 52, 2, 0, '0000-00-00', 'SV', 'AC'),
(60, 52, 3, 0, '0000-00-00', 'SV', 'AC'),
(61, 53, 1, 0, '0000-00-00', 'SV', 'AC'),
(62, 53, 2, 0, '0000-00-00', 'SV', 'AC'),
(63, 53, 3, 0, '0000-00-00', 'SV', 'AC'),
(64, 55, 1, 0, '0000-00-00', 'SV', 'AC'),
(65, 55, 2, 0, '0000-00-00', 'SV', 'AC'),
(66, 55, 3, 0, '0000-00-00', 'SV', 'AC'),
(67, 56, 1, 0, '2015-10-21', 'VI', 'AC'),
(68, 56, 2, 0, '2015-10-21', 'VI', 'AC'),
(69, 56, 3, 0, '2015-10-21', 'VI', 'AC'),
(70, 58, 1, 0, '0000-00-00', 'SV', 'AC'),
(71, 58, 2, 0, '0000-00-00', 'SV', 'AC'),
(72, 58, 3, 0, '0000-00-00', 'SV', 'AC');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `objetivo_especifico`
--

DROP TABLE IF EXISTS `objetivo_especifico`;
CREATE TABLE IF NOT EXISTS `objetivo_especifico` (
`id` int(11) NOT NULL,
  `proyecto_id` int(11) NOT NULL,
  `descripcion` text,
  `estado` varchar(2) DEFAULT NULL COMMENT 'Activo sera AC, No activo NC, Eliminado DE'
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `objetivo_especifico`
--

INSERT INTO `objetivo_especifico` (`id`, `proyecto_id`, `descripcion`, `estado`) VALUES
(1, 19, 'Diseñar e implementar la Base de datos para la administración de usuarios, control del modulo ventas y para la administración del modulo libros.', 'AC'),
(2, 19, 'Desarrollar la implementación de control del modulo de ventas y para la administración del modulo libros.', 'AC'),
(3, 19, 'Integración del portal web con técnicas de posicionamiento web.', 'AC'),
(4, 18, 'Desarrollar un módulo que pueda mostrar los reportes', 'AC'),
(5, 13, 'Elaborar documentos finales', 'AC'),
(6, 32, 'Elaborar documentos finales', 'AC'),
(7, 37, 'Desarrollar un módulo que pueda mostrar los reportes', 'AC'),
(8, 38, 'Diseñar e implementar la Base de datos para la administración de usuarios, control del modulo ventas y para la administración del modulo libros.', 'AC'),
(9, 38, 'Desarrollar la implementación de control del modulo de ventas y para la administración del modulo libros.', 'AC'),
(10, 38, 'Integración del portal web con técnicas de posicionamiento web.', 'AC'),
(11, 40, 'OE1', 'AC'),
(12, 40, 'OE2', 'AC'),
(13, 40, 'OE3', 'AC'),
(14, 43, 'OE1', 'AC'),
(15, 43, 'OE2', 'AC'),
(16, 43, 'OE3', 'AC');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `observacion`
--

DROP TABLE IF EXISTS `observacion`;
CREATE TABLE IF NOT EXISTS `observacion` (
`id` int(11) NOT NULL,
  `revision_id` int(11) NOT NULL,
  `observacion` varchar(1500) DEFAULT NULL,
  `respuesta` varchar(1500) DEFAULT NULL,
  `estado_observacion` varchar(2) DEFAULT NULL COMMENT 'estado 1 creado (CR), etado 2 corregido (CO), estado 4  aprobado (AP)',
  `estado` varchar(2) DEFAULT NULL COMMENT 'Activo sera AC, No activo NC, Eliminado DE'
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `observacion`
--

INSERT INTO `observacion` (`id`, `revision_id`, `observacion`, `respuesta`, `estado_observacion`, `estado`) VALUES
(1, 1, '1.- Corregir ortogragifa', '&lt;p&gt;Hecho&lt;/p&gt;\r\n', 'AP', 'AC'),
(2, 1, '2.- Corregir paginacion', '&lt;p&gt;Listo&lt;/p&gt;\r\n', 'AP', 'AC'),
(3, 1, '3.- Corregir caratula', '&lt;p&gt;Tengo una duda sobre el formato&lt;/p&gt;\r\n', 'NP', 'AC'),
(4, 2, '3.- Corregir caratula', '&lt;p&gt;Envio la version final con las obs. corregidas en caratula&lt;/p&gt;\r\n', 'NP', 'AC'),
(5, 3, '3.- Corregir caratula', '', 'CR', 'AC'),
(6, 4, 'Agregar Biografia', '&lt;p&gt;Completado&lt;/p&gt;\r\n', 'AP', 'AC'),
(7, 5, 'Agregar capitulo dos', '&lt;p&gt;Agregado&lt;/p&gt;\r\n', 'AP', 'AC'),
(8, 6, 'Correciones en el software', '&lt;p&gt;Correciones terminadas&lt;/p&gt;\r\n', 'AP', 'AC'),
(9, 7, 'fawefawefa', '&lt;p&gt;sg rgseg se gseg sg sr g&lt;/p&gt;\r\n', 'NP', 'AC'),
(10, 7, 'afweawefa awe faw fawf ', '&lt;p&gt;tw w4t wt4 wt w34t w34tw&amp;nbsp;&lt;/p&gt;\r\n', 'AP', 'AC'),
(11, 8, 'fawefawefa bsdbserbs', '&lt;p&gt;awd awd awd&lt;/p&gt;\r\n', 'AP', 'AC'),
(12, 8, 'dtser gsergsg', '&lt;p&gt;awd adaw aw a ad da&lt;/p&gt;\r\n', 'AP', 'AC');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `permiso`
--

DROP TABLE IF EXISTS `permiso`;
CREATE TABLE IF NOT EXISTS `permiso` (
`id` int(11) NOT NULL,
  `grupo_id` int(11) DEFAULT NULL,
  `modulo_id` int(11) DEFAULT NULL,
  `helpdesk_id` int(11) DEFAULT NULL,
  `ver` tinyint(1) DEFAULT NULL,
  `crear` tinyint(1) DEFAULT NULL,
  `editar` tinyint(1) DEFAULT NULL,
  `eliminar` tinyint(1) DEFAULT NULL,
  `estado` varchar(2) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=134 DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `permiso`
--

INSERT INTO `permiso` (`id`, `grupo_id`, `modulo_id`, `helpdesk_id`, `ver`, `crear`, `editar`, `eliminar`, `estado`) VALUES
(1, 1, 1, 0, 1, 1, 1, 1, 'AC'),
(2, 1, 2, 0, 1, 1, 1, 1, 'AC'),
(3, 1, 3, 0, 1, 1, 1, 1, 'AC'),
(4, 1, 4, 0, 1, 1, 1, 1, 'AC'),
(5, 1, 5, 0, 1, 1, 1, 1, 'AC'),
(6, 1, 6, 0, 1, 1, 1, 1, 'AC'),
(7, 1, 7, 0, 1, 1, 1, 1, 'AC'),
(8, 1, 8, 0, 1, 1, 1, 1, 'AC'),
(9, 1, 9, 0, 1, 1, 1, 1, 'AC'),
(10, 1, 10, 0, 1, 1, 1, 1, 'AC'),
(11, 1, 11, 0, 1, 1, 1, 1, 'AC'),
(12, 7, 11, 0, 0, 0, 0, 0, 'AC'),
(13, 7, 10, 0, 0, 0, 0, 0, 'AC'),
(14, 7, 9, 0, 0, 0, 0, 0, 'AC'),
(15, 7, 8, 0, 0, 0, 0, 0, 'AC'),
(16, 7, 7, 0, 0, 0, 0, 0, 'AC'),
(17, 7, 6, 0, 0, 0, 0, 0, 'AC'),
(18, 7, 5, 0, 0, 0, 0, 0, 'AC'),
(19, 7, 4, 0, 0, 0, 0, 0, 'AC'),
(20, 7, 3, 0, 0, 0, 0, 0, 'AC'),
(21, 7, 2, 0, 0, 0, 0, 0, 'AC'),
(22, 7, 1, 0, 1, 0, 0, 0, 'AC'),
(23, 6, 11, 0, 0, 0, 0, 0, 'AC'),
(24, 6, 10, 0, 0, 0, 0, 0, 'AC'),
(25, 6, 9, 0, 0, 0, 0, 0, 'AC'),
(26, 6, 8, 0, 0, 0, 0, 0, 'AC'),
(27, 6, 7, 0, 0, 0, 0, 0, 'AC'),
(28, 6, 6, 0, 0, 0, 0, 0, 'AC'),
(29, 6, 5, 0, 0, 0, 0, 0, 'AC'),
(30, 6, 4, 0, 0, 0, 0, 0, 'AC'),
(31, 6, 3, 0, 0, 0, 0, 0, 'AC'),
(32, 6, 2, 0, 0, 0, 0, 0, 'AC'),
(33, 6, 1, 0, 0, 0, 0, 0, 'AC'),
(34, 5, 11, 0, 0, 0, 0, 0, 'AC'),
(35, 5, 10, 0, 0, 0, 0, 0, 'AC'),
(36, 5, 9, 0, 0, 0, 0, 0, 'AC'),
(37, 5, 8, 0, 0, 0, 0, 0, 'AC'),
(38, 5, 7, 0, 0, 0, 0, 0, 'AC'),
(39, 5, 6, 0, 0, 0, 0, 0, 'AC'),
(40, 5, 5, 0, 0, 0, 0, 0, 'AC'),
(41, 5, 4, 0, 0, 0, 0, 0, 'AC'),
(42, 5, 3, 0, 0, 0, 0, 0, 'AC'),
(43, 5, 2, 0, 0, 0, 0, 0, 'AC'),
(44, 5, 1, 0, 0, 0, 0, 0, 'AC'),
(45, 4, 11, 0, 0, 0, 0, 0, 'AC'),
(46, 4, 10, 0, 0, 0, 0, 0, 'AC'),
(47, 4, 9, 0, 0, 0, 0, 0, 'AC'),
(48, 4, 8, 0, 0, 0, 0, 0, 'AC'),
(49, 4, 7, 0, 0, 0, 0, 0, 'AC'),
(50, 4, 6, 0, 0, 0, 0, 0, 'AC'),
(51, 4, 5, 0, 0, 0, 0, 0, 'AC'),
(52, 4, 4, 0, 0, 0, 0, 0, 'AC'),
(53, 4, 3, 0, 0, 0, 0, 0, 'AC'),
(54, 4, 2, 0, 0, 0, 0, 0, 'AC'),
(55, 4, 1, 0, 0, 0, 0, 0, 'AC'),
(56, 3, 11, 0, 0, 0, 0, 0, 'AC'),
(57, 3, 10, 0, 0, 0, 0, 0, 'AC'),
(58, 3, 9, 0, 0, 0, 0, 0, 'AC'),
(59, 3, 8, 0, 0, 0, 0, 0, 'AC'),
(60, 3, 7, 0, 0, 0, 0, 0, 'AC'),
(61, 3, 6, 0, 0, 0, 0, 0, 'AC'),
(62, 3, 5, 0, 0, 0, 0, 0, 'AC'),
(63, 3, 4, 0, 0, 0, 0, 0, 'AC'),
(64, 3, 3, 0, 0, 0, 0, 0, 'AC'),
(65, 3, 2, 0, 0, 0, 0, 0, 'AC'),
(66, 3, 1, 0, 0, 0, 0, 0, 'AC'),
(67, 2, 11, 0, 0, 0, 0, 0, 'AC'),
(68, 2, 10, 0, 1, 0, 0, 0, 'AC'),
(69, 2, 9, 0, 0, 0, 0, 0, 'AC'),
(70, 2, 8, 0, 0, 0, 0, 0, 'AC'),
(71, 2, 7, 0, 0, 0, 0, 0, 'AC'),
(72, 2, 6, 0, 0, 0, 0, 0, 'AC'),
(73, 2, 5, 0, 0, 0, 0, 0, 'AC'),
(74, 2, 4, 0, 0, 0, 0, 0, 'AC'),
(75, 2, 3, 0, 0, 0, 0, 0, 'AC'),
(76, 2, 2, 0, 0, 0, 0, 0, 'AC'),
(77, 2, 1, 0, 0, 0, 0, 0, 'AC'),
(78, 1, 12, 0, 1, 1, 1, 1, 'AC'),
(79, 1, 13, 0, 1, 1, 1, 1, 'AC'),
(80, 7, 13, 0, 0, 0, 0, 0, 'AC'),
(81, 7, 12, 0, 0, 0, 0, 0, 'AC'),
(82, 6, 13, 0, 0, 0, 0, 0, 'AC'),
(83, 6, 12, 0, 0, 0, 0, 0, 'AC'),
(84, 5, 13, 0, 0, 0, 0, 0, 'AC'),
(85, 5, 12, 0, 0, 0, 0, 0, 'AC'),
(86, 4, 13, 0, 0, 0, 0, 0, 'AC'),
(87, 4, 12, 0, 0, 0, 0, 0, 'AC'),
(88, 3, 13, 0, 0, 0, 0, 0, 'AC'),
(89, 3, 12, 0, 0, 0, 0, 0, 'AC'),
(90, 2, 13, 0, 0, 0, 0, 0, 'AC'),
(91, 2, 12, 0, 0, 0, 0, 0, 'AC'),
(92, 1, 14, 0, 1, 1, 1, 1, 'AC'),
(93, 7, 14, 0, 1, 0, 0, 0, 'AC'),
(94, 6, 14, 0, 0, 0, 0, 0, 'AC'),
(95, 5, 14, 0, 0, 0, 0, 0, 'AC'),
(96, 4, 14, 0, 0, 0, 0, 0, 'AC'),
(97, 3, 14, 0, 0, 0, 0, 0, 'AC'),
(98, 2, 14, 0, 0, 0, 0, 0, 'AC'),
(99, 1, 15, 0, 1, 1, 1, 1, 'AC'),
(100, 1, 16, 0, 1, 1, 1, 1, 'AC'),
(101, 7, 16, 0, 0, 0, 0, 0, 'AC'),
(102, 7, 15, 0, 0, 0, 0, 0, 'AC'),
(103, 6, 16, 0, 1, 0, 0, 0, 'AC'),
(104, 6, 15, 0, 0, 0, 0, 0, 'AC'),
(105, 5, 16, 0, 0, 0, 0, 0, 'AC'),
(106, 5, 15, 0, 0, 0, 0, 0, 'AC'),
(107, 4, 16, 0, 0, 0, 0, 0, 'AC'),
(108, 4, 15, 0, 1, 0, 0, 0, 'AC'),
(109, 3, 16, 0, 0, 0, 0, 0, 'AC'),
(110, 3, 15, 0, 1, 0, 0, 0, 'AC'),
(111, 2, 16, 0, 0, 0, 0, 0, 'AC'),
(112, 2, 15, 0, 0, 0, 0, 0, 'AC'),
(113, 1, 17, 0, 1, 1, 1, 1, 'AC'),
(114, 7, 17, 0, 1, 0, 0, 0, 'AC'),
(115, 6, 17, 0, 1, 0, 0, 0, 'AC'),
(116, 5, 17, 0, 1, 0, 0, 0, 'AC'),
(117, 4, 17, 0, 1, 0, 0, 0, 'AC'),
(118, 3, 17, 0, 1, 0, 0, 0, 'AC'),
(119, 2, 17, 0, 1, 0, 0, 0, 'AC'),
(120, 1, 18, 0, 1, 1, 1, 1, 'AC'),
(121, 1, 19, 0, 1, 1, 1, 1, 'AC'),
(122, 7, 19, 0, 0, 0, 0, 0, 'AC'),
(123, 7, 18, 0, 0, 0, 0, 0, 'AC'),
(124, 6, 19, 0, 0, 0, 0, 0, 'AC'),
(125, 6, 18, 0, 0, 0, 0, 0, 'AC'),
(126, 5, 19, 0, 0, 0, 0, 0, 'AC'),
(127, 5, 18, 0, 0, 0, 0, 0, 'AC'),
(128, 4, 19, 0, 1, 0, 0, 0, 'AC'),
(129, 4, 18, 0, 0, 0, 0, 0, 'AC'),
(130, 3, 19, 0, 0, 0, 0, 0, 'AC'),
(131, 3, 18, 0, 0, 0, 0, 0, 'AC'),
(132, 2, 19, 0, 0, 0, 0, 0, 'AC'),
(133, 2, 18, 0, 0, 0, 0, 0, 'AC');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pertenece`
--

DROP TABLE IF EXISTS `pertenece`;
CREATE TABLE IF NOT EXISTS `pertenece` (
`id` int(11) NOT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `grupo_id` int(11) DEFAULT NULL,
  `estado` varchar(2) DEFAULT NULL COMMENT 'Activo sera AC, No activo NC, Eliminado DE'
) ENGINE=InnoDB AUTO_INCREMENT=103 DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `pertenece`
--

INSERT INTO `pertenece` (`id`, `usuario_id`, `grupo_id`, `estado`) VALUES
(1, 1, 1, 'AC'),
(2, 2, 3, 'AC'),
(3, 3, 3, 'AC'),
(4, 4, 3, 'AC'),
(5, 5, 3, 'AC'),
(6, 6, 3, 'AC'),
(7, 7, 3, 'AC'),
(8, 8, 3, 'AC'),
(9, 9, 3, 'AC'),
(10, 10, 3, 'AC'),
(11, 11, 3, 'AC'),
(12, 12, 3, 'AC'),
(13, 13, 3, 'AC'),
(14, 14, 3, 'AC'),
(15, 15, 3, 'AC'),
(16, 16, 3, 'AC'),
(17, 17, 3, 'AC'),
(18, 18, 3, 'AC'),
(19, 19, 3, 'AC'),
(20, 20, 3, 'AC'),
(21, 21, 3, 'AC'),
(22, 22, 3, 'AC'),
(23, 23, 3, 'AC'),
(24, 24, 3, 'AC'),
(25, 25, 3, 'AC'),
(26, 26, 3, 'AC'),
(27, 27, 3, 'AC'),
(28, 28, 3, 'AC'),
(29, 29, 3, 'AC'),
(30, 30, 3, 'AC'),
(31, 31, 3, 'AC'),
(32, 32, 3, 'AC'),
(33, 33, 3, 'AC'),
(34, 34, 3, 'AC'),
(35, 35, 3, 'AC'),
(36, 36, 3, 'AC'),
(37, 37, 3, 'AC'),
(38, 38, 3, 'AC'),
(39, 39, 3, 'AC'),
(40, 40, 3, 'AC'),
(41, 41, 3, 'AC'),
(42, 42, 3, 'AC'),
(43, 43, 3, 'AC'),
(44, 44, 3, 'AC'),
(45, 45, 3, 'AC'),
(46, 46, 3, 'AC'),
(47, 47, 3, 'AC'),
(48, 48, 3, 'AC'),
(49, 49, 3, 'AC'),
(50, 50, 3, 'AC'),
(51, 51, 3, 'AC'),
(52, 52, 3, 'AC'),
(53, 53, 3, 'AC'),
(54, 54, 3, 'AC'),
(55, 55, 3, 'AC'),
(56, 56, 3, 'AC'),
(57, 57, 3, 'AC'),
(58, 58, 3, 'AC'),
(59, 59, 3, 'AC'),
(60, 60, 3, 'AC'),
(61, 61, 3, 'AC'),
(62, 62, 3, 'AC'),
(63, 63, 3, 'AC'),
(64, 64, 3, 'AC'),
(65, 65, 3, 'AC'),
(66, 66, 3, 'AC'),
(67, 67, 3, 'AC'),
(68, 68, 3, 'AC'),
(69, 69, 3, 'AC'),
(70, 70, 3, 'AC'),
(71, 71, 3, 'AC'),
(72, 72, 3, 'AC'),
(73, 73, 3, 'AC'),
(74, 74, 3, 'AC'),
(75, 75, 2, 'AC'),
(76, 76, 2, 'AC'),
(77, 77, 2, 'AC'),
(78, 78, 2, 'AC'),
(79, 79, 2, 'AC'),
(80, 80, 2, 'AC'),
(81, 81, 2, 'AC'),
(82, 82, 2, 'AC'),
(83, 83, 2, 'AC'),
(84, 84, 2, 'AC'),
(85, 85, 2, 'AC'),
(86, 86, 2, 'AC'),
(87, 87, 2, 'AC'),
(88, 88, 2, 'AC'),
(89, 89, 2, 'AC'),
(90, 90, 2, 'AC'),
(91, 91, 2, 'AC'),
(92, 92, 2, 'AC'),
(93, 93, 2, 'AC'),
(94, 5, 7, 'AC'),
(95, 94, 2, 'AC'),
(96, 95, 4, 'AC'),
(97, 96, 2, 'AC'),
(98, 97, 2, 'AC'),
(99, 98, 2, 'AC'),
(100, 4, 6, 'AC'),
(102, 100, 2, 'AC');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `proyecto`
--

DROP TABLE IF EXISTS `proyecto`;
CREATE TABLE IF NOT EXISTS `proyecto` (
`id` int(11) NOT NULL,
  `modalidad_id` int(11) DEFAULT NULL,
  `carrera_id` int(11) DEFAULT NULL,
  `institucion_id` int(11) DEFAULT NULL,
  `nombre` varchar(1500) DEFAULT 'Sin Titulo',
  `numero_asignado` varchar(45) DEFAULT NULL,
  `objetivo_general` text,
  `descripcion` text,
  `director_carrera` varchar(300) DEFAULT NULL,
  `docente_materia` varchar(300) DEFAULT NULL,
  `registro_tutor` varchar(300) DEFAULT NULL,
  `fecha_registro` date DEFAULT NULL,
  `registrado_por` varchar(300) DEFAULT NULL,
  `responsable` varchar(300) DEFAULT NULL,
  `trabajo_conjunto` varchar(2) DEFAULT NULL COMMENT 'si es trabajo conjunto (TC) o si es trabajo solitario (TS)',
  `asignacion_tribunal` varchar(45) DEFAULT NULL,
  `asignacion_defensa` varchar(45) DEFAULT NULL,
  `es_actual` tinyint(4) DEFAULT NULL COMMENT 'si es que este proyecto es el proyecto actual del estudiante o no',
  `tipo_proyecto` varchar(2) DEFAULT 'PR' COMMENT 'Tipo perfil (PE), tipo Proyecto Final (PR)',
  `estado_proyecto` varchar(2) DEFAULT NULL COMMENT 'Iniciado (IN), Visto Bueno de Docente, Tutores y Revisores (VB) , TRibunales asignados (TA), tribunales Visto Bueno (TV), con defensa (LD)',
  `estado` varchar(2) DEFAULT NULL COMMENT 'Activo sera AC, No activo NC, Eliminado DE'
) ENGINE=InnoDB AUTO_INCREMENT=45 DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `proyecto`
--

INSERT INTO `proyecto` (`id`, `modalidad_id`, `carrera_id`, `institucion_id`, `nombre`, `numero_asignado`, `objetivo_general`, `descripcion`, `director_carrera`, `docente_materia`, `registro_tutor`, `fecha_registro`, `registrado_por`, `responsable`, `trabajo_conjunto`, `asignacion_tribunal`, `asignacion_defensa`, `es_actual`, `tipo_proyecto`, `estado_proyecto`, `estado`) VALUES
(1, 1, 1, 0, 'Evaluación de Calidad Automatizado del Sistema Integrado de Cobros del Consumo de Agua y Otros Cobros, para la Cooperativa de Servicios de Agua Potable Llauquinquiri', '1', 'Controlar la calidad del Sistema Integrado de Cobros del consumo de Agua y Otros cobros, para la Cooperativa de Servicios de Agua Potable Llauquinquiri mediante el Testeo, basados en metodologías y herramientas formales de la\r\nIngeniería de Calidad.', 'Cuando se habla de desarrollo de software hecho a medida implica el cumplir los requerimientos que\r\nsolicita el cliente, satisfacer sus necesidades y, de manera general, cumplir con estándares en su implementación. Como\r\nresultado de esta implementación hecha a medida implica que existan más errores, esto hace que sea irrelevante\r\nrealizar un control de calidad, que asegure que el software obtenido tenga la menor cantidad de errores.\r\nDebido a la falta de tiempo para la ejecución de pruebas más exhaustivas, falta de investigación de técnicas más\r\nformales relacionadas a la Ingeniería de Calidad, surge la necesidad de desarrollar un Control de Calidad formal al\r\nSistema Integrado de Cobros del consumo de Agua y Otros Cobros, para la Cooperativa de Servicios de Agua Potable\r\nLlauquinquiri  a la conclusión de su primera versión, con un Testeo formal con la aplicación de metodologías que nos\r\naseguren la calidad del mismo.', 'Director Sistemas', 'ING. JOSE RICHARD AYOROA CARDOZO', NULL, '2013-11-06', 'EST. ISMAEL NOEL FLORES GUTIéRREZ', '-- Seleccione --', 'TS', NULL, NULL, 0, 'PE', 'CO', 'AC'),
(2, 1, 1, 0, 'Evaluación de Calidad Automatizado del Sistema Integrado de Cobros del Consumo de Agua y Otros Cobros, para la Cooperativa de Servicios de Agua Potable Llauquinquiri', '2', 'Controlar la calidad del Sistema Integrado de Cobros del consumo de Agua y Otros cobros, para la Cooperativa de\r\nServicios de Agua Potable Llauquinquiri mediante el Testeo, basados en metodologías y herramientas formales de la\r\nIngeniería de Calidad', 'Cuando se habla de desarrollo de software hecho a medida implica el cumplir los requerimientos que\r\nsolicita el cliente, satisfacer sus necesidades y, de manera general, cumplir con estándares en su implementación. Como\r\nresultado de esta implementación hecha a medida implica que existan más errores, esto hace que sea irrelevante\r\nrealizar un control de calidad, que asegure que el software obtenido tenga la menor cantidad de errores', 'Director Sistemas', 'ING. JOSE RICHARD AYOROA CARDOZO', NULL, '2013-11-06', 'EST. RICHARD FLORES VALLEJOS', '-- Seleccione --', 'TS', NULL, NULL, 0, 'PE', 'CO', 'AC'),
(3, 1, 1, 0, 'Aplicación de herramientas y técnicas de posicionamiento web, a un portal web de venta de libros On-Line', '', 'Aplicar herramientas y técnicas para mejorar el posicionamiento de sitios web que\r\nse dedican a la venta de libros On-Line.', 'El mayor problema que existe con algunos portales web que se dedican al comercio online\r\nes que no pueden ser encontrados por los buscadores, por tanto recibe pocas visitas, además la\r\ninformación que contienen estos portales no cumplen con lo que buscan los usuarios.\r\nPodemos decir que un portal web que no tiene visitas necesariamente desaparece por así decirlo\r\n(queda en el olvido).\r\nPara que esto no ocurra aplicaremos herramientas y técnicas de posicionamiento, para que los\r\nbuscadores puedan encontrar al portal web y este quede posicionado.', 'Director Sistemas', 'ING. JOSE RICHARD AYOROA CARDOZO', NULL, '2013-11-06', 'EST. CAROLAY GIANCARLA MONTAñO LóPEZ', '-- Seleccione --', 'TS', NULL, NULL, 0, 'PE', 'CO', 'AC'),
(4, 3, 1, 0, 'SISTEMA DE CONTROL DE ATERRIZAJES, ESTACIONAMIENTOS, SOBREVUELOS Y COMBUSTIBLE', '4', 'DESARROLLAR UN SISTEMA DE CONTROL DE ATERRIZAJES,\r\nESTACIONAMIENTOS, COMBUSTIBLES, SOBREVUELOS Y LOS GASTOS QUE ESTOS\r\nREPRESENTAN PARA LA EMPRESA BOLIVIANA DE AVIACIÓN (BOA).', ': Debido al gran crecimiento que ha tenido Boliviana de Aviación en los últimos tiempos, la\r\ncantidad de vuelos que realiza se ha visto muy incrementada, por lo que también se han incrementado\r\nlos controles sobre sus actividades operativas como son los Aterrizajes, Estacionamientos, Sobrevuelos y\r\ncargas de combustible. En la actualidad, los encargados de realizar controles de estas actividades lo\r\nrealizan de manera manual, labores muy complejas y que consumen mucho tiempo.', 'Director Sistemas', 'ING. JOSE RICHARD AYOROA CARDOZO', NULL, '2013-11-06', 'EST. BADDY QUISBERT VILLARROEL', '-- Seleccione --', 'TS', NULL, NULL, 0, 'PE', 'CO', 'AC'),
(5, 3, 1, 0, 'Sistema de Cobranza en Línea para la Empresa Nacional de Electricidad Corporación', '5', 'Desarrollar un sistema de cobranza en línea para la empresa ENDE Corporación,\r\nque permita obtener información en línea de todas sus regionales de distribución eléctrica en el país.', 'El módulo de Cobranzas es una de las áreas importantes dentro de la empresa por la que se requiere\r\nincrementar la rapidez en la manipulación y obtención de esta información ya que esta información no es accedida de\r\nmanera eficiente.\r\nLa información que brindara, permitirá realizar procesos del área cobranzas, también permitirá obtener información de\r\nlos clientes de la empresa de las deudas que tiene estos y los puntos donde puede realizar los pagos. De esta manera se\r\npretende dar solución al problema de incrementar la rapidez en la manipulación y obtención de la información del área de\r\ncobranza.', 'Director Sistemas', 'ING. JOSE RICHARD AYOROA CARDOZO', NULL, '2013-11-06', 'EST. RIMBERTH VILLCA MAIZA', '-- Seleccione --', 'TS', NULL, NULL, 0, 'PE', 'CO', 'AC'),
(6, 2, 1, 1, 'Sistema Web de Propagación de Resultados Obtenidos en el Instituto de Investigaciones de Arquitectura y Ciencias del Hábitat (IIACH) de la Universidad Mayor de San Simón (UMSS)', '', 'Coadyuvar en la difusión de los resultados obtenidos del Instituto de Investigaciones de Arquitectura y Ciencias del Hábitat\r\n(IIACH) de la Universidad Mayor de San Simón (UMSS), mediante un sistema web que provea de información a la comunidad\r\nuniversitaria y la sociedad civil.', 'Actualmente con el avance de la tecnología, especialmente en los medios de difusión de noticias, avisos, artículos,\r\nproyectos, etc. los centros de investigación, universidades e incluso empresas mismas se ven en la obligación de hacerse participe\r\nde este progreso, ya sea para beneficio propio, como de los usuarios que requieran la información que las diferentes instituciones\r\ndel medio manejan.\r\nNo lejos de la situación, encontramos el Instituto de Investigaciones de Arquitectura y Ciencias del Hábitat (IIACH) quienes se ven\r\nen la necesidad de brindar a la sociedad toda la información que maneja resultante de su ardua tarea: artículos, imágenes en alta\r\ncalidad, datos de los resultados obtenidos en las investigaciones, informes sobre los proyectos, encuestas, en fin una amplia\r\nvariedad de información la cual se desea dar a conocer al público en general', 'Director Sistemas', 'ING. JOSE RICHARD AYOROA CARDOZO', NULL, '2013-11-06', 'EST. MAURICIO HENRY BARRIENTOS ROJAS', '-- Seleccione --', 'TS', NULL, NULL, 0, 'PE', 'CO', 'AC'),
(7, 1, 1, 0, 'Evaluación de la calidad del Sistema de E-vote auto verificable con apoyo de una herramienta de automatización.', '7', 'Evaluar la calidad del Sistema E-vote auto verificable mediante estándares de calidad y una\r\nherramienta de automatización', 'En la actualidad, en el mundo del software uno de los requisitos principales es lograr que el producto\r\nsea de calidad. Éste proyecto pretende evaluar la calidad del  Sistema de E-vote auto verificable\r\nmediante estándares y procesos de Control de Calidad para poder conocer su funcionamiento actual y\r\ndeterminar si cumple con los objetivos para los que fue creado.', 'Director Sistemas', 'ING. JOSE RICHARD AYOROA CARDOZO', NULL, '2013-11-06', 'EST. GUYEN UMAñA CAMPERO', '-- Seleccione --', 'TS', NULL, NULL, 0, 'PE', 'CO', 'AC'),
(8, 1, 1, 0, 'SISTEMA ADMINISTRATIVO PARA EL SERVICIO DE COBRANZA DE AGUA POTABLE', '', 'Desarrollar un Sistema de Software para las Asociación de Agua Potable, con la que logren una\r\nadministración eficiente y eficaz en la prestación del servicio', 'Con el crecimiento de la población y la demanda de usuarios que requieren el servicio de agua\r\npotable, es muy complicado llevar un control al 100  seguro con lo que respecta a los servicios\r\nprestados, usuarios beneficiados con el servicio, la parte económica, etc.\r\nPor lo cual se desarrollara un Sistema de Software para las Asociación de Agua Potable, con la que\r\nlogre una administración eficiente y eficaz en la prestación del servicio', 'Director Sistemas', '-- Seleccione --', NULL, '2013-11-06', 'EST. LIONED YURI ROCA ROCA', '-- Seleccione --', 'TS', NULL, NULL, 0, 'PE', 'CO', 'AC'),
(9, 1, 0, 0, 'Desarrollo de un sistema en línea de pedidos indumentarios utilizando el framework Code Igniter.', '9', 'Desarrollar un Sistema en línea para pedidos de pantalones de vestir utilizando el Framework Code\r\nIgniter.', 'El proyecto presentado tiene como meta el desarrollo de un sistema de pedidos en línea,\r\npara que los usuarios que normalmente necesitan tener presencia física en la empresa, puedan acceder a la\r\npagina desde el lugar donde se encuentren y ahí realizar sus pedidos de forma fácil, rápida, segura y\r\ncómoda donde cada producto tendrá sus características y estas podrán ser modificadas por el\r\nadministrador. De esta forma automatizar los procesos manuales que actualmente utilizan varias empresas.', 'Director Sistemas', '-- Seleccione --', NULL, '2013-11-06', 'EST. ANGéLICA CABALLERO DELGADILLO', '-- Seleccione --', 'TS', NULL, NULL, 0, 'PE', 'CO', 'AC'),
(10, 2, 0, 0, 'Desarrollo de un Sitio web para la Facultad de Bioquímica y Farmacia', '10', 'Diseñar e Implementar un sitio Web, con características dinámicas y estáticas, que brinde información\r\nactualizada y relevante de las actividades académicas y administrativas de la Facultad de Bioquímica y Farmacia.', 'La Facultad de Bioquímica y Farmacia, es una unidad académica que brinda servicios a la población\r\nuniversitaria y público en general, a través de sus laboratorios de análisis clínicos, farmacia, biblioteca, centros de\r\ninvestigación y producción, además de, gestionar sus actividades académicas. Cada uno de estas entidades requieren que su\r\ninformación, pueda ser difundida de manera inmediata y eficaz. En la actualidad los sitios web son una alternativa eficiente\r\nque permiten gestionar, almacenar, intercambiar y publicar la información. Es de vital importancia, para la Facultad de\r\nBioquímica y Farmacia, disponer de un Sitio Web para brindar su información actualizada, confiable y de publicación\r\ninmediata, más aun teniendo en cuenta que posee los recursos físicos necesarios para implementar su propio Sitio Web.', 'Director Sistemas', '-- Seleccione --', NULL, '2013-11-06', 'EST. ELIANA BAZOALTO LOPEZ', '-- Seleccione --', 'TS', NULL, NULL, 0, 'PE', 'CO', 'AC'),
(11, 2, 1, 1, 'SISTEMA PARA DAR SOPORTE AL PROCESO DE TITULACION Y A LAS MATERIAS DE PERFIL Y PROYECTO FINAL', '11', 'Realizar un sistema de software que ayude en el proceso de titulación en la carrera\r\nde Licenciatura en Ingeniería De Sistemas.', 'El proceso de titulación actual en la carrera de Licenciatura en Ingeniería de Sistemas presenta\r\ndemoras en los plazos que se deben cumplir de acuerdo a las normas vigentes en la Gestión I - 2013,\r\nestos retrasos y no cumplimiento de términos perjudican el proceso de titulación de los estudiantes\r\nque cursan los últimos semestres de la carrera de Licenciatura en Ingeniería de Sistemas.', 'Director Sistemas', 'ING. JOSE RICHARD AYOROA CARDOZO', NULL, '2013-11-06', 'EST. URVY DIANET CALLE MARCA', '-- Seleccione --', 'TS', NULL, NULL, 0, 'PE', 'CO', 'AC'),
(12, 2, 1, 1, 'Sistema de apoyo para la mejora de la administración de la producción de cereales en PYMES', '12', 'Coadyuvar en la mejora de la administración de la producción de cereales en PYMES, con el\r\ndesarrollo de una herramienta de software que le permita administrar y conjuntamente reducir\r\npérdidas económicas.', 'En la actualidad las pequeñas empresas tienen un sistema deficiente para la planificación de su\r\nproducción, muchas veces de manera empírica; también tienes problemas con sus sistemas de apoyo.\r\nLa implementación de esta herramienta busca dar un apoyo a los pequeños y medianos empresarios\r\ncon sus problemas de administración y gestión de la producción.', 'Director Sistemas', 'ING. JOSE RICHARD AYOROA CARDOZO', NULL, '2013-11-06', 'EST. LIONEL AYAVIRI SEJAS', '-- Seleccione --', 'TS', NULL, NULL, 0, 'PE', 'CO', 'AC'),
(13, 1, 1, 0, 'SISTEMA DE GESTION ERP PARA TALLERES DE SERVICIO AUTOMOTRIZ', '', 'Desarrollar un Sistema de Información ERP para soporte de procesos de gestión para empresas de servicio automotriz.', 'El presente proyecto de grado tiene como área de investigación los sistemas ERP\r\naplicado a instituciones de servicios Automotrices, ya que estos sistemas de gestión empresarial están\r\ndiseñados para modelar y automatizar los procesos fundamentales. Las instituciones que brindan\r\nservicio automotriz de Cochabamba requieren de los beneficios que un sistema ERP puede ofrecerle,\r\nen cuanto al manejo de la información y la integración entre las áreas existentes y su comunicación.', 'Director Sistemas', '-- Seleccione --', NULL, '2013-11-06', 'EST. GRISELDA ANNEL PACA MENESES', '-- Seleccione --', 'TS', NULL, NULL, 0, 'PE', 'CO', 'AC'),
(14, 3, 1, 0, 'Sistema de información web para administración de la Residencia Universitaria Femenina Los Molles', '', 'Construir un sistema de información Web para la administración de los servicios y\r\nactividades en la Residencia Universitaria Femenina Los Molles aplicando workflow.', 'El proyecto consistirá en la implementación de un sistema de información web, que facilite y sea más fiable la\r\ntarea de administración, hasta el momento se realiza de manera manual. Se implementará una base de datos\r\ncon los datos necesarios para su prueba, el diseño e implementación de la interfaz gráfica, la implementación\r\nde la funcionalidad requerida. Permitirá mostrar la información deseada de modo que pueda ser vista en\r\ncualquier parte por las personas interesadas.', 'Director Sistemas', 'ING. JOSE RICHARD AYOROA CARDOZO', NULL, '2013-11-06', 'EST. ANGELA ELIANA BORDA DAVILA', '-- Seleccione --', 'TS', NULL, NULL, 0, 'PE', 'CO', 'AC'),
(15, 2, 0, 1, 'PÁGINA WEB INTERACTIVA PARA LA CARRERA DE CIENCIAS DE LA EDUCACIÓN.', '', 'SISTEMA WEB INTERACTIVA PARA LA CARRERA DE CIENCIAS DE LA\r\nEDUCACIÓN', 'La incorporación de una página web en la carrera funcionará como un canal de comunicación que nos acerca a los\r\nestudiantes, docentes y público en general. Ya que la sociedad requiere que la información de algunas instituciones como\r\nla Universidad se encuentre disponible, incluso para usuarios externos. Estos sistemas de información son un recurso vital\r\npara la correcta toma de decisiones, que en determinado momento concluye en una ventaja competitiva. El usuario\r\ninteracciona con las aplicaciones web a través del navegador.\r\nLas páginas interactivas con acceso a datos permiten interactuar con la información de una base de datos ya sea para\r\nobtener información y mostrar al usuario o bien para actualizar su contenido.', 'Director Sistemas', '-- Seleccione --', NULL, '2013-11-06', 'EST. CARLOS ANDRÉS BURGOS UREY', '-- Seleccione --', 'TS', NULL, NULL, 0, 'PE', 'CO', 'AC'),
(16, 3, 0, 0, 'PÁGINA WEB INTERACTIVA PARA LA CARRERA DE CIENCIAS DE LA EDUCACIÓN.', '', 'Objetivo general: Implementar un SISTEMA WEB INTERACTIVA PARA LA CARRERA DE CIENCIAS DE LA EDUCACIÓN', 'La incorporación de una página web en la carrera funcionará como un canal de comunicación que nos acerca a los\r\nestudiantes, docentes y público en general. Ya que la sociedad requiere que la información de algunas instituciones como\r\nla Universidad se encuentre disponible, incluso para usuarios externos. Estos sistemas de información son un recurso vital\r\npara la correcta toma de decisiones, que en determinado momento concluye en una ventaja competitiva. El usuario\r\ninteracciona con las aplicaciones web a través del navegador.\r\nLas páginas interactivas con acceso a datos permiten interactuar con la información de una base de datos ya sea para\r\nobtener información y mostrar al usuario o bien para actualizar su contenido.', 'Director Sistemas', '-- Seleccione --', NULL, '2013-11-06', 'EST. SHIRLEY JHOVANA  PINTO', '-- Seleccione --', 'TS', NULL, NULL, 0, 'PE', 'CO', 'AC'),
(17, 3, 0, 0, 'Sistema Web de Propagación de Resultados Obtenidos en el Instituto de Investigaciones de Arquitectura y Ciencias del Hábitat (IIACH) de la Universidad Mayor de San Simón (UMSS).', '', 'Coadyuvar en la difusión de los resultados obtenidos del Instituto de Investigaciones de Arquitectura y Ciencias del Hábitat\r\n(IIACH) de la Universidad Mayor de San Simón (UMSS), mediante un sistema web que provea de información a la comunidad\r\nuniversitaria y la sociedad civil.', 'Actualmente con el avance de la tecnología, especialmente en los medios de difusión de noticias, avisos,\r\nartículos, proyectos, etc, los centros de investigación, universidades e incluso empresas mismas se ven en la obligación de\r\nhacerse participe de este progreso, ya sea para beneficio propio, como de los usuarios que requieran la información que las\r\ndiferentes instituciones del medio manejan.', 'Director Sistemas', 'ING. JOSE RICHARD AYOROA CARDOZO', NULL, '2013-11-06', 'EST. GARY RICHARD VERA TERRAZAS', '-- Seleccione --', 'TS', NULL, NULL, 0, 'PE', 'CO', 'AC'),
(18, 1, 1, 0, 'Sistema de Información para el control de ventas de una empresa de Sombreros', '', 'Desarrollar un Sistema de Información para el control de ventas de una empresa de Sombreros\r\nutilizando framework CodeIgniter.', 'Actualmente algunas Empresas de venta de Sombreros no realizan un control adecuado de sus\r\nproductos dentro el almacén, incurriendo de esta manera en la perdida de información, algunas de las causas principales\r\npara no realizar un control adecuado es la cantidad de ingreso y la cantidad de salida realizada, y además que realizar un\r\ncontrol manual es muy moroso, dificultoso y poco eficiente. lo cuan genera un problema a realizar la búsqueda de pedidos\r\nhecho por los cliente lo cual se registran en un libro de pedidos donde a veces no se hace la entrega total del pedido y esto\r\nno se registra como un falta de entrega lo cual perjudica al cliente porque tiene que realizar otro pedido y es para otra\r\nfecha.', 'Director Sistemas', 'ING. JOSE RICHARD AYOROA CARDOZO', NULL, '2013-11-06', 'EST. SEGUNDINO GASTÓN FERNANDEZ FLORES', '-- Seleccione --', 'TS', NULL, NULL, 0, 'PE', 'CO', 'AC'),
(19, 3, 1, 0, 'Portal Web para la venta de libros On-Line, utilizando herramientas y técnicas de posicionamiento web', '', 'Desarrollar un Portal Web para la venta de libros On-Line, utilizando\r\nherramientas y técnicas de posicionamiento web', 'Actualmente las pequeñas y medianas empresas progresan a través de sus clientes, sino\r\nexisten clientelas por ende las empresas entran en desaparición. Es por este motivo la realización de\r\neste proyecto que está orientado para la venta de libros On-Line, el cual pueda realizar un control de la\r\nadministración de las ventas de libros y la administración existente de los libros para la venta directa\r\ncon el cliente, e integrando el portal web puesta en servidores en dominio gratuito; a este se aplicarán\r\ntécnicas y estrategias de posicionamiento web con el propósito de darnos a conocer para que tenga\r\néxito en la vitrina más grande del mundo La Red Global Mundial internet.', 'Director Sistemas', '-- Seleccione --', NULL, '2013-11-06', 'EST. MARCELO MARCOS VARGAS CHAVEZ', '-- Seleccione --', 'TS', NULL, NULL, 0, 'PE', 'CO', 'AC'),
(20, 1, 1, 0, 'Evaluación de Calidad Automatizado del Sistema Integrado de Cobros del Consumo de Agua y Otros Cobros, para la Cooperativa de Servicios de Agua Potable Llauquinquiri', '1', 'Controlar la calidad del Sistema Integrado de Cobros del consumo de Agua y Otros cobros, para la Cooperativa de Servicios de Agua Potable Llauquinquiri mediante el Testeo, basados en metodologías y herramientas formales de la\r\nIngeniería de Calidad.', 'Cuando se habla de desarrollo de software hecho a medida implica el cumplir los requerimientos que\r\nsolicita el cliente, satisfacer sus necesidades y, de manera general, cumplir con estándares en su implementación. Como\r\nresultado de esta implementación hecha a medida implica que existan más errores, esto hace que sea irrelevante\r\nrealizar un control de calidad, que asegure que el software obtenido tenga la menor cantidad de errores.\r\nDebido a la falta de tiempo para la ejecución de pruebas más exhaustivas, falta de investigación de técnicas más\r\nformales relacionadas a la Ingeniería de Calidad, surge la necesidad de desarrollar un Control de Calidad formal al\r\nSistema Integrado de Cobros del consumo de Agua y Otros Cobros, para la Cooperativa de Servicios de Agua Potable\r\nLlauquinquiri  a la conclusión de su primera versión, con un Testeo formal con la aplicación de metodologías que nos\r\naseguren la calidad del mismo.', 'Director Sistemas', 'ING. JOSE RICHARD AYOROA CARDOZO', NULL, '2013-11-06', 'EST. ISMAEL NOEL FLORES GUTIéRREZ', '-- Seleccione --', 'TS', NULL, NULL, 1, 'PR', 'IN', 'AC'),
(21, 1, 1, 0, 'Evaluación de Calidad Automatizado del Sistema Integrado de Cobros del Consumo de Agua y Otros Cobros, para la Cooperativa de Servicios de Agua Potable Llauquinquiri', '2', 'Controlar la calidad del Sistema Integrado de Cobros del consumo de Agua y Otros cobros, para la Cooperativa de\r\nServicios de Agua Potable Llauquinquiri mediante el Testeo, basados en metodologías y herramientas formales de la\r\nIngeniería de Calidad', 'Cuando se habla de desarrollo de software hecho a medida implica el cumplir los requerimientos que\r\nsolicita el cliente, satisfacer sus necesidades y, de manera general, cumplir con estándares en su implementación. Como\r\nresultado de esta implementación hecha a medida implica que existan más errores, esto hace que sea irrelevante\r\nrealizar un control de calidad, que asegure que el software obtenido tenga la menor cantidad de errores', 'Director Sistemas', 'ING. JOSE RICHARD AYOROA CARDOZO', NULL, '2013-11-06', 'EST. RICHARD FLORES VALLEJOS', '-- Seleccione --', 'TS', NULL, NULL, 1, 'PR', 'IN', 'AC'),
(22, 1, 1, 0, 'Aplicación de herramientas y técnicas de posicionamiento web, a un portal web de venta de libros On-Line', '', 'Aplicar herramientas y técnicas para mejorar el posicionamiento de sitios web que\r\nse dedican a la venta de libros On-Line.', 'El mayor problema que existe con algunos portales web que se dedican al comercio online\r\nes que no pueden ser encontrados por los buscadores, por tanto recibe pocas visitas, además la\r\ninformación que contienen estos portales no cumplen con lo que buscan los usuarios.\r\nPodemos decir que un portal web que no tiene visitas necesariamente desaparece por así decirlo\r\n(queda en el olvido).\r\nPara que esto no ocurra aplicaremos herramientas y técnicas de posicionamiento, para que los\r\nbuscadores puedan encontrar al portal web y este quede posicionado.', 'Director Sistemas', 'ING. JOSE RICHARD AYOROA CARDOZO', NULL, '2013-11-06', 'EST. CAROLAY GIANCARLA MONTAñO LóPEZ', '-- Seleccione --', 'TS', NULL, NULL, 1, 'PR', 'IN', 'AC'),
(23, 3, 1, 0, 'SISTEMA DE CONTROL DE ATERRIZAJES, ESTACIONAMIENTOS, SOBREVUELOS Y COMBUSTIBLE', '4', 'DESARROLLAR UN SISTEMA DE CONTROL DE ATERRIZAJES,\r\nESTACIONAMIENTOS, COMBUSTIBLES, SOBREVUELOS Y LOS GASTOS QUE ESTOS\r\nREPRESENTAN PARA LA EMPRESA BOLIVIANA DE AVIACIÓN (BOA).', ': Debido al gran crecimiento que ha tenido Boliviana de Aviación en los últimos tiempos, la\r\ncantidad de vuelos que realiza se ha visto muy incrementada, por lo que también se han incrementado\r\nlos controles sobre sus actividades operativas como son los Aterrizajes, Estacionamientos, Sobrevuelos y\r\ncargas de combustible. En la actualidad, los encargados de realizar controles de estas actividades lo\r\nrealizan de manera manual, labores muy complejas y que consumen mucho tiempo.', 'Director Sistemas', 'ING. JOSE RICHARD AYOROA CARDOZO', NULL, '2013-11-06', 'EST. BADDY QUISBERT VILLARROEL', '-- Seleccione --', 'TS', NULL, NULL, 1, 'PR', 'IN', 'AC'),
(24, 3, 1, 0, 'Sistema de Cobranza en Línea para la Empresa Nacional de Electricidad Corporación', '5', 'Desarrollar un sistema de cobranza en línea para la empresa ENDE Corporación,\r\nque permita obtener información en línea de todas sus regionales de distribución eléctrica en el país.', 'El módulo de Cobranzas es una de las áreas importantes dentro de la empresa por la que se requiere\r\nincrementar la rapidez en la manipulación y obtención de esta información ya que esta información no es accedida de\r\nmanera eficiente.\r\nLa información que brindara, permitirá realizar procesos del área cobranzas, también permitirá obtener información de\r\nlos clientes de la empresa de las deudas que tiene estos y los puntos donde puede realizar los pagos. De esta manera se\r\npretende dar solución al problema de incrementar la rapidez en la manipulación y obtención de la información del área de\r\ncobranza.', 'Director Sistemas', 'ING. JOSE RICHARD AYOROA CARDOZO', NULL, '2013-11-06', 'EST. RIMBERTH VILLCA MAIZA', '-- Seleccione --', 'TS', NULL, NULL, 1, 'PR', 'IN', 'AC'),
(25, 2, 1, 1, 'Sistema Web de Propagación de Resultados Obtenidos en el Instituto de Investigaciones de Arquitectura y Ciencias del Hábitat (IIACH) de la Universidad Mayor de San Simón (UMSS)', '', 'Coadyuvar en la difusión de los resultados obtenidos del Instituto de Investigaciones de Arquitectura y Ciencias del Hábitat\r\n(IIACH) de la Universidad Mayor de San Simón (UMSS), mediante un sistema web que provea de información a la comunidad\r\nuniversitaria y la sociedad civil.', 'Actualmente con el avance de la tecnología, especialmente en los medios de difusión de noticias, avisos, artículos,\r\nproyectos, etc. los centros de investigación, universidades e incluso empresas mismas se ven en la obligación de hacerse participe\r\nde este progreso, ya sea para beneficio propio, como de los usuarios que requieran la información que las diferentes instituciones\r\ndel medio manejan.\r\nNo lejos de la situación, encontramos el Instituto de Investigaciones de Arquitectura y Ciencias del Hábitat (IIACH) quienes se ven\r\nen la necesidad de brindar a la sociedad toda la información que maneja resultante de su ardua tarea: artículos, imágenes en alta\r\ncalidad, datos de los resultados obtenidos en las investigaciones, informes sobre los proyectos, encuestas, en fin una amplia\r\nvariedad de información la cual se desea dar a conocer al público en general', 'Director Sistemas', 'ING. JOSE RICHARD AYOROA CARDOZO', NULL, '2013-11-06', 'EST. MAURICIO HENRY BARRIENTOS ROJAS', '-- Seleccione --', 'TS', NULL, NULL, 1, 'PR', 'IN', 'AC'),
(26, 1, 1, 0, 'Evaluación de la calidad del Sistema de E-vote auto verificable con apoyo de una herramienta de automatización.', '7', 'Evaluar la calidad del Sistema E-vote auto verificable mediante estándares de calidad y una\r\nherramienta de automatización', 'En la actualidad, en el mundo del software uno de los requisitos principales es lograr que el producto\r\nsea de calidad. Éste proyecto pretende evaluar la calidad del  Sistema de E-vote auto verificable\r\nmediante estándares y procesos de Control de Calidad para poder conocer su funcionamiento actual y\r\ndeterminar si cumple con los objetivos para los que fue creado.', 'Director Sistemas', 'ING. JOSE RICHARD AYOROA CARDOZO', NULL, '2013-11-06', 'EST. GUYEN UMAñA CAMPERO', '-- Seleccione --', 'TS', NULL, NULL, 1, 'PR', 'IN', 'AC'),
(27, 1, 1, 0, 'SISTEMA ADMINISTRATIVO PARA EL SERVICIO DE COBRANZA DE AGUA POTABLE', '', 'Desarrollar un Sistema de Software para las Asociación de Agua Potable, con la que logren una\r\nadministración eficiente y eficaz en la prestación del servicio', 'Con el crecimiento de la población y la demanda de usuarios que requieren el servicio de agua\r\npotable, es muy complicado llevar un control al 100  seguro con lo que respecta a los servicios\r\nprestados, usuarios beneficiados con el servicio, la parte económica, etc.\r\nPor lo cual se desarrollara un Sistema de Software para las Asociación de Agua Potable, con la que\r\nlogre una administración eficiente y eficaz en la prestación del servicio', 'Director Sistemas', '-- Seleccione --', NULL, '2013-11-06', 'EST. LIONED YURI ROCA ROCA', '-- Seleccione --', 'TS', NULL, NULL, 1, 'PR', 'IN', 'AC'),
(28, 1, 0, 0, 'Desarrollo de un sistema en línea de pedidos indumentarios utilizando el framework Code Igniter.', '9', 'Desarrollar un Sistema en línea para pedidos de pantalones de vestir utilizando el Framework Code\r\nIgniter.', 'El proyecto presentado tiene como meta el desarrollo de un sistema de pedidos en línea,\r\npara que los usuarios que normalmente necesitan tener presencia física en la empresa, puedan acceder a la\r\npagina desde el lugar donde se encuentren y ahí realizar sus pedidos de forma fácil, rápida, segura y\r\ncómoda donde cada producto tendrá sus características y estas podrán ser modificadas por el\r\nadministrador. De esta forma automatizar los procesos manuales que actualmente utilizan varias empresas.', 'Director Sistemas', '-- Seleccione --', NULL, '2013-11-06', 'EST. ANGéLICA CABALLERO DELGADILLO', '-- Seleccione --', 'TS', NULL, NULL, 1, 'PR', 'IN', 'AC'),
(29, 2, 0, 0, 'Desarrollo de un Sitio web para la Facultad de Bioquímica y Farmacia', '10', 'Diseñar e Implementar un sitio Web, con características dinámicas y estáticas, que brinde información\r\nactualizada y relevante de las actividades académicas y administrativas de la Facultad de Bioquímica y Farmacia.', 'La Facultad de Bioquímica y Farmacia, es una unidad académica que brinda servicios a la población\r\nuniversitaria y público en general, a través de sus laboratorios de análisis clínicos, farmacia, biblioteca, centros de\r\ninvestigación y producción, además de, gestionar sus actividades académicas. Cada uno de estas entidades requieren que su\r\ninformación, pueda ser difundida de manera inmediata y eficaz. En la actualidad los sitios web son una alternativa eficiente\r\nque permiten gestionar, almacenar, intercambiar y publicar la información. Es de vital importancia, para la Facultad de\r\nBioquímica y Farmacia, disponer de un Sitio Web para brindar su información actualizada, confiable y de publicación\r\ninmediata, más aun teniendo en cuenta que posee los recursos físicos necesarios para implementar su propio Sitio Web.', 'Director Sistemas', '-- Seleccione --', NULL, '2013-11-06', 'EST. ELIANA BAZOALTO LOPEZ', '-- Seleccione --', 'TS', NULL, NULL, 1, 'PR', 'IN', 'AC'),
(30, 2, 1, 1, 'SISTEMA PARA DAR SOPORTE AL PROCESO DE TITULACION Y A LAS MATERIAS DE PERFIL Y PROYECTO FINAL', '11', 'Realizar un sistema de software que ayude en el proceso de titulación en la carrera\r\nde Licenciatura en Ingeniería De Sistemas.', 'El proceso de titulación actual en la carrera de Licenciatura en Ingeniería de Sistemas presenta\r\ndemoras en los plazos que se deben cumplir de acuerdo a las normas vigentes en la Gestión I - 2013,\r\nestos retrasos y no cumplimiento de términos perjudican el proceso de titulación de los estudiantes\r\nque cursan los últimos semestres de la carrera de Licenciatura en Ingeniería de Sistemas.', 'Director Sistemas', 'ING. JOSE RICHARD AYOROA CARDOZO', NULL, '2013-11-06', 'EST. URVY DIANET CALLE MARCA', '-- Seleccione --', 'TS', NULL, NULL, 1, 'PR', 'IN', 'AC'),
(31, 2, 1, 1, 'Sistema de apoyo para la mejora de la administración de la producción de cereales en PYMES', '12', 'Coadyuvar en la mejora de la administración de la producción de cereales en PYMES, con el\r\ndesarrollo de una herramienta de software que le permita administrar y conjuntamente reducir\r\npérdidas económicas.', 'En la actualidad las pequeñas empresas tienen un sistema deficiente para la planificación de su\r\nproducción, muchas veces de manera empírica; también tienes problemas con sus sistemas de apoyo.\r\nLa implementación de esta herramienta busca dar un apoyo a los pequeños y medianos empresarios\r\ncon sus problemas de administración y gestión de la producción.', 'Director Sistemas', 'ING. JOSE RICHARD AYOROA CARDOZO', NULL, '2013-11-06', 'EST. LIONEL AYAVIRI SEJAS', '-- Seleccione --', 'TS', NULL, NULL, 1, 'PR', 'IN', 'AC'),
(32, 1, 1, 0, 'SISTEMA DE GESTION ERP PARA TALLERES DE SERVICIO AUTOMOTRIZ', '', 'Desarrollar un Sistema de Información ERP para soporte de procesos de gestión para empresas de servicio automotriz.', 'El presente proyecto de grado tiene como área de investigación los sistemas ERP\r\naplicado a instituciones de servicios Automotrices, ya que estos sistemas de gestión empresarial están\r\ndiseñados para modelar y automatizar los procesos fundamentales. Las instituciones que brindan\r\nservicio automotriz de Cochabamba requieren de los beneficios que un sistema ERP puede ofrecerle,\r\nen cuanto al manejo de la información y la integración entre las áreas existentes y su comunicación.', 'Director Sistemas', '-- Seleccione --', NULL, '2013-11-06', 'EST. GRISELDA ANNEL PACA MENESES', '-- Seleccione --', 'TS', NULL, NULL, 1, 'PR', 'IN', 'AC'),
(33, 3, 1, 0, 'Sistema de información web para administración de la Residencia Universitaria Femenina Los Molles', '', 'Construir un sistema de información Web para la administración de los servicios y\r\nactividades en la Residencia Universitaria Femenina Los Molles aplicando workflow.', 'El proyecto consistirá en la implementación de un sistema de información web, que facilite y sea más fiable la\r\ntarea de administración, hasta el momento se realiza de manera manual. Se implementará una base de datos\r\ncon los datos necesarios para su prueba, el diseño e implementación de la interfaz gráfica, la implementación\r\nde la funcionalidad requerida. Permitirá mostrar la información deseada de modo que pueda ser vista en\r\ncualquier parte por las personas interesadas.', 'Director Sistemas', 'ING. JOSE RICHARD AYOROA CARDOZO', NULL, '2013-11-06', 'EST. ANGELA ELIANA BORDA DAVILA', '-- Seleccione --', 'TS', NULL, NULL, 1, 'PR', 'IN', 'AC'),
(34, 2, 0, 1, 'PÁGINA WEB INTERACTIVA PARA LA CARRERA DE CIENCIAS DE LA EDUCACIÓN.', '', 'SISTEMA WEB INTERACTIVA PARA LA CARRERA DE CIENCIAS DE LA\r\nEDUCACIÓN', 'La incorporación de una página web en la carrera funcionará como un canal de comunicación que nos acerca a los\r\nestudiantes, docentes y público en general. Ya que la sociedad requiere que la información de algunas instituciones como\r\nla Universidad se encuentre disponible, incluso para usuarios externos. Estos sistemas de información son un recurso vital\r\npara la correcta toma de decisiones, que en determinado momento concluye en una ventaja competitiva. El usuario\r\ninteracciona con las aplicaciones web a través del navegador.\r\nLas páginas interactivas con acceso a datos permiten interactuar con la información de una base de datos ya sea para\r\nobtener información y mostrar al usuario o bien para actualizar su contenido.', 'Director Sistemas', '-- Seleccione --', NULL, '2013-11-06', 'EST. CARLOS ANDRÉS BURGOS UREY', '-- Seleccione --', 'TS', NULL, NULL, 1, 'PR', 'IN', 'AC'),
(35, 3, 0, 0, 'PÁGINA WEB INTERACTIVA PARA LA CARRERA DE CIENCIAS DE LA EDUCACIÓN.', '', 'Objetivo general: Implementar un SISTEMA WEB INTERACTIVA PARA LA CARRERA DE CIENCIAS DE LA EDUCACIÓN', 'La incorporación de una página web en la carrera funcionará como un canal de comunicación que nos acerca a los\r\nestudiantes, docentes y público en general. Ya que la sociedad requiere que la información de algunas instituciones como\r\nla Universidad se encuentre disponible, incluso para usuarios externos. Estos sistemas de información son un recurso vital\r\npara la correcta toma de decisiones, que en determinado momento concluye en una ventaja competitiva. El usuario\r\ninteracciona con las aplicaciones web a través del navegador.\r\nLas páginas interactivas con acceso a datos permiten interactuar con la información de una base de datos ya sea para\r\nobtener información y mostrar al usuario o bien para actualizar su contenido.', 'Director Sistemas', '-- Seleccione --', NULL, '2013-11-06', 'EST. SHIRLEY JHOVANA  PINTO', '-- Seleccione --', 'TS', NULL, NULL, 1, 'PR', 'IN', 'AC'),
(36, 3, 0, 0, 'Sistema Web de Propagación de Resultados Obtenidos en el Instituto de Investigaciones de Arquitectura y Ciencias del Hábitat (IIACH) de la Universidad Mayor de San Simón (UMSS).', '', 'Coadyuvar en la difusión de los resultados obtenidos del Instituto de Investigaciones de Arquitectura y Ciencias del Hábitat\r\n(IIACH) de la Universidad Mayor de San Simón (UMSS), mediante un sistema web que provea de información a la comunidad\r\nuniversitaria y la sociedad civil.', 'Actualmente con el avance de la tecnología, especialmente en los medios de difusión de noticias, avisos,\r\nartículos, proyectos, etc, los centros de investigación, universidades e incluso empresas mismas se ven en la obligación de\r\nhacerse participe de este progreso, ya sea para beneficio propio, como de los usuarios que requieran la información que las\r\ndiferentes instituciones del medio manejan.', 'Director Sistemas', 'ING. JOSE RICHARD AYOROA CARDOZO', NULL, '2013-11-06', 'EST. GARY RICHARD VERA TERRAZAS', '-- Seleccione --', 'TS', NULL, NULL, 1, 'PR', 'IN', 'AC'),
(37, 1, 1, 0, 'Sistema de Información para el control de ventas de una empresa de Sombreros', '', 'Desarrollar un Sistema de Información para el control de ventas de una empresa de Sombreros\r\nutilizando framework CodeIgniter.', 'Actualmente algunas Empresas de venta de Sombreros no realizan un control adecuado de sus\r\nproductos dentro el almacén, incurriendo de esta manera en la perdida de información, algunas de las causas principales\r\npara no realizar un control adecuado es la cantidad de ingreso y la cantidad de salida realizada, y además que realizar un\r\ncontrol manual es muy moroso, dificultoso y poco eficiente. lo cuan genera un problema a realizar la búsqueda de pedidos\r\nhecho por los cliente lo cual se registran en un libro de pedidos donde a veces no se hace la entrega total del pedido y esto\r\nno se registra como un falta de entrega lo cual perjudica al cliente porque tiene que realizar otro pedido y es para otra\r\nfecha.', 'Director Sistemas', 'ING. JOSE RICHARD AYOROA CARDOZO', NULL, '2013-11-06', 'EST. SEGUNDINO GASTÓN FERNANDEZ FLORES', '-- Seleccione --', 'TS', NULL, NULL, 1, 'PR', 'IN', 'AC'),
(38, 3, 1, 0, 'Portal Web para la venta de libros On-Line, utilizando herramientas y técnicas de posicionamiento web', '', 'Desarrollar un Portal Web para la venta de libros On-Line, utilizando\r\nherramientas y técnicas de posicionamiento web', 'Actualmente las pequeñas y medianas empresas progresan a través de sus clientes, sino\r\nexisten clientelas por ende las empresas entran en desaparición. Es por este motivo la realización de\r\neste proyecto que está orientado para la venta de libros On-Line, el cual pueda realizar un control de la\r\nadministración de las ventas de libros y la administración existente de los libros para la venta directa\r\ncon el cliente, e integrando el portal web puesta en servidores en dominio gratuito; a este se aplicarán\r\ntécnicas y estrategias de posicionamiento web con el propósito de darnos a conocer para que tenga\r\néxito en la vitrina más grande del mundo La Red Global Mundial internet.', 'Director Sistemas', '-- Seleccione --', NULL, '2013-11-06', 'EST. MARCELO MARCOS VARGAS CHAVEZ', '-- Seleccione --', 'TS', NULL, NULL, 1, 'PR', 'IN', 'AC'),
(39, 0, 0, 0, '', '', '', '', '', '', '', '0000-00-00', '', '', '', NULL, NULL, 1, 'PE', 'IN', 'AC'),
(40, 1, 1, 0, 'Desarrollo aplicaciones mobiles', '10', 'O1', 'Perfil de prueba', 'Director Sistemas', 'ING. SAMUEL ROBERTO ACHá PEREZ', 'MSC. ING. JORGE WALTER ORELLANA ARAOZ', '2015-10-11', 'EST. PEPITO PEREZ GARNICA', '', 'TS', NULL, NULL, 0, 'PE', 'CO', 'AC'),
(41, 0, 0, 0, '', '', '', '', '', '', '', '0000-00-00', '', '', '', NULL, NULL, 1, 'PE', 'IN', 'AC'),
(42, 0, 0, 0, '', '', '', '', '', '', '', '0000-00-00', '', '', '', NULL, NULL, 1, 'PE', 'IN', 'AC'),
(43, 1, 1, 0, 'Desarrollo aplicaciones mobiles', '10', 'O1', 'Perfil de prueba', 'Director Sistemas', 'ING. SAMUEL ROBERTO ACHá PEREZ', 'MSC. ING. JORGE WALTER ORELLANA ARAOZ', '0000-00-00', 'EST. PEPITO PEREZ GARNICA', '', 'TS', NULL, NULL, 1, 'PR', 'LD', 'AC'),
(44, 0, 0, 0, '', '', '', '', '', '', '', '0000-00-00', '', '', '', NULL, NULL, 1, 'PE', 'VB', 'AC');

--
-- Disparadores `proyecto`
--
DROP TRIGGER IF EXISTS `biproydelet`;
DELIMITER //
CREATE TRIGGER `biproydelet` AFTER DELETE ON `proyecto`
 FOR EACH ROW INSERT INTO bitacora(host, operacion, modificado, tabla, tupla_antes, tupla_despues) 
VALUES (SUBSTRING(USER(), (INSTR(USER(),"@")+1)),"ELIMINAR", NOW(), "PROYECTO",CONCAT(OlD.ID,' ',OlD.nombre,' ',OlD.objetivo_general,' ',OlD.descripcion,' ',OlD.fecha_registro,' ',OlD.tipo_proyecto,' ',OlD.estado_proyecto),' ')
//
DELIMITER ;
DROP TRIGGER IF EXISTS `biproyecinsert`;
DELIMITER //
CREATE TRIGGER `biproyecinsert` AFTER INSERT ON `proyecto`
 FOR EACH ROW INSERT INTO bitacora(host, operacion, modificado, tabla, tupla_antes, tupla_despues) 
VALUES (SUBSTRING(USER(), (INSTR(USER(),"@")+1)),"INSERTAR", NOW(), "PROYECTO","",CONCAT(NEW.ID,' ', NEW.nombre,' ',NEW.objetivo_general,' ',NEW.descripcion,' ',NEW.fecha_registro,' ',NEW.tipo_proyecto,' ',NEW.estado_proyecto))
//
DELIMITER ;
DROP TRIGGER IF EXISTS `biproyeupdate`;
DELIMITER //
CREATE TRIGGER `biproyeupdate` AFTER UPDATE ON `proyecto`
 FOR EACH ROW INSERT INTO bitacora(host, operacion, modificado, tabla, tupla_antes, tupla_despues) 
VALUES (SUBSTRING(USER(), (INSTR(USER(),"@")+1)),"MODIFICAR", NOW(), "PROYECTO",CONCAT(OlD.ID,' ',OlD.nombre,' ',OlD.objetivo_general,' ',OlD.descripcion,' ',OlD.fecha_registro,' ',OlD.tipo_proyecto,' ',OlD.estado_proyecto),CONCAT(NEW.ID,' ', NEW.nombre,' ',NEW.objetivo_general,' ',NEW.descripcion,' ',NEW.fecha_registro,' ',NEW.tipo_proyecto,' ',NEW.estado_proyecto))
//
DELIMITER ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `proyecto_area`
--

DROP TABLE IF EXISTS `proyecto_area`;
CREATE TABLE IF NOT EXISTS `proyecto_area` (
`id` int(11) NOT NULL,
  `area_id` int(11) DEFAULT NULL,
  `proyecto_id` int(11) DEFAULT NULL,
  `estado` varchar(2) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `proyecto_area`
--

INSERT INTO `proyecto_area` (`id`, `area_id`, `proyecto_id`, `estado`) VALUES
(1, 1, 40, 'AC'),
(2, 1, 38, 'AC'),
(3, 1, 43, 'AC');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `proyecto_dicta`
--

DROP TABLE IF EXISTS `proyecto_dicta`;
CREATE TABLE IF NOT EXISTS `proyecto_dicta` (
`id` int(11) NOT NULL,
  `proyecto_id` int(11) DEFAULT NULL,
  `dicta_id` int(11) DEFAULT NULL,
  `estado` varchar(2) DEFAULT NULL COMMENT 'Activo sera AC, No activo NC, Eliminado DE'
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `proyecto_dicta`
--

INSERT INTO `proyecto_dicta` (`id`, `proyecto_id`, `dicta_id`, `estado`) VALUES
(1, 1, 1, 'AC'),
(2, 2, 1, 'AC'),
(3, 3, 1, 'AC'),
(4, 4, 1, 'AC'),
(5, 5, 1, 'AC'),
(6, 6, 1, 'AC'),
(7, 7, 1, 'AC'),
(8, 8, 1, 'AC'),
(9, 9, 1, 'AC'),
(10, 10, 1, 'AC'),
(11, 11, 1, 'AC'),
(12, 12, 1, 'AC'),
(13, 13, 1, 'AC'),
(14, 14, 1, 'AC'),
(15, 15, 1, 'AC'),
(16, 16, 1, 'AC'),
(17, 17, 1, 'AC'),
(18, 18, 1, 'AC'),
(19, 19, 1, 'AC'),
(20, 39, 2, 'AC'),
(21, 40, 2, 'AC'),
(22, 41, 2, 'AC'),
(23, 42, 3, 'AC'),
(24, 43, 7, 'AC'),
(25, 39, 7, 'AC'),
(26, 41, 7, 'AC'),
(27, 42, 7, 'AC'),
(28, 44, 5, 'AC');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `proyecto_estudiante`
--

DROP TABLE IF EXISTS `proyecto_estudiante`;
CREATE TABLE IF NOT EXISTS `proyecto_estudiante` (
`id` int(11) NOT NULL,
  `proyecto_id` int(11) DEFAULT NULL,
  `estudiante_id` int(11) DEFAULT NULL,
  `fecha_asignacion` date DEFAULT NULL,
  `estado` varchar(2) DEFAULT NULL COMMENT 'Activo sera AC, No activo NC, Eliminado DE'
) ENGINE=InnoDB AUTO_INCREMENT=45 DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `proyecto_estudiante`
--

INSERT INTO `proyecto_estudiante` (`id`, `proyecto_id`, `estudiante_id`, `fecha_asignacion`, `estado`) VALUES
(1, 1, 1, '2013-11-06', 'AC'),
(2, 2, 2, '2013-11-06', 'AC'),
(3, 3, 3, '2013-11-06', 'AC'),
(4, 4, 4, '2013-11-06', 'AC'),
(5, 5, 5, '2013-11-06', 'AC'),
(6, 6, 6, '2013-11-06', 'AC'),
(7, 7, 7, '2013-11-06', 'AC'),
(8, 8, 8, '2013-11-06', 'AC'),
(9, 9, 9, '2013-11-06', 'AC'),
(10, 10, 10, '2013-11-06', 'AC'),
(11, 11, 11, '2013-11-06', 'AC'),
(12, 12, 12, '2013-11-06', 'AC'),
(13, 13, 13, '2013-11-06', 'AC'),
(14, 14, 14, '2013-11-06', 'AC'),
(15, 15, 15, '2013-11-06', 'AC'),
(16, 16, 16, '2013-11-06', 'AC'),
(17, 17, 17, '2013-11-06', 'AC'),
(18, 18, 18, '2013-11-06', 'AC'),
(19, 19, 19, '2013-11-06', 'AC'),
(20, 20, 1, '2013-11-06', 'AC'),
(21, 21, 2, '2013-11-06', 'AC'),
(22, 22, 3, '2013-11-06', 'AC'),
(23, 23, 4, '2013-11-06', 'AC'),
(24, 24, 5, '2013-11-06', 'AC'),
(25, 25, 6, '2013-11-06', 'AC'),
(26, 26, 7, '2013-11-06', 'AC'),
(27, 27, 8, '2013-11-06', 'AC'),
(28, 28, 9, '2013-11-06', 'AC'),
(29, 29, 10, '2013-11-06', 'AC'),
(30, 30, 11, '2013-11-06', 'AC'),
(31, 31, 12, '2013-11-06', 'AC'),
(32, 32, 13, '2013-11-06', 'AC'),
(33, 33, 14, '2013-11-06', 'AC'),
(34, 34, 15, '2013-11-06', 'AC'),
(35, 35, 16, '2013-11-06', 'AC'),
(36, 36, 17, '2013-11-06', 'AC'),
(37, 37, 18, '2013-11-06', 'AC'),
(38, 38, 19, '2013-11-06', 'AC'),
(39, 39, 20, '2015-09-09', 'AC'),
(40, 40, 21, '0000-00-00', 'AC'),
(41, 41, 22, '2015-10-11', 'AC'),
(42, 42, 23, '2015-10-11', 'AC'),
(43, 43, 21, '2015-10-11', 'AC'),
(44, 44, 24, '2015-10-21', 'AC');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `proyecto_revisor`
--

DROP TABLE IF EXISTS `proyecto_revisor`;
CREATE TABLE IF NOT EXISTS `proyecto_revisor` (
`id` int(11) NOT NULL,
  `proyecto_id` int(11) DEFAULT NULL,
  `revisor_id` int(11) DEFAULT NULL,
  `estado` varchar(2) DEFAULT NULL COMMENT 'Activo sera AC, No activo NC, Eliminado DE'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `proyecto_sub_area`
--

DROP TABLE IF EXISTS `proyecto_sub_area`;
CREATE TABLE IF NOT EXISTS `proyecto_sub_area` (
`id` int(11) NOT NULL,
  `sub_area_id` int(11) NOT NULL,
  `proyecto_id` int(11) NOT NULL,
  `estado` varchar(2) DEFAULT NULL COMMENT 'Activo sera AC, No activo NC, Eliminado DE'
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `proyecto_sub_area`
--

INSERT INTO `proyecto_sub_area` (`id`, `sub_area_id`, `proyecto_id`, `estado`) VALUES
(1, 1, 19, 'AC'),
(2, 2, 16, 'AC'),
(3, 3, 40, 'AC'),
(4, 3, 34, 'AC'),
(5, 2, 35, 'AC'),
(6, 1, 38, 'AC'),
(7, 3, 43, 'AC');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `proyecto_tutor`
--

DROP TABLE IF EXISTS `proyecto_tutor`;
CREATE TABLE IF NOT EXISTS `proyecto_tutor` (
`id` int(11) NOT NULL,
  `proyecto_id` int(11) DEFAULT NULL,
  `tutor_id` int(11) DEFAULT NULL,
  `fecha_asignacion` date DEFAULT NULL COMMENT 'fecha que fue asignado como tutor',
  `fecha_acepta` date DEFAULT NULL COMMENT 'fecha que acepta la tutoria',
  `fecha_final` date DEFAULT NULL COMMENT 'Fecha en la que termina la tutoria',
  `estado_tutoria` varchar(2) DEFAULT NULL COMMENT 'Pendiente (PE), Aceptado (AC) , Rechado (RE), finallizado (FI)',
  `estado` varchar(2) DEFAULT NULL COMMENT 'Activo sera AC, No activo NC, Eliminado DE'
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `proyecto_tutor`
--

INSERT INTO `proyecto_tutor` (`id`, `proyecto_id`, `tutor_id`, `fecha_asignacion`, `fecha_acepta`, `fecha_final`, `estado_tutoria`, `estado`) VALUES
(1, 39, 2, '2015-10-10', '2015-10-10', '0000-00-00', 'AC', 'AC'),
(2, 43, 2, '2015-10-11', '2015-10-11', '0000-00-00', 'AC', 'AC'),
(3, 43, 3, '2015-10-11', '2015-10-11', '0000-00-00', 'AC', 'AC'),
(4, 43, 4, '2015-10-11', '2015-10-11', '0000-00-00', 'AC', 'AC'),
(5, 43, 5, '2015-10-11', '2015-10-11', '0000-00-00', 'AC', 'AC'),
(6, 44, 1, '2015-10-21', '0000-00-00', '2015-10-21', 'FI', 'AC'),
(7, 44, 2, '2015-10-21', '2015-10-21', '0000-00-00', 'AC', 'AC'),
(8, 44, 3, '2015-10-21', '2015-10-21', '0000-00-00', 'AC', 'AC');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `respaldo`
--

DROP TABLE IF EXISTS `respaldo`;
CREATE TABLE IF NOT EXISTS `respaldo` (
`id` int(11) NOT NULL,
  `fecha_respaldo` date DEFAULT NULL,
  `archivo` varchar(200) DEFAULT NULL,
  `estado` varchar(10) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `respaldo`
--

INSERT INTO `respaldo` (`id`, `fecha_respaldo`, `archivo`, `estado`) VALUES
(1, '2015-10-21', 'respaldo/db-backup-10-21-2015-13-12-54.sql', NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `revision`
--

DROP TABLE IF EXISTS `revision`;
CREATE TABLE IF NOT EXISTS `revision` (
`id` int(11) NOT NULL,
  `proyecto_id` int(11) DEFAULT NULL,
  `avance_id` int(11) DEFAULT NULL,
  `revisor` int(11) DEFAULT NULL COMMENT 'dependiendo de tipo docente_id',
  `revisor_tipo` varchar(2) DEFAULT NULL COMMENT 'docente (DO), docente perfil(DP), tutor (TU), tribunal (TR)',
  `fecha_revision` date DEFAULT NULL,
  `fecha_correccion` date DEFAULT NULL,
  `fecha_aprobacion` date DEFAULT NULL,
  `estado_revision` varchar(2) DEFAULT NULL COMMENT 'estado 1 creado (CR), estado 2 visto (VI), estado 3 respondido  (RE), estado 4 aprobado (AP)',
  `estado` varchar(2) DEFAULT NULL COMMENT 'Activo sera AC, No activo NC, Eliminado DE'
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `revision`
--

INSERT INTO `revision` (`id`, `proyecto_id`, `avance_id`, `revisor`, `revisor_tipo`, `fecha_revision`, `fecha_correccion`, `fecha_aprobacion`, `estado_revision`, `estado`) VALUES
(1, 40, 2, 2, 'TU', '2015-10-11', '2015-10-11', '2015-10-11', 'AP', 'AC'),
(2, 40, 2, 2, 'TU', '2015-10-11', '2015-10-11', '2015-10-11', 'AP', 'AC'),
(3, 40, 2, 2, 'TU', '2015-10-11', '0000-00-00', '0000-00-00', 'CR', 'AC'),
(4, 40, 4, 2, 'TU', '2015-10-11', '2015-10-11', '2015-10-11', 'AP', 'AC'),
(5, 43, 5, 2, 'TU', '2015-11-01', '2015-11-01', '2015-11-01', 'AP', 'AC'),
(6, 43, 7, 52, 'TR', '2015-11-01', '2015-11-01', '2015-11-01', 'AP', 'AC'),
(7, 44, 9, 2, 'TU', '2015-10-20', '2015-10-21', '2015-10-20', 'AP', 'AC'),
(8, 44, 9, 2, 'TU', '2015-10-20', '2015-10-21', '2015-10-20', 'AP', 'AC');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `revisor`
--

DROP TABLE IF EXISTS `revisor`;
CREATE TABLE IF NOT EXISTS `revisor` (
`id` int(11) NOT NULL,
  `usuario_id` int(11) NOT NULL,
  `fecha_inicio` date DEFAULT NULL,
  `fecha_fin` date DEFAULT NULL,
  `estado` varchar(2) DEFAULT NULL COMMENT 'Activo sera AC, No activo NC, Eliminado DE'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `semestre`
--

DROP TABLE IF EXISTS `semestre`;
CREATE TABLE IF NOT EXISTS `semestre` (
`id` int(11) NOT NULL,
  `codigo` varchar(45) DEFAULT NULL,
  `activo` tinyint(1) DEFAULT NULL,
  `valor` int(11) DEFAULT NULL,
  `fecha_inicio` date DEFAULT NULL,
  `fecha_fin` date DEFAULT NULL,
  `estado` varchar(2) DEFAULT NULL COMMENT 'Activo sera AC, No activo NC, Eliminado DE'
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `semestre`
--

INSERT INTO `semestre` (`id`, `codigo`, `activo`, `valor`, `fecha_inicio`, `fecha_fin`, `estado`) VALUES
(1, 'I-2015', 0, 1, '2015-02-10', '2015-10-31', 'AC'),
(2, 'II-2015', 1, 2, '2015-11-01', '2015-12-31', 'AC');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `sub_area`
--

DROP TABLE IF EXISTS `sub_area`;
CREATE TABLE IF NOT EXISTS `sub_area` (
`id` int(11) NOT NULL,
  `area_id` int(11) DEFAULT NULL,
  `nombre` varchar(45) DEFAULT NULL,
  `descripcion` varchar(45) DEFAULT NULL,
  `estado` varchar(2) DEFAULT NULL COMMENT 'Activo sera AC, No activo NC, Eliminado DE'
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `sub_area`
--

INSERT INTO `sub_area` (`id`, `area_id`, `nombre`, `descripcion`, `estado`) VALUES
(1, 1, 'Sistema de Información', 'Subarea del area de Ingenieria de software', 'AC'),
(2, 1, 'Reingeniería', 'Reingeniería', 'AC'),
(3, 1, 'Programacion Web', 'programacion web de paginas', 'AC'),
(4, 2, 'Programación Web Objetos', 'Programación Web Objetos Descripción', 'AC');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `titulo_honorifico`
--

DROP TABLE IF EXISTS `titulo_honorifico`;
CREATE TABLE IF NOT EXISTS `titulo_honorifico` (
`id` int(11) NOT NULL,
  `nombre` varchar(150) DEFAULT NULL,
  `descripcion` varchar(300) DEFAULT NULL,
  `estado` varchar(2) DEFAULT NULL COMMENT 'Activo sera AC, No activo NC, Eliminado DE'
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `titulo_honorifico`
--

INSERT INTO `titulo_honorifico` (`id`, `nombre`, `descripcion`, `estado`) VALUES
(1, 'Est.', 'Est.', 'AC'),
(2, 'Lic.', 'Lic.', 'AC'),
(3, 'Ing.', 'Ing.', 'AC'),
(4, 'Msc.', 'Msc.', 'AC'),
(5, 'Msc. Lic.', 'Msc. Lic.', 'AC'),
(6, 'Msc. Ing.', 'Msc. Ing.', 'AC'),
(7, 'Dr.', 'Dr.', 'AC'),
(8, 'Ph.D.', 'Ph.D.', 'AC');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tooltip`
--

DROP TABLE IF EXISTS `tooltip`;
CREATE TABLE IF NOT EXISTS `tooltip` (
`id` int(11) NOT NULL,
  `helpdesk_id` int(11) DEFAULT NULL,
  `titulo` varchar(150) DEFAULT NULL,
  `codigo` varchar(150) DEFAULT NULL,
  `descripcion` varchar(1000) DEFAULT NULL,
  `mostrar` tinyint(4) DEFAULT NULL COMMENT 'si se muestra el tool tip o no',
  `estado_tooltip` varchar(2) DEFAULT NULL COMMENT 'Recien creado RC, Clonados (CL) , Aprobado AP',
  `estado` varchar(2) DEFAULT NULL COMMENT 'Activo sera AC, No activo NC, Eliminado DE'
) ENGINE=InnoDB AUTO_INCREMENT=526 DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `tooltip`
--

INSERT INTO `tooltip` (`id`, `helpdesk_id`, `titulo`, `codigo`, `descripcion`, `mostrar`, `estado_tooltip`, `estado`) VALUES
(1, 0, 'Login', 'login', 'Búsqueda del usuario mediante su nombre de acceso,login registrado', 1, 'CL', 'AC'),
(2, 0, 'Clave', 'clave', 'Clave', 1, 'AP', 'AC'),
(3, 0, 'Tipo', 'tipo', 'Tipo', 1, 'AP', 'AC'),
(4, 0, 'Sigla', 'sigla', 'Sigla', 1, 'AP', 'AC'),
(5, 0, 'Nombre', 'nombre', 'Búsqueda del usuario mediante su apellido paterno registrado', 1, 'CL', 'AC'),
(6, 0, 'Apellido paterno', 'apellido_paterno', 'Apellido paterno', 1, 'AP', 'AC'),
(7, 0, 'Apellido Paterno', 'apellido_materno', 'Búsqueda del usuario mediante su apellido materno registrado', 1, 'CL', 'AC'),
(8, 0, 'email', 'email', 'Búsqueda del usuario mediante su correo electrónico valido registrado', 1, 'CL', 'AC'),
(9, 0, 'codigo_sis', 'codigo_sis', 'Búsqueda del usuario mediante su Codigo sis registrado', 1, 'CL', 'AC'),
(10, 0, 'Docente', 'docente', 'Docente', 1, 'AP', 'AC'),
(11, 0, 'Semestre id', 'semestre_id', 'Semestre id', 1, 'AP', 'AC'),
(12, 0, 'Materia id', 'materia_id', 'Materia id', 1, 'AP', 'AC'),
(13, 0, 'Dicta id', 'dicta_id', 'Dicta id', 1, 'AP', 'AC'),
(14, 0, 'Ci', 'ci', 'Ci', 1, 'AP', 'AC'),
(15, 0, 'T&iacute;tulo honorifico', 'titulo_honorifico', 'Titulo honorifico', 1, 'AP', 'AC'),
(16, 0, 'Fecha nacimiento', 'fecha_nacimiento', 'Fecha nacimiento', 1, 'AP', 'AC'),
(17, 0, 'Clave2', 'clave2', 'Clave2', 1, 'AP', 'AC'),
(18, 0, 'Estado', 'estado', 'Estado', 1, 'AP', 'AC'),
(19, 0, 'Codigo', 'codigo', 'Codigo', 1, 'AP', 'AC'),
(20, 0, 'Descripcion', 'descripcion', 'Descripcion', 1, 'AP', 'AC'),
(21, 0, 'Modulo codigo', 'modulo_codigo', 'Modulo codigo', 1, 'AP', 'AC'),
(22, 0, 'Modulo descripcion', 'modulo_descripcion', 'Modulo descripcion', 1, 'AP', 'AC'),
(23, 0, 'Numero', 'numero', 'Numero', 1, 'AP', 'AC'),
(24, 0, 'Telefono', 'telefono', 'Telefono', 1, 'AP', 'AC'),
(25, 0, 'Tutor', 'tutor', 'Tutor', 1, 'AP', 'AC'),
(26, 0, 'Carrera de la Facultad', 'carrera_id', 'Es la carrera de fecultad', 1, 'CL', 'AC'),
(27, 0, 'Trabajo conjunto', 'trabajo_conjunto', 'Trabajo conjunto', 1, 'AP', 'AC'),
(28, 0, 'Semestre', 'semestre', 'Semestre', 1, 'AP', 'AC'),
(29, 0, 'Cambio tema', 'cambio_tema', 'Cambio tema', 1, 'AP', 'AC'),
(30, 0, 'Proyecto nombre', 'proyecto_nombre', 'Proyecto nombre', 1, 'AP', 'AC'),
(31, 0, 'Areas', 'areas', 'Areas', 1, 'AP', 'AC'),
(32, 0, 'Subareas', 'subareas', 'Subareas', 1, 'AP', 'AC'),
(33, 0, 'Nuevasubarea ', 'nuevasubarea ', 'Nuevasubarea ', 1, 'AP', 'AC'),
(34, 0, 'Agregarareas', 'agregarareas', 'Agregarareas', 1, 'AP', 'AC'),
(35, 0, 'Quitarareas', 'quitarareas', 'Quitarareas', 1, 'AP', 'AC'),
(36, 0, 'Modalidad', 'modalidad', 'Modalidad', 1, 'AP', 'AC'),
(37, 0, 'Institucion', 'institucion', 'Institucion', 1, 'AP', 'AC'),
(38, 0, 'Nuevainstitucion', 'nuevainstitucion', 'Nuevainstitucion', 1, 'AP', 'AC'),
(39, 0, 'Objetivogeneral', 'objetivogeneral', 'Objetivogeneral', 1, 'AP', 'AC'),
(40, 0, 'Objetivoespecificos', 'objetivoespecificos', 'Objetivoespecificos', 1, 'AP', 'AC'),
(41, 0, 'Agregarobjetivo', 'agregarobjetivo', 'Agregarobjetivo', 1, 'AP', 'AC'),
(42, 0, 'Quitarobjetivo', 'quitarobjetivo', 'Quitarobjetivo', 1, 'AP', 'AC'),
(43, 0, 'Director carrera', 'director_carrera', 'Director carrera', 1, 'AP', 'AC'),
(44, 0, 'Docente materia', 'docente_materia', 'Docente materia', 1, 'AP', 'AC'),
(45, 0, 'Responsable', 'responsable', 'Responsable', 1, 'AP', 'AC'),
(46, 0, 'Estudiante', 'estudiante', 'Estudiante', 1, 'AP', 'AC'),
(47, 0, 'Registrado por', 'registrado_por', 'Registrado por', 1, 'AP', 'AC'),
(48, 0, 'Fecha registro', 'fecha_registro', 'Fecha registro', 1, 'AP', 'AC'),
(49, 0, 'Datos', 'datos', 'Datos', 1, 'AP', 'AC'),
(50, 3, 'Login', 'login', 'Búsqueda del usuario mediante su nombre de acceso,login registrado', 1, 'CL', 'AC'),
(51, 3, 'Clave', 'clave', 'Clave', 1, 'AP', 'AC'),
(52, 5, 'Nombre', 'nombre', 'Búsqueda del usuario mediante su nombre registrado', 1, 'AP', 'AC'),
(53, 5, 'Apellido Paterno', 'apellido_paterno', 'Búsqueda del docente mediante su apellido paterno registrado', 1, 'AP', 'AC'),
(54, 5, 'Apellido Materno', 'apellido_materno', 'Búsqueda del docente mediante su apellido materno registrado', 1, 'AP', 'AC'),
(55, 5, 'Login', 'login', 'Búsqueda del docente mediante su login o su nombre de acceso al sistema', 1, 'AP', 'AC'),
(56, 5, 'email', 'email', 'Búsqueda del usuario mediante su correo electrónico registrado', 1, 'AP', 'AC'),
(57, 5, 'Codigo Sis', 'codigo_sis', 'Búsqueda del docente mediante su código sis', 1, 'AP', 'AC'),
(58, 7, 'Nombre', 'nombre', 'Búsqueda del usuario mediante su apellido paterno registrado', 1, 'AP', 'AC'),
(59, 7, 'apellido_paterno', 'apellido_paterno', 'Búsqueda del usuario mediante su apellido paterno registrado', 1, 'AP', 'AC'),
(60, 7, 'Apellido Paterno', 'apellido_materno', 'Búsqueda del usuario mediante su apellido materno registrado', 1, 'AP', 'AC'),
(61, 7, 'Login', 'login', 'Búsqueda del usuario mediante su nombre de acceso,login registrado', 1, 'AP', 'AC'),
(62, 7, 'email', 'email', 'Búsqueda del usuario mediante su correo electrónico valido registrado', 1, 'AP', 'AC'),
(63, 7, 'codigo_sis', 'codigo_sis', 'Búsqueda del usuario mediante su Codigo sis registrado', 1, 'AP', 'AC'),
(64, 9, 'Nombre', 'nombre', 'Búsqueda del usuario mediante su Nombre registrado', 1, 'AP', 'AC'),
(65, 9, 'Apellido Paterno', 'apellido_paterno', 'Búsqueda del usuario mediante su Apellido paterno registrado', 1, 'AP', 'AC'),
(66, 9, 'Apellido Materno', 'apellido_materno', 'Búsqueda del usuario mediante su Apellido Materno registrado', 1, 'AP', 'AC'),
(67, 9, 'Login', 'login', 'Búsqueda del usuario mediante su login o nombre de acceso registrado', 1, 'AP', 'AC'),
(68, 9, 'Email', 'email', 'Búsqueda del usuario mediante su Email valido registrado', 1, 'AP', 'AC'),
(69, 10, 'Nombre', 'nombre', 'Búsqueda del usuario mediante su nombre registrado', 1, 'AP', 'AC'),
(70, 10, 'Apellido Paterno', 'apellido_paterno', 'Búsqueda del usuario mediante Apellido Paterno registrado', 1, 'AP', 'AC'),
(71, 10, 'Apellido Materno', 'apellido_materno', 'Búsqueda del usuario mediante su Apellido materno registrado', 1, 'AP', 'AC'),
(72, 10, 'Login', 'login', 'Búsqueda del usuario mediante su login o nombre de acceso registrado', 1, 'AP', 'AC'),
(73, 10, 'Email', 'email', 'Búsqueda del usuario mediante su Email registrado', 1, 'AP', 'AC'),
(74, 12, 'Estado', 'estado', 'Búsqueda mediante Estado registrado', 1, 'AP', 'AC'),
(75, 12, 'Codigo', 'codigo', 'Búsqueda del permiso mediante su Codigo registrado', 1, 'AP', 'AC'),
(76, 12, 'Descripcion', 'descripcion', 'Búsqueda del permiso segun la descripcion registrada', 1, 'AP', 'AC'),
(77, 13, 'Modulo codigo', 'modulo_codigo', 'Modulo codigo', 1, 'AP', 'AC'),
(78, 13, 'Modulo descripcion', 'modulo_descripcion', 'Modulo descripcion', 1, 'AP', 'AC'),
(79, 16, 'Login', 'login', 'Ingrese su login de acceso al sistema', 1, 'AP', 'AC'),
(80, 16, 'Clave', 'clave', 'Ingrese  su password de acceso al sistema', 1, 'AP', 'AC'),
(81, 17, 'Login', 'login', 'Nombre de acceso Consejo', 1, 'AP', 'AC'),
(82, 17, 'Clave', 'clave', 'Password de acceso Consejo', 1, 'AP', 'AC'),
(83, 21, 'Login', 'login', 'Ingrese su login de acceso al sistema', 1, 'AP', 'AC'),
(84, 21, 'Clave', 'clave', 'Ingrese su password de ingreso al sistema', 1, 'AP', 'AC'),
(85, 24, 'Tipo', 'tipo_proyecto', 'Búsqueda de Cartas mediante la Tipo de carta registrada', 1, 'AP', 'AC'),
(86, 24, 'Estado', 'estado_proyecto', 'Búsqueda de Cartas mediante la Estado del registrada', 1, 'AP', 'AC'),
(87, 24, 'T&iacute;tulo', 'titulo', 'Búsqueda de Cartas mediante la Titulo registrada', 1, 'AP', 'AC'),
(88, 24, 'Descripcion', 'descripcion', 'Búsqueda de Cartas mediante la descripción registrada', 1, 'AP', 'AC'),
(89, 25, 'Tipo de Proyecto', 'tipo_proyecto', 'Elija la carta según el tipo sea para perfil o proyecto final', 1, 'AP', 'AC'),
(90, 25, 'Estado', 'estado_proyecto', 'Elija el proyecto segun el estado en el que se encuentre', 1, 'AP', 'AC'),
(91, 25, 'Tirulo', 'titulo', 'Registro del titulo que llevara la carta', 1, 'AP', 'AC'),
(92, 25, 'Descripcion', 'descripcion', 'Descripción que llevara la carta', 1, 'AP', 'AC'),
(93, 52, 'Bus', 'bus', 'Bus', 1, 'AP', 'AC'),
(94, 54, 'Semestre', 'semestre_id', 'Semestre actual en el cual esta inscrito el estudiante', 1, 'AP', 'AC'),
(95, 54, 'Materia', 'materia_id', 'Materia al cual el estudiante se registrara', 1, 'AP', 'AC'),
(96, 54, 'Grupo', 'dicta_id', 'Grupo del la materia l cual pertenece el estudiante', 1, 'AP', 'AC'),
(97, 54, 'Código Sis', 'codigo_sis', 'Código sis del estudiante proporcionado por la univercidad ,dato numerico', 1, 'AP', 'AC'),
(98, 54, 'Cedula de Identidad', 'ci', 'Documento de identidad del estudiante es un dato numerico', 1, 'AP', 'AC'),
(99, 54, 'Título Honorifico', 'titulo_honorifico', 'En este caso es el identificador del estudiante.', 1, 'AP', 'AC'),
(100, 54, 'Nombre', 'nombre', 'Nombres del estudiante', 1, 'AP', 'AC'),
(101, 54, 'Apellido Paterno', 'apellido_paterno', 'Registro del apellido apterno del estudianre.', 1, 'AP', 'AC'),
(102, 54, 'Apellido Materno', 'apellido_materno', 'Registro del apellido materno correspondiente al estudiante', 1, 'AP', 'AC'),
(103, 54, 'Fecha de Nacimiento', 'fecha_nacimiento', 'Fecha de nacimiento del estudiante', 1, 'AP', 'AC'),
(104, 54, 'email', 'email', 'Direccion de correo electronico valido del estudiante', 1, 'AP', 'AC'),
(105, 54, 'Login', 'login', 'nombre de acsedo del aestudiante al sistema', 1, 'AP', 'AC'),
(106, 54, 'Clave', 'clave', 'Clave de ingreso o password del estudiante para el acceso al sistema', 1, 'AP', 'AC'),
(107, 54, 'Verificacion de clave de ingreso', 'clave2', 'Se verifica la clave q ingreso el usuario al principio', 1, 'AP', 'AC'),
(108, 56, 'Tipo', 'tipo', 'Tipo de materia perfil o proyecto final', 1, 'AP', 'AC'),
(109, 56, 'Sigla', 'sigla', 'Siglas q identifican ala materia', 1, 'AP', 'AC'),
(110, 56, 'Nombre', 'nombre', 'Nombre de la materia para realización del proyecto fina', 1, 'AP', 'AC'),
(111, 57, 'Nombre', 'nombre', 'Búsqueda de materia mediante la nombre registrada', 1, 'AP', 'AC'),
(112, 57, 'Sigla', 'sigla', 'Búsqueda de materia mediante la Sigla registrada', 1, 'AP', 'AC'),
(113, 58, 'Docente', 'docente', 'Docente', 1, 'AP', 'AC'),
(114, 60, 'Nombre', 'nombre', 'Búsqueda del usuario mediante su nombre registrado', 1, 'AP', 'AC'),
(115, 60, 'Aoellido Paterno', 'apellido_paterno', 'Búsqueda del usuario mediante su apellido paterno registrado', 1, 'AP', 'AC'),
(116, 60, 'Apellido Materno', 'apellido_materno', 'Búsqueda del usuario mediante su apellido paterno registrado', 1, 'AP', 'AC'),
(117, 60, 'login', 'login', 'Búsqueda del usuario mediante su nombre de acceso al sistema registrado', 1, 'AP', 'AC'),
(118, 60, 'email', 'email', 'Búsqueda del usuario mediante su correo electrónico valido registrado', 1, 'AP', 'AC'),
(119, 60, 'Codigo sis', 'codigo_sis', 'Búsqueda del usuario mediante su código sis registrado', 1, 'AP', 'AC'),
(120, 61, 'Estado', 'estado', 'Búsqueda del usuario mediante su Estado activo o no activo registrado', 1, 'AP', 'AC'),
(121, 61, 'Nombre', 'nombre', 'Búsqueda del usuario mediante su Nombre registrado', 1, 'AP', 'AC'),
(122, 61, 'Apellidos', 'apellidos', 'Búsqueda del usuario mediante su Apellidos registrado', 1, 'AP', 'AC'),
(123, 61, 'Login', 'login', 'Búsqueda del usuario mediante su nombre de acceso o login registrado', 1, 'AP', 'AC'),
(124, 61, 'Email', 'email', 'Búsqueda del usuario mediante su correo electrónico registrado', 1, 'AP', 'AC'),
(125, 62, 'Nombre', 'nombre', 'Búsqueda del usuario mediante su apellido paterno registrado', 1, 'CL', 'AC'),
(126, 62, 'Apellido paterno', 'apellido_paterno', 'Apellido paterno', 1, 'AP', 'AC'),
(127, 62, 'Apellido Paterno', 'apellido_materno', 'Búsqueda del usuario mediante su apellido materno registrado', 1, 'CL', 'AC'),
(128, 62, 'Login', 'login', 'Búsqueda del usuario mediante su nombre de acceso,login registrado', 1, 'CL', 'AC'),
(129, 62, 'email', 'email', 'Búsqueda del usuario mediante su correo electrónico valido registrado', 1, 'CL', 'AC'),
(130, 63, 'Estado notificacion', 'estado_notificacion', 'Estado en el que se encuentra la notificación', 1, 'AP', 'AC'),
(131, 63, 'Tipo de mensaje', 'tipo', 'Este es el tipo de mensaje enviado por el usuario', 1, 'AP', 'AC'),
(132, 63, 'Asunto', 'asunto', 'Asunto del mensaje enviado por el usuario', 1, 'AP', 'AC'),
(133, 63, 'Detalle', 'detalle', 'Detalle del mensaje enviado por el usuario', 1, 'AP', 'AC'),
(134, 69, 'Estado', 'estado_notificacion', 'Búsqueda del la notificación mensaje el estado de la notificacion', 1, 'AP', 'AC'),
(135, 69, 'Tipo', 'tipo', 'Búsqueda del la notificación mensaje el tipo de mensaje', 1, 'AP', 'AC'),
(136, 69, 'Asunto', 'asunto', 'Búsqueda del la notificación mensaje el Asunto', 1, 'AP', 'AC'),
(137, 69, 'Detalle de mensaje', 'detalle', 'Búsqueda del la notificación mensaje el detalle', 1, 'AP', 'AC'),
(138, 75, 'Apellido paterno', 'apellido_paterno', 'Apellido paterno', 1, 'AP', 'AC'),
(139, 75, 'Apellido Paterno', 'apellido_materno', 'Búsqueda del usuario mediante su apellido materno registrado', 1, 'CL', 'AC'),
(140, 75, 'Nombre', 'nombre', 'Búsqueda del usuario mediante su apellido paterno registrado', 1, 'CL', 'AC'),
(141, 75, 'Numero', 'numero', 'Numero', 1, 'AP', 'AC'),
(142, 75, 'Telefono', 'telefono', 'Telefono', 1, 'AP', 'AC'),
(143, 75, 'email', 'email', 'Búsqueda del usuario mediante su correo electrónico valido registrado', 1, 'CL', 'AC'),
(144, 75, 'Tutor', 'tutor', 'Tutor', 1, 'AP', 'AC'),
(145, 75, 'Carrera de la Facultad', 'carrera_id', 'Es la carrera de fecultad', 1, 'CL', 'AC'),
(146, 75, 'Trabajo conjunto', 'trabajo_conjunto', 'Trabajo conjunto', 1, 'AP', 'AC'),
(147, 75, 'Semestre', 'semestre', 'Semestre', 1, 'AP', 'AC'),
(148, 75, 'Cambio tema', 'cambio_tema', 'Cambio tema', 1, 'AP', 'AC'),
(149, 75, 'Proyecto nombre', 'proyecto_nombre', 'Proyecto nombre', 1, 'AP', 'AC'),
(150, 75, 'Areas', 'areas', 'Areas', 1, 'AP', 'AC'),
(151, 75, 'Subareas', 'subareas', 'Subareas', 1, 'AP', 'AC'),
(152, 75, 'Nuevasubarea ', 'nuevasubarea ', 'Nuevasubarea ', 1, 'AP', 'AC'),
(153, 75, 'Agregarareas', 'agregarareas', 'Agregarareas', 1, 'AP', 'AC'),
(154, 75, 'Quitarareas', 'quitarareas', 'Quitarareas', 1, 'AP', 'AC'),
(155, 75, 'Modalidad', 'modalidad', 'Modalidad', 1, 'AP', 'AC'),
(156, 75, 'Institucion', 'institucion', 'Institucion', 1, 'AP', 'AC'),
(157, 75, 'Nuevainstitucion', 'nuevainstitucion', 'Nuevainstitucion', 1, 'AP', 'AC'),
(158, 75, 'Objetivogeneral', 'objetivogeneral', 'Objetivogeneral', 1, 'AP', 'AC'),
(159, 75, 'Objetivoespecificos', 'objetivoespecificos', 'Objetivoespecificos', 1, 'AP', 'AC'),
(160, 75, 'Agregarobjetivo', 'agregarobjetivo', 'Agregarobjetivo', 1, 'AP', 'AC'),
(161, 75, 'Quitarobjetivo', 'quitarobjetivo', 'Quitarobjetivo', 1, 'AP', 'AC'),
(162, 75, 'Descripcion', 'descripcion', 'Descripcion', 1, 'AP', 'AC'),
(163, 75, 'Director carrera', 'director_carrera', 'Director carrera', 1, 'AP', 'AC'),
(164, 75, 'Docente materia', 'docente_materia', 'Docente materia', 1, 'AP', 'AC'),
(165, 75, 'Responsable', 'responsable', 'Responsable', 1, 'AP', 'AC'),
(166, 75, 'Estudiante', 'estudiante', 'Estudiante', 1, 'AP', 'AC'),
(167, 75, 'Registrado por', 'registrado_por', 'Registrado por', 1, 'AP', 'AC'),
(168, 75, 'Fecha registro', 'fecha_registro', 'Fecha registro', 1, 'AP', 'AC'),
(169, 76, 'Semestre', 'semestre', 'Semestre', 1, 'AP', 'AC'),
(170, 77, 'Código', 'codigo', 'Registro de un semestre por código ejm. II-2014', 1, 'AP', 'AC'),
(171, 78, 'Codigo', 'codigo', 'código de semestre', 1, 'AP', 'AC'),
(172, 86, 'Nombre', 'nombre', 'Búsqueda del usuario mediante su Nombre registrado', 1, 'AP', 'AC'),
(173, 86, 'Apellido Paterno', 'apellido_paterno', 'Búsqueda del usuario mediante su apellido paterno registrado', 1, 'AP', 'AC'),
(174, 86, 'Apellido Materno', 'apellido_materno', 'Búsqueda del usuario mediante su apellido materno registrado', 1, 'AP', 'AC'),
(175, 86, 'Login', 'login', 'Búsqueda del usuario mediante su login registrado', 1, 'AP', 'AC'),
(176, 86, 'Email', 'email', 'Búsqueda del usuario mediante su Email registrado', 1, 'AP', 'AC'),
(177, 87, 'Nombre', 'nombre', 'Búsqueda del usuario mediante su Nombre registrado', 1, 'AP', 'AC'),
(178, 87, 'Apellido Paterno', 'apellido_paterno', 'Búsqueda del usuario mediante su Apellido paterno registrado', 1, 'AP', 'AC'),
(179, 87, 'Apellido Materno', 'apellido_materno', 'Búsqueda del usuario mediante su Apellido materno registrado', 1, 'AP', 'AC'),
(180, 87, 'Login', 'login', 'Búsqueda del usuario mediante su Nombre de Acceso registrado', 1, 'AP', 'AC'),
(181, 87, 'Email', 'email', 'Búsqueda del usuario mediante su correo electrónico valido registrado', 1, 'AP', 'AC'),
(182, 88, 'Nombre', 'nombre', 'Búsqueda del usuario mediante su Nombre registrado', 1, 'AP', 'AC'),
(183, 88, 'Apellido Paterno', 'apellido_paterno', 'Búsqueda del usuario mediante su Apellido Paterno registrado', 1, 'AP', 'AC'),
(184, 88, 'Apellido Materno', 'apellido_materno', 'Búsqueda del usuario mediante su Apellido materno registrado', 1, 'AP', 'AC'),
(185, 88, 'Login', 'login', 'Búsqueda del usuario mediante su nombre de acceso registrado', 1, 'AP', 'AC'),
(186, 88, 'Email', 'email', 'Búsqueda del usuario mediante su correo electrónico valido registrado', 1, 'AP', 'AC'),
(187, 91, 'Nombre', 'nombre', 'Búsqueda del usuario mediante su nombre registrado', 1, 'AP', 'AC'),
(188, 91, 'Apellido', 'apellido_paterno', 'Búsqueda del usuario mediante su apellido paterno registrado', 1, 'AP', 'AC'),
(189, 91, 'Apellido Mareno', 'apellido_materno', 'Búsqueda del usuario mediante su apellido materno registrado', 1, 'AP', 'AC'),
(190, 91, 'Login', 'login', 'Búsqueda del usuario mediante su nombre o login de acceso registrado', 1, 'AP', 'AC'),
(191, 91, 'Email', 'email', 'Búsqueda del usuario mediante su correo electrónico valido registrado', 1, 'AP', 'AC'),
(192, 91, 'Codigo Sis', 'codigo_sis', 'Búsqueda del usuario mediante su Código sis registrado', 1, 'AP', 'AC'),
(193, 97, 'Nombre Evento', 'nombre_evento', 'Búsqueda de evento mediante nombre evento registrado', 1, 'AP', 'AC'),
(194, 97, 'Detalle', 'detalle_evento', 'Búsqueda de evento mediante detalle registrado', 1, 'AP', 'AC'),
(195, 98, 'Código de Semestre', 'nombre', 'Registro de código de semestre', 1, 'AP', 'AC'),
(196, 98, 'Nombre del Evento', 'nombre_evento', 'Registro del nombre del evento', 1, 'AP', 'AC'),
(197, 98, 'Detalle', 'detalle_evento', 'Registro del detalle del cronograma', 1, 'AP', 'AC'),
(198, 98, 'Fecha de Evento', 'fecha_evento', 'Seleccionamos la fecha del evento', 1, 'AP', 'AC'),
(199, 110, 'Avance', 'archivos', 'Registro de Correciones', 1, 'AP', 'AC'),
(200, 110, 'Descripción', 'descripcion', 'Descripción del Avance o Correciones', 1, 'AP', 'AC'),
(201, 111, 'Estado', 'estado', 'Estado del avance realizado', 1, 'AP', 'AC'),
(202, 111, 'Descripcion', 'descripcion', 'Descripción del avance del estudiante', 1, 'AP', 'AC'),
(203, 113, 'Estado revisión', 'estado_revision', 'Estado revisión realizada por el docente', 1, 'AP', 'AC'),
(204, 113, 'Revisor tipo', 'revisor_tipo', 'Revisor tipo de docente o usuario', 1, 'AP', 'AC'),
(205, 113, 'Fecha revisión', 'fecha_revision', 'Fecha revisión de la corrección del docente', 1, 'AP', 'AC'),
(206, 114, 'Registro codigo sis', 'codigo_sis', 'Dato numerico del docente proporcionado por la univercidad', 1, 'AP', 'AC'),
(207, 114, 'Registro Cedula de Identidad', 'ci', 'Dato numerico de documento de identidad del docente', 1, 'AP', 'AC'),
(208, 114, 'Registro t&iacute;tulo Honorifico', 'titulo_honorifico', 'Es el grado de nivel academico del docente .', 1, 'AP', 'AC'),
(209, 114, 'Nombres Docente', 'nombre', 'Registro del los Nombres del docente', 1, 'AP', 'AC'),
(210, 114, 'Apellido Paterno', 'apellido_paterno', 'Registro del apellido paterno del docente', 1, 'AP', 'AC'),
(211, 114, 'Apellido Materno', 'apellido_materno', 'Apellido materno correspondiente al docente', 1, 'AP', 'AC'),
(212, 114, 'Registro Fecha de Nacimiento', 'fecha_nacimiento', 'Registro correspondiente ala fecha de nacimiento del docente', 1, 'AP', 'AC'),
(213, 114, 'email', 'email', 'Direccion de correo valida del docente', 1, 'AP', 'AC'),
(214, 114, 'Login', 'login', 'nombre de ususario de logeo del docente o inicio de secion en el sistema', 1, 'AP', 'AC'),
(215, 114, 'Clave de Ingreso', 'clave', 'clave de ingreso con el cual el docente tendra acceso al sistema', 1, 'AP', 'AC'),
(216, 114, 'Clave2', 'clave2', 'Clave verificada para ver si las claves coinciden', 1, 'AP', 'AC'),
(217, 114, 'Numero de horas disponibles del docente', 'numero de horas disponibles', 'la horas disponibles que trabaja un docente en la universidad', 1, 'AP', 'AC'),
(218, 115, 'Nombre', 'nombre', 'Registro del nombre del área a registrar', 1, 'AP', 'AC'),
(219, 115, 'Descripcion', 'descripcion', 'Descripción del área a registrar', 1, 'AP', 'AC'),
(220, 117, 'Nombre', 'nombre', 'Búsqueda del usuario mediante su Nombre registrado', 1, 'AP', 'AC'),
(221, 117, 'Apellido Paterno', 'apellido_paterno', 'Búsqueda del usuario mediante su Apellido Paterno registrado', 1, 'AP', 'AC'),
(222, 117, 'Apellido Materno', 'apellido_materno', 'Búsqueda del usuario mediante su Apellido Materno registrado', 1, 'AP', 'AC'),
(223, 117, 'Login', 'login', 'Búsqueda del usuario mediante su Login registrado', 1, 'AP', 'AC'),
(224, 117, 'Email', 'email', 'Búsqueda del usuario mediante su Email registrado', 1, 'AP', 'AC'),
(225, 120, 'Fecha', 'fecha', 'Fecha', 1, 'AP', 'AC'),
(226, 120, 'Observacion', 'observacion', 'Observacion', 1, 'AP', 'AC'),
(227, 122, 'Nuevainstitucion', 'nuevainstitucion', 'Nuevainstitucion', 1, 'AP', 'AC'),
(228, 123, 'Nombre', 'nombre', 'Búsqueda del usuario mediante su Nombre registrado.', 1, 'AP', 'AC'),
(229, 123, 'Apellido paterno', 'apellido_paterno', 'Búsqueda del usuario mediante su Apellido Paterno registrado.', 1, 'AP', 'AC'),
(230, 123, 'Apellido Materno', 'apellido_materno', 'Búsqueda del usuario mediante su Apellido materno registrado.', 1, 'AP', 'AC'),
(231, 123, 'Login', 'login', 'Búsqueda del usuario mediante su login o nombre de acceso al sistema registrado.', 1, 'AP', 'AC'),
(232, 123, 'Email', 'email', 'Búsqueda del usuario mediante su correo electrónico valido registrado', 1, 'AP', 'AC'),
(233, 123, 'Codigo Sis', 'codigo_sis', 'Búsqueda del usuario mediante su Código sis registrado', 1, 'AP', 'AC'),
(234, 124, 'Apellido paterno', 'apellido_paterno', 'Apellido paterno', 1, 'AP', 'AC'),
(235, 124, 'Apellido Paterno', 'apellido_materno', 'Búsqueda del usuario mediante su apellido materno registrado', 1, 'CL', 'AC'),
(236, 124, 'Nombre', 'nombre', 'Búsqueda del usuario mediante su apellido paterno registrado', 1, 'CL', 'AC'),
(237, 124, 'Numero', 'numero', 'Numero', 1, 'AP', 'AC'),
(238, 124, 'Telefono', 'telefono', 'Telefono', 1, 'AP', 'AC'),
(239, 124, 'email', 'email', 'Búsqueda del usuario mediante su correo electrónico valido registrado', 1, 'CL', 'AC'),
(240, 124, 'Tutor', 'tutor', 'Tutor', 1, 'AP', 'AC'),
(241, 124, 'Carrera de la Facultad', 'carrera_id', 'Es la carrera de facultad', 1, 'AP', 'AC'),
(242, 124, 'Trabajo conjunto', 'trabajo_conjunto', 'Trabajo conjunto', 1, 'AP', 'AC'),
(243, 124, 'Semestre', 'semestre', 'Semestre', 1, 'AP', 'AC'),
(244, 124, 'Cambio tema', 'cambio_tema', 'Cambio tema', 1, 'AP', 'AC'),
(245, 124, 'Proyecto nombre', 'proyecto_nombre', 'Proyecto nombre', 1, 'AP', 'AC'),
(246, 124, 'Areas', 'areas', 'Areas', 1, 'AP', 'AC'),
(247, 124, 'Subareas', 'subareas', 'Subareas', 1, 'AP', 'AC'),
(248, 124, 'Agregarareas', 'agregarareas', 'Agregarareas', 1, 'AP', 'AC'),
(249, 124, 'Nuevasubarea ', 'nuevasubarea ', 'Nuevasubarea ', 1, 'AP', 'AC'),
(250, 124, 'Quitarareas', 'quitarareas', 'Quitarareas', 1, 'AP', 'AC'),
(251, 124, 'Modalidad', 'modalidad', 'Modalidad', 1, 'AP', 'AC'),
(252, 124, 'Institucion', 'institucion', 'Institucion', 1, 'AP', 'AC'),
(253, 124, 'Nuevainstitucion', 'nuevainstitucion', 'Nuevainstitucion', 1, 'AP', 'AC'),
(254, 124, 'Objetivogeneral', 'objetivogeneral', 'Objetivogeneral', 1, 'AP', 'AC'),
(255, 124, 'Objetivoespecificos', 'objetivoespecificos', 'Objetivoespecificos', 1, 'AP', 'AC'),
(256, 124, 'Agregarobjetivo', 'agregarobjetivo', 'Agregarobjetivo', 1, 'AP', 'AC'),
(257, 124, 'Quitarobjetivo', 'quitarobjetivo', 'Quitarobjetivo', 1, 'AP', 'AC'),
(258, 124, 'Descripcion', 'descripcion', 'Descripcion', 1, 'AP', 'AC'),
(259, 124, 'Director carrera', 'director_carrera', 'Director carrera', 1, 'AP', 'AC'),
(260, 124, 'Docente materia', 'docente_materia', 'Docente materia', 1, 'AP', 'AC'),
(261, 124, 'Responsable', 'responsable', 'Responsable', 1, 'AP', 'AC'),
(262, 124, 'Estudiante', 'estudiante', 'Estudiante', 1, 'AP', 'AC'),
(263, 124, 'Registrado por', 'registrado_por', 'Registrado por', 1, 'AP', 'AC'),
(264, 124, 'Fecha registro', 'fecha_registro', 'Fecha registro', 1, 'AP', 'AC'),
(265, 126, 'codigo_sis', 'codigo_sis', 'Búsqueda del usuario mediante su Codigo sis registrado', 1, 'CL', 'AC'),
(266, 126, 'Ci', 'ci', 'Ci', 1, 'AP', 'AC'),
(267, 126, 'Nombre', 'nombre', 'Búsqueda del usuario mediante su apellido paterno registrado', 1, 'CL', 'AC'),
(268, 126, 'Apellido paterno', 'apellido_paterno', 'Apellido paterno', 1, 'AP', 'AC'),
(269, 126, 'Apellido Paterno', 'apellido_materno', 'Búsqueda del usuario mediante su apellido materno registrado', 1, 'CL', 'AC'),
(270, 126, 'Fecha nacimiento', 'fecha_nacimiento', 'Fecha nacimiento', 1, 'AP', 'AC'),
(271, 126, 'email', 'email', 'Búsqueda del usuario mediante su correo electrónico valido registrado', 1, 'CL', 'AC'),
(272, 126, 'Cambiar clave', 'cambiar_clave', 'Cambiar clave', 1, 'AP', 'AC'),
(273, 126, 'Clave', 'clave', 'Clave', 1, 'AP', 'AC'),
(274, 126, 'Clave2', 'clave2', 'Clave2', 1, 'AP', 'AC'),
(275, 126, 'Clave3', 'clave3', 'Clave3', 1, 'AP', 'AC'),
(276, 130, 'Nombre', 'nombre', 'Nombre del los lugares a realice la defensa del proyecto de tesis', 1, 'AP', 'AC'),
(277, 130, 'Descripción', 'descripcion', 'Una breve descripción sobre el lugar de defensa', 1, 'AP', 'AC'),
(278, 131, 'nombre', 'nombre', 'Búsqueda de lugar mediante la descripción registrada', 1, 'AP', 'AC'),
(279, 131, 'descripcion', 'descripcion', 'Búsqueda del lugar mediante la descripción registrada', 1, 'AP', 'AC'),
(280, 134, 'Login', 'login', 'Búsqueda del usuario mediante su nombre de acceso,login registrado', 1, 'CL', 'AC'),
(281, 134, 'Clave', 'clave', 'Clave', 1, 'AP', 'AC'),
(282, 137, 'Nombre', 'nombre', 'Búsqueda del usuario mediante su apellido paterno registrado', 1, 'CL', 'AC'),
(283, 137, 'Apellido paterno', 'apellido_paterno', 'Apellido paterno', 1, 'AP', 'AC'),
(284, 137, 'Apellido Paterno', 'apellido_materno', 'Búsqueda del usuario mediante su apellido materno registrado', 1, 'CL', 'AC'),
(285, 137, 'Login', 'login', 'Búsqueda del usuario mediante su nombre de acceso,login registrado', 1, 'CL', 'AC'),
(286, 137, 'email', 'email', 'Búsqueda del usuario mediante su correo electrónico valido registrado', 1, 'CL', 'AC'),
(287, 137, 'codigo_sis', 'codigo_sis', 'Búsqueda del usuario mediante su Codigo sis registrado', 1, 'CL', 'AC'),
(288, 138, 'Registro codigo sis', 'codigo_sis', 'es el registro de codigo sis del docente es un dato numerico', 1, 'AP', 'AC'),
(289, 138, 'Registro cedula de identidad', 'ci', 'la cedula de identidad es un dato numerico,es el documento q identifica a una persona', 1, 'AP', 'AC'),
(290, 138, 't&iacute;tulo honorfico', 'titulo_honorifico', 'regitro del titulo honorifico es el titulo o grado academico del docente', 1, 'AP', 'AC'),
(291, 138, 'Nombre', 'nombre', 'Búsqueda del usuario mediante su apellido paterno registrado', 1, 'CL', 'AC'),
(292, 138, 'Apellido paterno', 'apellido_paterno', 'Apellido paterno', 1, 'AP', 'AC'),
(293, 138, 'Apellido Paterno', 'apellido_materno', 'Búsqueda del usuario mediante su apellido materno registrado', 1, 'CL', 'AC'),
(294, 138, 'Fecha nacimiento', 'fecha_nacimiento', 'Fecha nacimiento', 1, 'AP', 'AC'),
(295, 138, 'email', 'email', 'Búsqueda del usuario mediante su correo electrónico valido registrado', 1, 'CL', 'AC'),
(296, 138, 'Login', 'login', 'Búsqueda del usuario mediante su nombre de acceso,login registrado', 1, 'CL', 'AC'),
(297, 138, 'Clave', 'clave', 'Clave', 1, 'AP', 'AC'),
(298, 138, 'Clave2', 'clave2', 'Clave2', 1, 'AP', 'AC'),
(299, 138, 'Numero de horas disponibles', 'numero de horas disponibles', 'Numero de horas disponibles', 1, 'AP', 'AC'),
(300, 141, 'Nombre', 'nombre', 'Búsqueda del usuario mediante su apellido paterno registrado', 1, 'CL', 'AC'),
(301, 141, 'Apellido paterno', 'apellido_paterno', 'Apellido paterno', 1, 'AP', 'AC'),
(302, 141, 'Apellido Paterno', 'apellido_materno', 'Búsqueda del usuario mediante su apellido materno registrado', 1, 'CL', 'AC'),
(303, 141, 'Login', 'login', 'Búsqueda del usuario mediante su nombre de acceso,login registrado', 1, 'CL', 'AC'),
(304, 141, 'email', 'email', 'Búsqueda del usuario mediante su correo electrónico valido registrado', 1, 'CL', 'AC'),
(305, 141, 'Registro codigo sis', 'codigo_sis', 'es el registro de codigo sis del docente es un dato numerico', 1, 'CL', 'AC'),
(306, 142, 'Estado impresion', 'estado_impresion', 'Estado impresion', 1, 'AP', 'AC'),
(307, 142, 'Tipo proyecto', 'tipo_proyecto', 'Tipo proyecto', 1, 'AP', 'AC'),
(308, 142, 'Estado proyecto', 'estado_proyecto', 'Estado proyecto', 1, 'AP', 'AC'),
(309, 142, 'T&iacute;tulo', 'titulo', 'Titulo', 1, 'AP', 'AC'),
(310, 142, 'Descripcion', 'descripcion', 'Descripcion', 1, 'AP', 'AC'),
(311, 144, 'Nombre', 'nombre', 'Búsqueda del usuario mediante su apellido paterno registrado', 1, 'CL', 'AC'),
(312, 144, 'Apellido paterno', 'apellido_paterno', 'Apellido paterno', 1, 'AP', 'AC'),
(313, 144, 'Apellido Paterno', 'apellido_materno', 'Búsqueda del usuario mediante su apellido materno registrado', 1, 'CL', 'AC'),
(314, 144, 'Login', 'login', 'Búsqueda del usuario mediante su nombre de acceso,login registrado', 1, 'CL', 'AC'),
(315, 144, 'email', 'email', 'Búsqueda del usuario mediante su correo electrónico valido registrado', 1, 'CL', 'AC'),
(316, 145, 'Nombre', 'nombre', 'Búsqueda del usuario mediante su apellido paterno registrado', 1, 'CL', 'AC'),
(317, 145, 'Apellido paterno', 'apellido_paterno', 'Apellido paterno', 1, 'AP', 'AC'),
(318, 145, 'Apellido Paterno', 'apellido_materno', 'Búsqueda del usuario mediante su apellido materno registrado', 1, 'CL', 'AC'),
(319, 145, 'Login', 'login', 'Búsqueda del usuario mediante su nombre de acceso,login registrado', 1, 'CL', 'AC'),
(320, 145, 'email', 'email', 'Búsqueda del usuario mediante su correo electrónico valido registrado', 1, 'CL', 'AC'),
(321, 146, 'Nombre', 'nombre', 'Búsqueda del usuario mediante su apellido paterno registrado', 1, 'CL', 'AC'),
(322, 146, 'Apellido paterno', 'apellido_paterno', 'Apellido paterno', 1, 'AP', 'AC'),
(323, 146, 'Apellido Paterno', 'apellido_materno', 'Búsqueda del usuario mediante su apellido materno registrado', 1, 'CL', 'AC'),
(324, 146, 'Login', 'login', 'Búsqueda del usuario mediante su nombre de acceso,login registrado', 1, 'CL', 'AC'),
(325, 146, 'email', 'email', 'Búsqueda del usuario mediante su correo electrónico valido registrado', 1, 'CL', 'AC'),
(326, 147, 'Nombre', 'nombre', 'Búsqueda del usuario mediante su apellido paterno registrado', 1, 'CL', 'AC'),
(327, 147, 'Apellido paterno', 'apellido_paterno', 'Apellido paterno', 1, 'AP', 'AC'),
(328, 147, 'Apellido Paterno', 'apellido_materno', 'Búsqueda del usuario mediante su apellido materno registrado', 1, 'CL', 'AC'),
(329, 147, 'Login', 'login', 'Búsqueda del usuario mediante su nombre de acceso,login registrado', 1, 'CL', 'AC'),
(330, 147, 'email', 'email', 'Búsqueda del usuario mediante su correo electrónico valido registrado', 1, 'CL', 'AC'),
(331, 149, 'Estado', 'estado_helpdesk', 'busqueda mediante estadis del temas de ayuda', 1, 'AP', 'AC'),
(332, 149, 'Descripcion', 'descripcion', 'Búsqueda mediante descripcion de temas de ayudaregistrado', 1, 'AP', 'AC'),
(333, 149, 'Claves', 'keywords', 'Busqueda mediante palabras claves registrado', 1, 'AP', 'AC'),
(334, 150, 'T&iacute;tulo', 'titulo', 'Titulo', 1, 'AP', 'AC'),
(335, 150, 'Descripcion', 'descripcion', 'Descripcion', 1, 'AP', 'AC'),
(336, 150, 'Keywords', 'keywords', 'Keywords', 1, 'AP', 'AC'),
(337, 151, 'Apellido Paterno', 'apellido_paterno', 'Aellido paterno registrado de Estudiante', 1, 'AP', 'AC'),
(338, 151, 'Apellido Materno', 'apellido_materno', 'Apellido materno registrado de Estudiante', 1, 'AP', 'AC'),
(339, 151, 'Nombre', 'nombre', 'Nombre de estudiante registrado', 1, 'AP', 'AC'),
(340, 151, 'Numero', 'numero', 'Numero', 1, 'AP', 'AC'),
(341, 151, 'Telefono', 'telefono', 'Numero telefono del Estudiante', 1, 'AP', 'AC'),
(342, 151, 'email', 'email', 'Correo electronico registrado', 1, 'AP', 'AC'),
(343, 151, 'Tutor', 'tutor', 'Tutor', 1, 'AP', 'AC'),
(344, 151, 'Carrera', 'carrera_id', 'Carrera ala q pertenece el estudiante', 1, 'AP', 'AC'),
(345, 151, 'Trabajo Conjunto', 'trabajo_conjunto', 'Tipificar si el proyecto el de trabajo grupal o no', 1, 'AP', 'AC'),
(346, 151, 'Semestre', 'semestre', 'Semestre de registro de perfil del estudiante', 1, 'AP', 'AC'),
(347, 151, 'Cambio de Tema', 'cambio_tema', 'Tipificar si el registro de perfil es cambio de tema o no', 1, 'AP', 'AC'),
(348, 151, 'T&iacute;tulo del Proyecto', 'proyecto_nombre', 'Titulo del proyecto de perfil a registrar', 1, 'AP', 'AC'),
(349, 151, 'Areas', 'areas', 'Areas', 1, 'AP', 'AC'),
(350, 151, 'Subareas', 'subareas', 'Subareas', 1, 'AP', 'AC'),
(351, 151, 'Agregarareas', 'agregarareas', 'Agregarareas', 1, 'AP', 'AC'),
(352, 151, 'Nuevasubarea ', 'nuevasubarea ', 'Nuevasubarea ', 1, 'AP', 'AC'),
(353, 151, 'Quitarareas', 'quitarareas', 'Quitarareas', 1, 'AP', 'AC'),
(354, 151, 'Modalida', 'modalidad', 'La modalidad de Titulacion ala que pertenece el proyecto', 1, 'AP', 'AC'),
(355, 151, 'Institucion', 'institucion', 'Institucion', 1, 'AP', 'AC'),
(356, 151, 'Nuevainstitucion', 'nuevainstitucion', 'Nuevainstitucion', 1, 'AP', 'AC'),
(357, 151, 'Objetivo General', 'objetivogeneral', 'El Objetivo general del proeycto', 1, 'AP', 'AC'),
(358, 151, 'Objetivo Especificos', 'objetivoespecificos', 'Los objetivos especificos del Sistema', 1, 'AP', 'AC'),
(359, 151, 'Agregarobjetivo', 'agregarobjetivo', 'Agregarobjetivo', 1, 'AP', 'AC'),
(360, 151, 'Quitarobjetivo', 'quitarobjetivo', 'Quitarobjetivo', 1, 'AP', 'AC'),
(361, 151, 'Descripcion', 'descripcion', 'Registro de la descripcion del proyecto de perfil', 1, 'AP', 'AC'),
(362, 151, 'Director Carrera', 'director_carrera', 'Nombre del Director de carrera actual', 1, 'AP', 'AC'),
(363, 151, 'Docente Materia', 'docente_materia', 'docente de la materia del estudiante', 1, 'AP', 'AC'),
(364, 151, 'Responsable', 'responsable', 'Responsable', 1, 'AP', 'AC'),
(365, 151, 'Estudiante', 'estudiante', 'Nombre completo del Estudiante', 1, 'AP', 'AC'),
(366, 151, 'Registrado por', 'registrado_por', 'Nombre del usuario por el cual se esta registrando', 1, 'AP', 'AC'),
(367, 151, 'Fecha Registro', 'fecha_registro', 'Fecha de registro de perfil del estudiante', 1, 'AP', 'AC'),
(368, 152, 'T&iacute;tulo', 'titulo', 'Titulo', 1, 'AP', 'AC'),
(369, 152, 'Descripcion', 'descripcion', 'Descripcion', 1, 'AP', 'AC'),
(370, 152, 'Keywords', 'keywords', 'Keywords', 1, 'AP', 'AC'),
(371, 154, 'Cedula de Identidad', 'ci', 'Documento de identidad del tutor es un dato numerico', 1, 'AP', 'AC'),
(372, 154, 'T&iacute;tulo Honorifico', 'titulo_honorifico', 'En este caso es el identificador del tutor del grado academico.', 1, 'AP', 'AC'),
(373, 154, 'Nombre', 'nombre', 'Nombre del tutor', 1, 'AP', 'AC'),
(374, 154, 'Apellido Paterno', 'apellido_paterno', 'Apellido Paterno del tutor', 1, 'AP', 'AC'),
(375, 154, 'Apellido Materno', 'apellido_materno', 'Apellido materno registro tutor', 1, 'AP', 'AC'),
(376, 154, 'Fecha de Nacimiento', 'fecha_nacimiento', 'Fecha de nacimiento del tutor', 1, 'AP', 'AC'),
(377, 154, 'email', 'email', 'Correo electronico valido', 1, 'AP', 'AC'),
(378, 154, 'Login', 'login', 'login o su nombre de acseso al sistema', 1, 'AP', 'AC'),
(379, 154, 'Clave', 'clave', 'Clave de ingreso o password del tutor para el acceso al sistema', 1, 'AP', 'AC'),
(380, 154, 'Verificacion de clave de ingreso', 'clave2', 'Se verifica la clave q ingreso el usuario al principio', 1, 'CL', 'AC'),
(381, 155, 'Estado', 'estado', 'Búsqueda mediante Estado registrado', 1, 'AP', 'AC'),
(382, 155, 'Codigo', 'codigo', 'Búsqueda del permiso mediante su Codigo registrado', 1, 'AP', 'AC'),
(383, 155, 'Descripcion', 'descripcion', 'Búsqueda del permiso segun la descripcion registrada', 1, 'AP', 'AC'),
(384, 156, 'Codigo', 'codigo', 'Registro del nombre de un grupo de usuarios del sistema', 1, 'AP', 'AC'),
(385, 156, 'Descripcion', 'descripcion', 'Descripción del Grupo de usuario', 1, 'AP', 'AC'),
(386, 158, 'Nombre', 'nombre', 'Búsqueda del usuario mediante su nombre registrado', 1, 'AP', 'AC'),
(387, 158, 'Apellido Paterno', 'apellido_paterno', 'Búsqueda del usuario mediante su apellido paterno registrado', 1, 'AP', 'AC'),
(388, 158, 'Apellido Materno', 'apellido_materno', 'Búsqueda del usuario mediante su apellido materno registrado', 1, 'AP', 'AC'),
(389, 158, 'Login', 'login', 'Búsqueda del usuario mediante su login o su nombre de acseso al asitema', 1, 'AP', 'AC'),
(390, 158, 'email', 'email', 'Búsqueda del usuario mediante su correo electronico registrado', 1, 'AP', 'AC'),
(391, 158, 'Codigo Sis', 'codigo_sis', 'Búsqueda del usuario mediante su codigo sis', 1, 'AP', 'AC'),
(392, 160, 'Estado', 'estado_helpdesk', 'busqueda mediante estadis del temas de ayuda', 1, 'CL', 'AC'),
(393, 160, 'Descripcion', 'descripcion', 'Busqueda del permiso segun la descripcion registrada', 1, 'AP', 'AC'),
(394, 160, 'Claves', 'keywords', 'Busqueda mediante palabras claves registrado', 1, 'AP', 'AC'),
(395, 161, 'Estado', 'estado_impresion', 'Busqueda de Cartas mediate Estado de registro.', 1, 'AP', 'AC'),
(396, 161, 'Tipo Proyecto', 'tipo_proyecto', 'Busqueda de Cartas mediante su Tipo Proyecto registrado', 1, 'AP', 'AC'),
(397, 161, 'Estado Proyecto', 'estado_proyecto', 'Busqueda de Cartas mediante su Estado del Proyecto registrado', 1, 'AP', 'AC'),
(398, 161, 'T&iacute;tulo', 'titulo', 'Busqueda de Cartas mediante su Titulo registrado', 1, 'AP', 'AC'),
(399, 161, 'Descripcion', 'descripcion', 'Busqueda de cartas segun la descripcion registrada', 1, 'AP', 'AC'),
(400, 163, 'Estado', 'estado_notificacion', 'Búsqueda de notificaciones mediante Estado registrado', 1, 'AP', 'AC'),
(401, 163, 'Tipo de Mensaje', 'tipo', 'Búsqueda de notificaciones mediante Tipo de Mensaje registrado', 1, 'AP', 'AC'),
(402, 163, 'Asunto', 'asunto', 'Búsqueda de notificaciones mediante Asunto registrado', 1, 'AP', 'AC'),
(403, 163, 'Mensaje', 'detalle', 'Búsqueda de notificaciones mediante mensaje registrado', 1, 'AP', 'AC'),
(404, 164, 'Nombre', 'nombre', 'Busqueda del valores del semestre mediante su nombre registrado', 1, 'AP', 'AC'),
(405, 164, 'Valor', 'valor', 'Búsqueda de variables de semestre por valor', 1, 'AP', 'AC'),
(406, 166, 'Nombre', 'nombre', 'Búsqueda del Área mediante su nombre registrado', 1, 'AP', 'AC'),
(407, 166, 'Descripcion', 'descripcion', 'Busqueda del área según la descripción registrada', 1, 'AP', 'AC'),
(408, 167, 'Nombre', 'nombre', 'Búsqueda de carreras mediante su nombre registrado', 1, 'AP', 'AC'),
(409, 168, 'Nombre Carrera', 'nombre', 'Nombre de las carrera', 1, 'AP', 'AC'),
(410, 169, 'Nombre', 'nombre', 'Búsqueda de la institución mediante su nombre registrado', 1, 'AP', 'AC'),
(411, 169, 'Descripcion', 'descripcion', 'Búsqueda de la institución según la descripción registrada', 1, 'AP', 'AC'),
(412, 170, 'Nombre Institución', 'nombre', 'Registro de las instituciones con a que van dirigidas los proyectos', 1, 'AP', 'AC'),
(413, 170, 'Descripción', 'descripcion', 'Registro de una breve descripción sobre la Institución', 1, 'AP', 'AC'),
(414, 171, 'Nombre', 'nombre', 'Búsqueda del modalidad mediante su nombre registrado', 1, 'AP', 'AC'),
(415, 171, 'Descripcion', 'descripcion', 'Búsqueda de modalidad según la descripción registrada', 1, 'AP', 'AC'),
(416, 172, 'Nombre Modalidad', 'nombre', 'Registro de la modalidad de titulación del estudiante', 1, 'AP', 'AC'),
(417, 172, 'Descripción', 'descripcion', 'Una descripción referente ala Modalidad', 1, 'AP', 'AC'),
(418, 172, 'Datos', 'datos', 'hace referencia si la modalidad requiere de  de una institución o responsable', 1, 'AP', 'AC'),
(419, 173, 'Nombre', 'nombre', 'Busqueda del titulo honorifico mediante su nombre registrado', 1, 'AP', 'AC'),
(420, 173, 'Descripcion', 'descripcion', 'Búsqueda del titulo honorifico según la descripción registrada', 1, 'AP', 'AC'),
(421, 174, 'Nombre', 'nombre', 'Nombre del titulo o grado academico del usuario', 1, 'AP', 'AC'),
(422, 174, 'Descripcion', 'descripcion', 'Descripcion del grado academico', 1, 'AP', 'AC'),
(423, 175, 'Nombre', 'nombre', 'Búsqueda del Grupo de materia mediante su nombre registrado', 1, 'AP', 'AC'),
(424, 176, 'Código de grupo', 'nombre', 'Código q identifica al los distintos grupos de una materia', 1, 'AP', 'AC'),
(425, 178, 'Login', 'login', 'busqueda del docente mediante su login o su nombre de acseso al asitema', 1, 'CL', 'AC'),
(426, 178, 'Clave', 'clave', 'Clave de ingreso o password del estudiante para el acceso al sistema', 1, 'CL', 'AC'),
(427, 181, 'Estado', 'estado', 'Búsqueda mediante Estado registrado', 1, 'CL', 'AC'),
(428, 181, 'Codigo', 'codigo', 'Búsqueda del permiso mediante su Codigo registrado', 1, 'CL', 'AC'),
(429, 181, 'Descripcion', 'descripcion', 'Búsqueda del permiso segun la descripcion registrada', 1, 'CL', 'AC'),
(430, 182, 'Estado tooltip', 'estado_tooltip', 'Estado tooltip', 1, 'AP', 'AC'),
(431, 182, 'Codigo', 'codigo', 'Búsqueda del permiso mediante su Codigo registrado', 1, 'CL', 'AC'),
(432, 182, 'T&iacute;tulo', 'titulo', 'Búsqueda de Cartas mediante la Titulo registrada', 1, 'CL', 'AC'),
(433, 182, 'Descripcion', 'descripcion', 'Búsqueda del permiso segun la descripcion registrada', 1, 'CL', 'AC'),
(434, 183, 'Estado', 'estado_helpdesk', 'busqueda mediante estadis del temas de ayuda', 1, 'CL', 'AC'),
(435, 183, 'Descripcion', 'descripcion', 'Búsqueda del permiso segun la descripcion registrada', 1, 'CL', 'AC'),
(436, 183, 'Claves', 'keywords', 'Busqueda mediante palabras claves registrado', 1, 'CL', 'AC'),
(437, 195, 'Nombre', 'nombre', 'Búsqueda del usuario mediante su nombre registrado', 1, 'CL', 'AC'),
(438, 195, 'Apellido Paterno', 'apellido_paterno', 'Búsqueda del docente mediante su apellido paterno registrado', 1, 'CL', 'AC'),
(439, 195, 'Apellido Materno', 'apellido_materno', 'Búsqueda del docente mediante su apellido materno registrado', 1, 'CL', 'AC'),
(440, 195, 'Login', 'login', 'Búsqueda del docente mediante su login o su nombre de acceso al sistema', 1, 'CL', 'AC'),
(441, 195, 'email', 'email', 'Búsqueda del usuario mediante su correo electrónico registrado', 1, 'CL', 'AC'),
(442, 195, 'Codigo Sis', 'codigo_sis', 'Búsqueda del docente mediante su código sis', 1, 'CL', 'AC'),
(443, 197, 'Nombre', 'nombre', 'Búsqueda del usuario mediante su nombre registrado', 1, 'CL', 'AC'),
(444, 197, 'Descripcion', 'descripcion', 'Búsqueda del permiso segun la descripcion registrada', 1, 'CL', 'AC'),
(445, 198, 'Nombre', 'nombre', 'Búsqueda del usuario mediante su nombre registrado', 1, 'CL', 'AC'),
(446, 198, 'Descripcion', 'descripcion', 'Búsqueda del permiso segun la descripcion registrada', 1, 'CL', 'AC'),
(447, 200, 'Nombre', 'nombre', 'Búsqueda del usuario mediante su nombre registrado', 1, 'CL', 'AC'),
(448, 200, 'Nombre Evento', 'nombre_evento', 'Búsqueda de evento mediante nombre evento registrado', 1, 'CL', 'AC'),
(449, 200, 'Detalle', 'detalle_evento', 'Búsqueda de evento mediante detalle registrado', 1, 'CL', 'AC'),
(450, 200, 'Fecha de Evento', 'fecha_evento', 'Seleccionamos la fecha del evento', 1, 'CL', 'AC'),
(451, 205, 'Estado tooltip', 'estado_tooltip', 'Estado tooltip', 1, 'AP', 'AC'),
(452, 205, 'Codigo', 'codigo', 'Búsqueda del permiso mediante su Codigo registrado', 1, 'CL', 'AC'),
(453, 205, 'T&iacute;tulo', 'titulo', 'Búsqueda de Cartas mediante la Titulo registrada', 1, 'CL', 'AC'),
(454, 205, 'Descripcion', 'descripcion', 'Búsqueda del permiso segun la descripcion registrada', 1, 'CL', 'AC'),
(455, 207, 'T&iacute;tulo', 'titulo', 'Búsqueda de Cartas mediante la Titulo registrada', 1, 'CL', 'AC'),
(456, 207, 'Descripcion', 'descripcion', 'Búsqueda del permiso segun la descripcion registrada', 1, 'CL', 'AC'),
(457, 212, 'Nombre', 'nombre', 'Búsqueda del usuario mediante su nombre registrado', 1, 'CL', 'AC'),
(458, 212, 'Valor', 'valor', 'Búsqueda de variables de semestre por valor', 1, 'CL', 'AC'),
(459, 213, 'Nombre', 'nombre', 'Búsqueda del nombre del foro mediante su nombre registrado', 1, 'AP', 'AC'),
(460, 213, 'Descripcion', 'descripcion', 'Búsqueda del foro segun la descripcion registrada', 1, 'AP', 'AC'),
(461, 214, 'Nombre', 'nombre', 'Búsqueda del usuario mediante su nombre registrado', 1, 'CL', 'AC'),
(462, 214, 'Descripcion', 'descripcion', 'Búsqueda del permiso segun la descripcion registrada', 1, 'CL', 'AC'),
(463, 215, 'Nombre', 'nombre', 'Búsqueda del usuario mediante su nombre registrado', 1, 'CL', 'AC'),
(464, 215, 'Descripcion', 'descripcion', 'Búsqueda del permiso segun la descripcion registrada', 1, 'CL', 'AC'),
(465, 216, 'Nombre', 'nombre', 'Búsqueda del usuario mediante su nombre registrado', 1, 'CL', 'AC'),
(466, 216, 'Descripcion', 'descripcion', 'Búsqueda del permiso segun la descripcion registrada', 1, 'CL', 'AC'),
(467, 217, 'Nombre', 'nombre', 'Búsqueda del usuario mediante su nombre registrado', 1, 'CL', 'AC'),
(468, 217, 'Descripcion', 'descripcion', 'Búsqueda del permiso segun la descripcion registrada', 1, 'CL', 'AC'),
(469, 221, 'Nombre', 'nombre', 'Búsqueda del usuario mediante su nombre registrado', 1, 'CL', 'AC'),
(470, 221, 'Fecha inicio', 'fecha_inicio', 'Fecha inicio', 1, 'AP', 'AC'),
(471, 221, 'Fecha fin', 'fecha_fin', 'Fecha fin', 1, 'AP', 'AC'),
(472, 221, 'Descripcion', 'descripcion', 'Búsqueda del permiso segun la descripcion registrada', 1, 'CL', 'AC'),
(473, 222, 'Fecha inicio', 'fecha_inicio', 'Fecha inicio', 1, 'AP', 'AC'),
(474, 222, 'Fecha fin', 'fecha_fin', 'Fecha fin', 1, 'AP', 'AC'),
(475, 222, 'Descripcion', 'descripcion', 'Búsqueda del permiso segun la descripcion registrada', 1, 'CL', 'AC'),
(476, 56, 'Codigo', 'codigo', 'Búsqueda del permiso mediante su Codigo registrado', 1, 'CL', 'AC'),
(477, 228, 'Nombre', 'nombre', 'Búsqueda del usuario mediante su nombre registrado', 1, 'CL', 'AC'),
(478, 228, 'Apellido Paterno', 'apellido_paterno', 'Búsqueda del docente mediante su apellido paterno registrado', 1, 'CL', 'AC'),
(479, 228, 'Apellido Materno', 'apellido_materno', 'Búsqueda del docente mediante su apellido materno registrado', 1, 'CL', 'AC'),
(480, 228, 'Login', 'login', 'Búsqueda del docente mediante su login o su nombre de acceso al sistema', 1, 'CL', 'AC'),
(481, 228, 'email', 'email', 'Búsqueda del usuario mediante su correo electrónico registrado', 1, 'CL', 'AC'),
(482, 228, 'Codigo Sis', 'codigo_sis', 'Búsqueda del docente mediante su código sis', 1, 'CL', 'AC'),
(483, 229, 'Codigo Sis', 'codigo_sis', 'Búsqueda del docente mediante su código sis', 1, 'CL', 'AC'),
(484, 229, 'Cedula de Identidad', 'ci', 'Documento de identidad del estudiante es un dato numerico', 1, 'CL', 'AC'),
(485, 229, 'Título Honorifico', 'titulo_honorifico', 'En este caso es el identificador del estudiante.', 1, 'CL', 'AC'),
(486, 229, 'Nombre', 'nombre', 'Búsqueda del usuario mediante su nombre registrado', 1, 'CL', 'AC'),
(487, 229, 'Apellido Paterno', 'apellido_paterno', 'Búsqueda del docente mediante su apellido paterno registrado', 1, 'CL', 'AC'),
(488, 229, 'Apellido Materno', 'apellido_materno', 'Búsqueda del docente mediante su apellido materno registrado', 1, 'CL', 'AC'),
(489, 229, 'Fecha de Nacimiento', 'fecha_nacimiento', 'Fecha de nacimiento del estudiante', 1, 'CL', 'AC'),
(490, 229, 'email', 'email', 'Búsqueda del usuario mediante su correo electrónico registrado', 1, 'CL', 'AC'),
(491, 229, 'Login', 'login', 'Búsqueda del docente mediante su login o su nombre de acceso al sistema', 1, 'CL', 'AC'),
(492, 229, 'Clave', 'clave', 'Ingrese  su password de acceso al sistema', 1, 'CL', 'AC'),
(493, 229, 'Verificacion de clave de ingreso', 'clave2', 'Se verifica la clave q ingreso el usuario al principio', 1, 'CL', 'AC'),
(494, 232, 'Nombre', 'nombre', 'Búsqueda del usuario mediante su nombre registrado', 1, 'CL', 'AC'),
(495, 232, 'Descripcion', 'descripcion', 'Descripcion', 1, 'CL', 'AC'),
(496, 239, 'Nombre', 'nombre', 'Búsqueda del usuario mediante su nombre registrado', 1, 'CL', 'AC'),
(497, 239, 'Descripcion', 'descripcion', 'Descripcion', 1, 'CL', 'AC'),
(498, 241, 'Nombre', 'nombre', 'Búsqueda del usuario mediante su nombre registrado', 1, 'CL', 'AC'),
(499, 241, 'Fecha inicio', 'fecha_inicio', 'Fecha inicio', 1, 'CL', 'AC'),
(500, 241, 'Fecha fin', 'fecha_fin', 'Fecha fin', 1, 'CL', 'AC'),
(501, 241, 'Descripcion', 'descripcion', 'Descripcion', 1, 'CL', 'AC'),
(502, 242, 'Fecha inicio', 'fecha_inicio', 'Fecha inicio', 1, 'CL', 'AC'),
(503, 242, 'Fecha fin', 'fecha_fin', 'Fecha fin', 1, 'CL', 'AC'),
(504, 242, 'Descripcion', 'descripcion', 'Descripcion', 1, 'CL', 'AC'),
(505, 77, 'Fecha inicio', 'fecha_inicio', 'Fecha inicio', 1, 'CL', 'AC'),
(506, 77, 'Fecha fin', 'fecha_fin', 'Fecha fin', 1, 'CL', 'AC'),
(507, 78, 'Fecha inicio', 'fecha_inicio', 'Fecha inicio', 1, 'CL', 'AC'),
(508, 78, 'Fecha fin', 'fecha_fin', 'Fecha fin', 1, 'CL', 'AC'),
(509, 243, 'Nombre', 'nombre', 'Búsqueda del usuario mediante su nombre registrado', 1, 'CL', 'AC'),
(510, 243, 'Apellido paterno', 'apellido_paterno', 'Apellido paterno', 1, 'CL', 'AC'),
(511, 243, 'Apellido Materno', 'apellido_materno', 'Búsqueda del docente mediante su apellido materno registrado', 1, 'CL', 'AC'),
(512, 243, 'Login', 'login', 'Búsqueda del docente mediante su login o su nombre de acceso al sistema', 1, 'CL', 'AC'),
(513, 243, 'email', 'email', 'Búsqueda del usuario mediante su correo electrónico registrado', 1, 'CL', 'AC'),
(514, 243, 'Codigo Sis', 'codigo_sis', 'Búsqueda del docente mediante su código sis', 1, 'CL', 'AC'),
(515, 110, 'avance', 'avance', 'avance', 1, 'RC', 'AC'),
(516, 185, 'avance', 'avance', 'avance', 1, 'RC', 'AC'),
(517, 54, 'Cambiar clave', 'cambiar_clave', 'Cambiar clave', 1, 'CL', 'AC'),
(518, 54, 'Clave3', 'clave3', 'Clave3', 1, 'CL', 'AC'),
(519, 246, 'Semestre', 'semestre', 'Semestre', 1, 'CL', 'AC');
INSERT INTO `tooltip` (`id`, `helpdesk_id`, `titulo`, `codigo`, `descripcion`, `mostrar`, `estado_tooltip`, `estado`) VALUES
(520, 110, 'avance_especifico', 'avance_especifico', 'avance_especifico', 1, 'RC', 'AC'),
(521, 185, 'avance_especifico', 'avance_especifico', 'avance_especifico', 1, 'RC', 'AC'),
(522, 112, 'avance', 'avance', 'avance', 1, 'RC', 'AC'),
(523, 112, 'avance_especifico', 'avance_especifico', 'avance_especifico', 1, 'RC', 'AC'),
(524, 248, 'Nombre', 'nombre', 'Búsqueda del usuario mediante su nombre registrado', 1, 'CL', 'AC'),
(525, 248, 'Valor', 'valor', 'Búsqueda de variables de semestre por valor', 1, 'CL', 'AC');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tribunal`
--

DROP TABLE IF EXISTS `tribunal`;
CREATE TABLE IF NOT EXISTS `tribunal` (
`id` int(11) NOT NULL,
  `docente_id` int(11) NOT NULL,
  `proyecto_id` int(11) NOT NULL,
  `detalle` text,
  `accion` varchar(2) DEFAULT NULL COMMENT 'aceptar , rechazar',
  `visto` varchar(2) DEFAULT NULL COMMENT 'no visto (NV), Visto(V)',
  `fecha_asignacion` date DEFAULT NULL,
  `fecha_aceptacion` date DEFAULT NULL,
  `semestre` varchar(45) DEFAULT NULL,
  `visto_bueno` varchar(2) DEFAULT NULL,
  `fecha_vistobueno` date DEFAULT NULL,
  `nota_tribunal` int(11) DEFAULT NULL,
  `estado` varchar(2) DEFAULT NULL COMMENT 'Activo sera AC, No activo NC, Eliminado DE'
) ENGINE=InnoDB AUTO_INCREMENT=57 DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `tribunal`
--

INSERT INTO `tribunal` (`id`, `docente_id`, `proyecto_id`, `detalle`, `accion`, `visto`, `fecha_asignacion`, `fecha_aceptacion`, `semestre`, `visto_bueno`, `fecha_vistobueno`, `nota_tribunal`, `estado`) VALUES
(1, 0, 0, '', 'AC', '', '0000-00-00', '0000-00-00', '', '', '0000-00-00', 0, NULL),
(2, 0, 0, '', 'AC', '', '0000-00-00', '0000-00-00', '', '', '0000-00-00', 0, NULL),
(3, 0, 0, '', 'AC', '', '0000-00-00', '0000-00-00', '', '', '0000-00-00', 0, NULL),
(4, 0, 0, '', 'AC', '', '0000-00-00', '0000-00-00', '', '', '0000-00-00', 0, NULL),
(5, 0, 0, '', 'AC', '', '0000-00-00', '0000-00-00', '', '', '0000-00-00', 0, NULL),
(6, 0, 0, '', 'AC', '', '0000-00-00', '0000-00-00', '', '', '0000-00-00', 0, NULL),
(7, 0, 0, '', 'AC', '', '0000-00-00', '0000-00-00', '', '', '0000-00-00', 0, NULL),
(8, 0, 0, '', 'AC', '', '0000-00-00', '0000-00-00', '', '', '0000-00-00', 0, NULL),
(9, 0, 0, '', 'AC', '', '0000-00-00', '0000-00-00', '', '', '0000-00-00', 0, NULL),
(10, 0, 0, '', 'AC', '', '0000-00-00', '0000-00-00', '', '', '0000-00-00', 0, NULL),
(11, 0, 0, '', 'AC', '', '0000-00-00', '0000-00-00', '', '', '0000-00-00', 0, NULL),
(12, 0, 0, '', 'AC', '', '0000-00-00', '0000-00-00', '', '', '0000-00-00', 0, NULL),
(13, 0, 0, '', 'AC', '', '0000-00-00', '0000-00-00', '', '', '0000-00-00', 0, NULL),
(14, 0, 0, '', 'AC', '', '0000-00-00', '0000-00-00', '', '', '0000-00-00', 0, NULL),
(15, 0, 0, '', 'AC', '', '0000-00-00', '0000-00-00', '', '', '0000-00-00', 0, NULL),
(16, 0, 0, '', 'AC', '', '0000-00-00', '0000-00-00', '', '', '0000-00-00', 0, NULL),
(17, 0, 0, '', 'AC', '', '0000-00-00', '0000-00-00', '', '', '0000-00-00', 0, NULL),
(18, 0, 0, '', 'AC', '', '0000-00-00', '0000-00-00', '', '', '0000-00-00', 0, NULL),
(19, 0, 0, '', 'AC', '', '0000-00-00', '0000-00-00', '', '', '0000-00-00', 0, NULL),
(20, 0, 0, '', 'AC', '', '0000-00-00', '0000-00-00', '', '', '0000-00-00', 0, NULL),
(21, 0, 0, '', 'AC', '', '0000-00-00', '0000-00-00', '', '', '0000-00-00', 0, NULL),
(22, 0, 0, '', 'AC', '', '0000-00-00', '0000-00-00', '', '', '0000-00-00', 0, NULL),
(23, 0, 0, '', 'AC', '', '0000-00-00', '0000-00-00', '', '', '0000-00-00', 0, NULL),
(24, 0, 0, '', 'AC', '', '0000-00-00', '0000-00-00', '', '', '0000-00-00', 0, NULL),
(25, 0, 0, '', 'AC', '', '0000-00-00', '0000-00-00', '', '', '0000-00-00', 0, NULL),
(26, 0, 0, '', 'AC', '', '0000-00-00', '0000-00-00', '', '', '0000-00-00', 0, NULL),
(27, 0, 0, '', 'AC', '', '0000-00-00', '0000-00-00', '', '', '0000-00-00', 0, NULL),
(28, 0, 0, '', 'AC', '', '0000-00-00', '0000-00-00', '', '', '0000-00-00', 0, NULL),
(29, 0, 0, '', 'AC', '', '0000-00-00', '0000-00-00', '', '', '0000-00-00', 0, NULL),
(30, 0, 0, '', 'AC', '', '0000-00-00', '0000-00-00', '', '', '0000-00-00', 0, NULL),
(31, 0, 0, '', 'AC', '', '0000-00-00', '0000-00-00', '', '', '0000-00-00', 0, NULL),
(32, 0, 0, '', 'AC', '', '0000-00-00', '0000-00-00', '', '', '0000-00-00', 0, NULL),
(33, 0, 0, '', 'AC', '', '0000-00-00', '0000-00-00', '', '', '0000-00-00', 0, NULL),
(34, 0, 0, '', 'AC', '', '0000-00-00', '0000-00-00', '', '', '0000-00-00', 0, NULL),
(35, 0, 0, '', 'AC', '', '0000-00-00', '0000-00-00', '', '', '0000-00-00', 0, NULL),
(36, 0, 0, '', 'AC', '', '0000-00-00', '0000-00-00', '', '', '0000-00-00', 0, NULL),
(37, 0, 0, '', 'AC', '', '0000-00-00', '0000-00-00', '', '', '0000-00-00', 0, NULL),
(38, 0, 0, '', 'AC', '', '0000-00-00', '0000-00-00', '', '', '0000-00-00', 0, NULL),
(39, 0, 0, '', 'AC', '', '0000-00-00', '0000-00-00', '', '', '0000-00-00', 0, NULL),
(40, 0, 0, '', 'AC', '', '0000-00-00', '0000-00-00', '', '', '0000-00-00', 0, NULL),
(41, 0, 0, '', 'AC', '', '0000-00-00', '0000-00-00', '', '', '0000-00-00', 0, NULL),
(42, 0, 0, '', 'AC', '', '0000-00-00', '0000-00-00', '', '', '0000-00-00', 0, NULL),
(43, 0, 0, '', 'AC', '', '0000-00-00', '0000-00-00', '', '', '0000-00-00', 0, NULL),
(44, 0, 0, '', 'AC', '', '0000-00-00', '0000-00-00', '', '', '0000-00-00', 0, NULL),
(45, 0, 0, '', 'AC', '', '0000-00-00', '0000-00-00', '', '', '0000-00-00', 0, NULL),
(46, 0, 0, '', 'AC', '', '0000-00-00', '0000-00-00', '', '', '0000-00-00', 0, NULL),
(47, 0, 0, '', 'AC', '', '0000-00-00', '0000-00-00', '', '', '0000-00-00', 0, NULL),
(48, 0, 0, '', 'AC', '', '0000-00-00', '0000-00-00', '', '', '0000-00-00', 0, NULL),
(49, 0, 0, '', 'AC', '', '0000-00-00', '0000-00-00', '', '', '0000-00-00', 0, NULL),
(50, 0, 0, '', 'AC', '', '0000-00-00', '0000-00-00', '', '', '0000-00-00', 0, NULL),
(51, 0, 0, '', 'AC', '', '0000-00-00', '0000-00-00', '', '', '0000-00-00', 0, NULL),
(52, 25, 43, '<p>Se le Asign&oacute; los Tribunales correspondientes al proyecto:Desarrollo aplicaciones mobiles del estudiante:EST. PEPITO PEREZ GARNICA para que usted realize las funciones como tribunal al proyecto ya mencionado esperamos su pronta respuesta</p>', 'AC', 'NV', '2015-11-01', '2015-11-01', '', 'VB', '2015-11-01', 0, 'AC'),
(53, 47, 43, '<p>Se le Asign&oacute; los Tribunales correspondientes al proyecto:Desarrollo aplicaciones mobiles del estudiante:EST. PEPITO PEREZ GARNICA para que usted realize las funciones como tribunal al proyecto ya mencionado esperamos su pronta respuesta</p>', 'AC', 'NV', '2015-11-01', '2015-11-01', '', 'VB', '2015-11-01', 0, 'AC'),
(54, 3, 43, '<p>Se le Asign&oacute; los Tribunales correspondientes al proyecto:Desarrollo aplicaciones mobiles del estudiante:EST. PEPITO PEREZ GARNICA para que usted realize las funciones como tribunal al proyecto ya mencionado esperamos su pronta respuesta</p>', 'AC', 'NV', '2015-11-01', '2015-11-01', '', 'VB', '2015-11-01', 0, 'AC'),
(55, 0, 0, '', 'AC', '', '0000-00-00', '0000-00-00', '', '', '0000-00-00', 0, NULL),
(56, 0, 0, '', 'AC', '', '0000-00-00', '0000-00-00', '', '', '0000-00-00', 0, NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tutor`
--

DROP TABLE IF EXISTS `tutor`;
CREATE TABLE IF NOT EXISTS `tutor` (
`id` int(11) NOT NULL,
  `usuario_id` int(11) NOT NULL,
  `tutor` varchar(5) NOT NULL DEFAULT 'DO',
  `estado` varchar(2) DEFAULT NULL COMMENT 'Activo sera AC, No activo NC, Eliminado DE'
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `tutor`
--

INSERT INTO `tutor` (`id`, `usuario_id`, `tutor`, `estado`) VALUES
(1, 95, '', 'AC'),
(2, 74, '', 'AC'),
(3, 73, '', 'AC'),
(4, 72, '', 'AC'),
(5, 71, '', 'AC');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuario`
--

DROP TABLE IF EXISTS `usuario`;
CREATE TABLE IF NOT EXISTS `usuario` (
`id` int(11) NOT NULL,
  `nombre` varchar(100) DEFAULT NULL,
  `titulo_honorifico` varchar(100) DEFAULT NULL,
  `apellido_paterno` varchar(45) DEFAULT NULL,
  `apellido_materno` varchar(100) DEFAULT NULL,
  `telefono` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `fecha_nacimiento` date DEFAULT NULL,
  `login` varchar(45) DEFAULT NULL,
  `clave` varchar(45) DEFAULT NULL COMMENT 'La clave del usuario minimo 5 digitos',
  `ci` varchar(45) DEFAULT NULL,
  `sexo` varchar(1) DEFAULT NULL COMMENT 'Masculino (M) femenino (F)',
  `puede_ser_tutor` tinyint(1) DEFAULT '0' COMMENT '1 si puede, 0 si no puede',
  `tribunal` varchar(5) NOT NULL DEFAULT 'DO',
  `estado` varchar(2) DEFAULT NULL COMMENT 'Activo sera AC, No activo NC, Eliminado DE'
) ENGINE=InnoDB AUTO_INCREMENT=101 DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `usuario`
--

INSERT INTO `usuario` (`id`, `nombre`, `titulo_honorifico`, `apellido_paterno`, `apellido_materno`, `telefono`, `email`, `fecha_nacimiento`, `login`, `clave`, `ci`, `sexo`, `puede_ser_tutor`, `tribunal`, `estado`) VALUES
(1, 'Administrador', NULL, 'Super', ' ', NULL, 'superadmin@sapti.com', '1989-01-17', 'admin', '4297f44b13955235245b2497399d7a93', '123123', 'M', 0, 'DO', 'AC'),
(2, 'Lucio', 'Dr.', 'Gonzales', 'Cartagena', '', '', '2013-11-06', '500001', 'cf874aad79e14b401a4c86954a596fa5', '500001', '', 1, 'DO', 'AC'),
(3, 'Jose Richard', 'Ing.', 'Ayoroa', 'Cardozo', '', '', '2013-11-06', '500002', 'e8647dce263d505d7b0d605a5d6c2d1b', '500002', '', 1, 'DO', 'AC'),
(4, 'Vladimir', 'Msc.', 'Costas', 'Jáuregui', '', '', '2013-11-06', '500003', '28102e526765b0ac82736c2c205b94ab', '500003', '', 1, 'DO', 'AC'),
(5, 'Yony Richard', 'Lic.', 'Montoya', 'Burgos', '', '', '2013-11-06', '500004', 'ad702a3ec1e6317dfdc06ececcc03d2e', '500004', '', 1, 'DO', 'AC'),
(6, 'Jimmy', 'Ing.', 'Villarroel', 'Novillo', '', '', '2013-11-06', '500005', '0392818b32472a09b84f2b13908c1243', '500005', '', 1, 'DO', 'AC'),
(7, 'Henrry Frank', 'Lic.', 'Villarroel', 'Tapia', '', '', '2013-11-06', '500006', '576226389b62628b5a757e044e3c6a24', '500006', '', 1, 'DO', 'AC'),
(8, 'Samuel Roberto', 'Ing.', 'Achá', 'Perez', '', '', '2013-11-06', '500007', '705e5b6b317d091229d9699f2d616df2', '500007', '', 1, 'DO', 'AC'),
(9, 'Luis Roberto', 'Ing.', 'Agreda', 'Corrales', '', '', '2013-11-06', '500008', '49cc492aec9039819fc2b7a1a138a9fb', '500008', '', 1, 'DO', 'AC'),
(10, 'Nancy Tatiana', 'Msc.', 'Aparicio', 'Yuja', '', '', '2013-11-06', '500009', '17065b3b2fe15f5c974a4065b18e030c', '500009', '', 1, 'DO', 'AC'),
(11, 'Ligia Jacqueline', 'Lic.', 'Aranibar', 'La Fuente', '', '', '2013-11-06', '500010', '67478479ad1213a3e9341881175ee3b6', '500010', '', 1, 'DO', 'AC'),
(12, 'Pablo Ramon', 'Lic.', 'Azero', 'Alcocer', '', '', '2013-11-06', '500011', '26621877e74d60fabed43cea37a77651', '500011', '', 1, 'DO', 'AC'),
(13, 'Maria Leticia', 'Lic.', 'Blanco', 'Coca', '', '', '2013-11-06', '500012', '23cd9e0ce513fa08ed79fc876db1d25d', '500012', '', 1, 'DO', 'AC'),
(14, 'Boris Marcelo', 'Lic.', 'Calancha', 'Navia', '', '', '2013-11-06', '500013', '674186b8c66a85578d54f339a58ca3cf', '500013', '', 1, 'DO', 'AC'),
(15, 'Indira Elva', 'Msc.', 'Camacho', 'del Castillo', '', '', '2013-11-06', '500014', '7df5523bb26e62f32b12cf0cebe3297d', '500014', '', 1, 'DO', 'AC'),
(16, 'Alvaro Hernando', 'Lic.', 'Carrasco', 'Calvo', '', '', '2013-11-06', '500015', '771e8cf06fa57452133bbb588d63bb9e', '500015', '', 1, 'DO', 'AC'),
(17, 'Raul', 'Lic.', 'Catari', 'Rios', '', '', '2013-11-06', '500016', '0693aaee5f362b197b367da78759603c', '500016', '', 1, 'DO', 'AC'),
(18, 'Francisco', 'Lic.', 'Choque', 'Uño', '', '', '2013-11-06', '500017', '29827ae18c4badba450e393e6a8675f4', '500017', '', 1, 'DO', 'AC'),
(19, 'Carlos J. Alfredo', 'Ing.', 'Cosio', 'Papadopolis', '', '', '2013-11-06', '500018', '50ffcd261f2347a7dabcb04d0ebc64d4', '500018', '', 1, 'DO', 'AC'),
(20, 'Grover', 'Lic.', 'Cussi', 'Nicolas', '', '', '2013-11-06', '500019', '2e82c593988864af55a34586892be0c1', '500019', '', 1, 'DO', 'AC'),
(21, 'Jorge', 'Lic.', 'Davalos', 'Brozovic', '', '', '2013-11-06', '500020', '9032629378f478b12aedd374816aa2f5', '500020', '', 1, 'DO', 'AC'),
(22, 'David', 'Lic.', 'Escalera', 'Fernandez', '', '', '2013-11-06', '500021', 'f0c89cc1c12dbfe8b1b664799f1939ba', '500021', '', 1, 'DO', 'AC'),
(23, 'Ivan Felix', 'Lic.', 'Fernandez', 'Daza', '', '', '2013-11-06', '500022', '1a025f481ea3486278e9e00c31e440ec', '500022', '', 1, 'DO', 'AC'),
(24, 'Juan A.', 'Lic.', 'Fernandez', 'León', '', '', '2013-11-06', '500023', '36783e63ea087c714c376b843863e3bf', '500023', '', 1, 'DO', 'AC'),
(25, 'Hernán', 'Ing.', 'Flores', 'Garcia', '', '', '2013-11-06', '500024', '64c9eec187276475779434ec212147eb', '500024', '', 1, 'DO', 'AC'),
(26, 'Juan Marcelo', 'Lic.', 'Flores', 'Soliz', '', '', '2013-11-06', '500025', 'df85c0fe203c709bedbbfa875f9872a1', '500025', '', 1, 'DO', 'AC'),
(27, 'Corina Justina', 'Lic.', 'Flores', 'Villarroel', '', '', '2013-11-06', '500026', '8ea3dcef4b706f90e6b072fb61975ff2', '500026', '', 1, 'DO', 'AC'),
(28, 'Carmen Rosa', 'Lic.', 'Garcia', 'Perez', '', '', '2013-11-06', '500027', 'c62c81ba67d18263e3df253f7116301d', '500027', '', 1, 'DO', 'AC'),
(29, 'Maria Estela', 'Lic.', 'Grilo', 'Salvatierra', '', '', '2013-11-06', '500028', '5581a688d7e32bf068a3ffca8abd9a53', '500028', '', 1, 'DO', 'AC'),
(30, 'Victor', 'Lic.', 'Gutierrez', 'Martinez', '', '', '2013-11-06', '500029', 'fc80ac211ab3f2a5c8bb8129f3c7e787', '500029', '', 1, 'DO', 'AC'),
(31, 'Julio', 'Ing.', 'Guzman', 'Guillen', '', '', '2013-11-06', '500030', 'ad832a453cb045763f292c8b948a0d45', '500030', '', 1, 'DO', 'AC'),
(32, 'Johnny', 'Ing.', 'Herrera', 'Acebey', '', '', '2013-11-06', '500031', '188daa0fd26341c027ac2aa145ebb27b', '500031', '', 1, 'DO', 'AC'),
(33, 'Mauricio', 'Lic.', 'Hoepfner', 'Reynolds', '', '', '2013-11-06', '500032', 'abcecdce9217174305e0a8d09eb60cd2', '500032', '', 1, 'DO', 'AC'),
(34, 'Roberto', 'Lic.', 'Hoepfner', 'Reynolds', '', '', '2013-11-06', '500033', '84436c8fcd4cac0f946e2a93efec582d', '500033', '', 1, 'DO', 'AC'),
(36, 'Mabel Gloria', 'Ing.', 'Magariños', 'Villarroel', '', '', '2013-11-06', '500035', 'b6d33401a011601f46ab6f27e4d087b1', '500035', '', 1, 'DO', 'AC'),
(37, 'Roberto Juan', 'Ing.', 'Manchego', 'Castellon', '', '', '2013-11-06', '500036', '214612692a9e4726553793e53cf07c11', '500036', '', 1, 'DO', 'AC'),
(38, 'Alfredo Eduardo', 'Lic.', 'Mansilla', 'Heredia', '', '', '2013-11-06', '500037', '4a95cd61e8f6d727ed7f26cffd89d7a1', '500037', '', 1, 'DO', 'AC'),
(39, 'Carlos Benito', 'Lic.', 'Manzur', 'Soria', '', '', '2013-11-06', '500038', '1380e60ba456d324a5b94de52c5745b5', '500038', '', 1, 'DO', 'AC'),
(40, 'Julio', 'Ing.', 'Medina', 'Gamboa', '', '', '2013-11-06', '500039', '8732024faf8dcd58203db2e5b112b65c', '500039', '', 1, 'DO', 'AC'),
(41, 'Victor R.', 'Lic.', 'Mejia', 'Urquieta', '', '', '2013-11-06', '500040', 'e87e82b69ad6b0098934fa7efe15841d', '500040', '', 1, 'DO', 'AC'),
(42, 'Luis', 'Lic.', 'Mercado', 'Jose', '', '', '2013-11-06', '500041', 'ec186794cea718ebf4268987fc2e38b2', '500041', '', 1, 'DO', 'AC'),
(43, 'Luis', 'Lic.', 'Molina', '', '', '', '2013-11-06', '500042', '8e7de6b5ca29bc52bf3b2ae4bc837cb3', '500042', '', 1, 'DO', 'AC'),
(44, 'Victor Hugo', 'Lic.', 'Montaño', 'Quiroga', '', '', '2013-11-06', '500043', 'a376a94c07d80271ea2432406ef108ac', '500043', '', 1, 'DO', 'AC'),
(45, 'Jose O.', 'Lic.', 'Moscoso', 'Aguirre', '', '', '2013-11-06', '500044', '7d3a53aa5daeaefe0ade737476addf68', '500044', '', 1, 'DO', 'AC'),
(46, 'Jose Gil', 'Ing.', 'Omonte', 'Ojalvo', '', '', '2013-11-06', '500045', '7fc0e70ce7ea08f59a6fdc8f79b4132c', '500045', '', 1, 'DO', 'AC'),
(47, 'Jose Roberto', 'Ing.', 'Omonte', 'Ojalvo', '', '', '2013-11-06', '500046', '04385e63c3d1188f8afae807fe272fa8', '500046', '', 1, 'DO', 'AC'),
(48, 'Richard', 'Lic.', 'Orellana', 'Arce', '', '', '2013-11-06', '500047', '38f62084079169b0bab767b3187dea85', '500047', '', 1, 'DO', 'AC'),
(49, 'Santiago', 'Lic.', 'Relos', 'Paco', '', '', '2013-11-06', '500048', '8bea0bc50dffecf371d506a9ea6a6acf', '500048', '', 1, 'DO', 'AC'),
(50, 'Juan Carlos', 'Lic.', 'Rodriguez', 'Ostria', '', '', '2013-11-06', '500049', 'fea016ed7cd8a0b4b853ce2a608f507d', '500049', '', 1, 'DO', 'AC'),
(51, 'Ramiro', 'Ing.', 'Rojas', 'Zurita', '', '', '2013-11-06', '500050', '0bdb8665502a21fe455e8dd0eb7938e7', '500050', '', 1, 'DO', 'AC'),
(52, 'Raúl', 'Ing.', 'Romero', 'Encinas', '', '', '2013-11-06', '500051', 'df7e8793a1ebe1d32d702aa671a0063e', '500051', '', 1, 'DO', 'AC'),
(53, 'Monica', 'Lic.', 'Ruiz', 'Romero', '', '', '2013-11-06', '500052', 'd3e84e77c4f0e2ac31232d655b1274a6', '500052', '', 1, 'DO', 'AC'),
(54, 'Ivan', 'Lic.', 'Ruiz', 'Ucumari', '', '', '2013-11-06', '500053', '9da96ab4ee696e9dd48e6968f8b0fcda', '500053', '', 1, 'DO', 'AC'),
(55, 'Rose Mary', 'Lic.', 'Salazar', 'Anaya', '', '', '2013-11-06', '500054', '7302cbac1d555346d928fcd9ea36ca46', '500054', '', 1, 'DO', 'AC'),
(56, 'Lenny', 'Lic.', 'Sanabria', 'Castellon', '', '', '2013-11-06', '500055', 'd266e2cc91cf57ac369da006359d72fc', '500055', '', 1, 'DO', 'AC'),
(57, 'Roxana', 'Lic.', 'Silva', 'Murillo', '', '', '2013-11-06', '500056', '4187de2f4b5bf81a22d9a0bc42a13566', '500056', '', 1, 'DO', 'AC'),
(58, 'Jose Antonio', 'Lic.', 'Soruco', 'Maita', '', '', '2013-11-06', '500057', '439eb3bfc67a575722a21e8cb59e8e59', '500057', '', 1, 'DO', 'AC'),
(59, 'Fidel', 'Lic.', 'Taborga', 'Acha', '', '', '2013-11-06', '500058', '16f40b1573de1074d7b6386baa901d59', '500058', '', 1, 'DO', 'AC'),
(60, 'Rosemary', 'Lic.', 'Torrico', 'Bascopé', '', '', '2013-11-06', '500059', '8121c1e96d7f7bf8f16e37b412503967', '500059', '', 1, 'DO', 'AC'),
(61, 'Hernan', 'Lic.', 'Ustariz', 'Vargas', '', '', '2013-11-06', '500060', '8556e533196e87a46234dc1e31d93ec7', '500060', '', 1, 'DO', 'AC'),
(62, 'Roberto', 'Ing.', 'Valenzuela', 'Miranda', '', '', '2013-11-06', '500061', '9d584b528748685a1b970636b90a7a13', '500061', '', 1, 'DO', 'AC'),
(63, 'Aidée', 'Lic.', 'Vargas', 'Colque', '', '', '2013-11-06', '500062', '9fcfa5c686bad4a6a8d269da14867084', '500062', '', 1, 'DO', 'AC'),
(64, 'Armando', 'Ing.', 'Villarroel', 'Gil', '', '', '2013-11-06', '500063', '1df741bf679f3a676e01cd818db80f78', '500063', '', 1, 'DO', 'AC'),
(65, 'Carla', 'Msc. Lic.', 'Salazar', 'Serrudo', '', '', '2013-11-06', '500064', '5206e7458baa975b27240ebfddff58cc', '500064', '', 1, 'DO', 'AC'),
(66, 'Patricia Elizabeth', 'Msc. Lic.', 'Romero', 'Rodríguez', '', '', '2013-11-06', '500065', 'dc42553512a01e1430cb6511f641cff8', '500065', '', 1, 'DO', 'AC'),
(67, 'Erika Patricia', 'Msc. Lic.', 'Rodriguez', 'Bilbao', '', '', '2013-11-06', '500066', 'c93fb01eed9e8fcdf794bca1dc97834b', '500066', '', 1, 'DO', 'AC'),
(68, 'Omar David', 'Msc. Ing.', 'Perez', 'Fuentes', '', '', '2013-11-06', '500067', 'f8be956148a06e392edfa1f9ce099839', '500067', '', 1, 'DO', 'AC'),
(69, 'Ruperto', 'Msc. Ing.', 'León', 'Romero', '', '', '2013-11-06', '500068', 'c033c0af10fa68a3bf86f08ed07c18a5', '500068', '', 1, 'DO', 'AC'),
(70, 'Tito Anibal', 'Msc. Ing.', 'Lima', 'Vacaflor', '', '', '2013-11-06', '500069', '9625034206fa11ce89370f91815762ca', '500069', '', 1, 'DO', 'AC'),
(71, 'Walter', 'Msc. Ing.', 'Cosio', 'Cabrera', '', '', '2013-11-06', '500070', 'b46dfe85cb5413c81c1393d20367dec9', '500070', '', 1, 'DO', 'AC'),
(72, 'Americo', 'Msc. Ing.', 'Fiorilo', 'Lozada', '', '', '2013-11-06', '500071', '67d34a57f06ef7b37073cea3978fcbc4', '500071', '', 1, 'DO', 'AC'),
(73, 'K. Rolando', 'Msc. Lic.', 'Jaldin', 'Rosales', '', '', '2013-11-06', '500072', '2ed79074eeb495954ee9493c17a557ff', '500072', '', 1, 'DO', 'AC'),
(74, 'Jorge Walter', 'Msc. Ing.', 'Orellana', 'Araoz', '', '', '2013-11-06', '500073', '820de24114daf321c7f7742c3083a912', '500073', '', 1, 'DO', 'AC'),
(75, 'Ismael Noel', 'Est.', 'Flores', 'Gutiérrez', '', 'isfloresguti@hotmail.com', '2013-11-06', '20008101', '8c20d10a3368bb8f6ad749c3a72eaef7', '20008101', 'M', 0, 'DO', 'AC'),
(76, 'Richard', 'Est.', 'Flores', 'Vallejos', '4721820 - 79389720', 'frichardv@hotmail.com', '2013-11-06', '20008102', '51603fe35f402dea6bd327b443fd225c', '20008102', 'M', 0, 'DO', 'AC'),
(77, 'Carolay Giancarla', 'Est.', 'Montaño', 'López', '4567896', 'lopez@gmail.com', '2013-11-06', '20008103', 'eb9e7a5ba66582d2e21f70e5b5b46d39', '20008103', 'M', 0, 'DO', 'AC'),
(78, 'Baddy', 'Est.', 'Quisbert', 'Villarroel', '4789654', 'baddyq@gmail.com', '2013-11-06', '20008104', '62e0ffd8d4cb2ef0a491e95f1ec3b2a0', '20008104', 'M', 0, 'DO', 'AC'),
(79, 'Rimberth', 'Est.', 'Villca', 'Maiza', '73838529-73798616', 'rimber_tuki@hotmail.com', '2013-11-06', '20008105', '1fa0af8115d963a8451ddef88dd9bb23', '20008105', 'M', 0, 'DO', 'AC'),
(80, 'Mauricio Henry', 'Est.', 'Barrientos', 'Rojas', '78965412', 'alan@gmail.com', '2013-11-02', '20008106', 'c89bc5f68325431b5d202e154cec69ab', '20008106', 'M', 0, 'DO', 'AC'),
(81, 'Guyen', 'Est.', 'Umaña', 'Campero', '', 'guyencu@gmail.com', '2013-11-06', '20008107', '68cd551ac9ccdbf1ed4a3e561f616500', '20008107', 'M', 0, 'DO', 'AC'),
(82, 'Lioned Yuri', 'Est.', 'Roca', 'Roca', '', 'lyroca@gmail.com', '2013-11-06', '20008108', 'e12c4de7bb6cc3a5c6692f4b5b957c8c', '20008108', 'M', 0, 'DO', 'AC'),
(83, 'Angélica', 'Est.', 'Caballero', 'Delgadillo', '456123', 'sis_jian@yahoo.es', '2013-11-06', '20008109', '112ba1716fecd51376e4ee77050c7b11', '20008109', 'F', 0, 'DO', 'AC'),
(84, 'Eliana', 'Est.', 'Bazoalto', 'Lopez', '', 'eliamia@gmail.com', '2013-11-06', '20008110', '1904afeccb4f19f467328ec09fbac2f6', '20008110', 'F', 0, 'DO', 'AC'),
(85, 'Urvy Dianet', 'Est.', 'Calle', 'Marca', '78965412', 'dianetcita@hotmail.com', '2013-11-06', '20008111', 'afa5fdf422d03cc547d02ee49a628509', '20008111', 'F', 0, 'DO', 'AC'),
(86, 'Lionel', 'Est.', 'Ayaviri', 'Sejas', '4654654', 'layosis@gmail.com', '2013-11-06', '20008112', '9cae899bfc61981c5980fe6e83e41103', '20008112', 'M', 0, 'DO', 'AC'),
(87, 'Griselda Annel', 'Est.', 'Paca', 'Meneses', '4563214', 'griss.anel@gmail.com', '2013-11-06', '20008114', 'fae85a5314c31f690a8235acb0f167e9', '20008114', 'F', 0, 'DO', 'AC'),
(88, 'Angela Eliana', 'Est.', 'Borda', 'Davila', '', 'a.naile@hotmail.es', '2013-11-06', '20008115', '112b92f981125374c84ef58ce6d693b3', '20008115', 'F', 0, 'DO', 'AC'),
(89, 'Carlos Andrés', 'Est.', 'Burgos', 'Urey', '456987123', 'carlitos_cbu@hotmail.com', '2013-11-06', '20008116', '8e7b5267c68514d672ccfc6e02ca09d8', '20008116', 'M', 0, 'DO', 'AC'),
(90, 'Shirley Jhovana', 'Est.', '', 'Pinto', '', 'jhoshi_1820@hotmail.com', '2013-11-06', '20008117', '9ddb39fd97d675dcb9237d7ee558306e', '20008117', 'F', 0, 'DO', 'AC'),
(91, 'Gary Richard', 'Est.', 'Vera', 'Terrazas', '4567834', 'garyver@hotmail.com', '2013-11-06', '20008118', '14fb16488f3352546748adb71228e40f', '20008118', 'M', 0, 'DO', 'AC'),
(92, 'Segundino Gastón', 'Est.', 'Fernandez', 'Flores', '46554654', 'gasfer_fl_sis@hotmail.com', '2013-11-06', '20008119', '9b33b9a30405de6c3c505bc81b6231da', '20008119', 'M', 0, 'DO', 'AC'),
(93, 'Marcelo Marcos', 'Est.', 'Vargas', 'Chavez', '478965231', 'mashelo.vargas@gmail.com', '2013-11-06', '20008120', '66d8dd3fcad7b075bd3a1d7c08289e4f', '20008120', 'M', 0, 'DO', 'AC'),
(94, 'Alberto', 'Est.', 'Buddy', 'Coal', '', 'tarubazu@hotmail.com', '2015-09-10', '200015', '8093b105ed38c24ac4d2601a3b54b4f7', '6545454', 'M', 0, '', 'AC'),
(95, 'Carlos', 'Ph.D.', 'Medina', 'Medina', '', 'tarubazu@hotmail.com', '2015-10-21', '2000125', '5acac25072add1cbd32e62c4af90cd95', '525465', 'M', 1, '', 'AC'),
(96, 'Pepito', 'Est.', 'Perez', 'Garnica', '4444', 'guyencu@gmail.com', '1989-10-19', 'salavi', '1a859467ee4cbdae6d659d99a4428403', '6545454', 'M', 0, '', 'AC'),
(97, 'Richiard', 'Est.', 'Poul', 'Poul', '', 'guyencu-buyer@gmail.com', '1994-10-12', '200017', 'c038ee4b6f2b4465b1b18a606184b61a', '200017', 'M', 0, '', 'AC'),
(98, 'Luis', 'Est.', 'Cardozo', 'Cardozo', '', 'um.mary@gmail.com', '1986-10-16', '200018', '56f8d3a3f6ead8b63617186c0a1123c5', '200018', 'M', 0, '', 'AC'),
(100, 'Avance', 'Est.', 'Acance', 'Acence', '', 'guyencu@gmail.com', '1989-10-19', '200020', '26d0beedea4450d8ef9e8f4799badaff', '200020', 'M', 0, '', 'AC');

--
-- Disparadores `usuario`
--
DROP TRIGGER IF EXISTS `biuserdelete`;
DELIMITER //
CREATE TRIGGER `biuserdelete` AFTER DELETE ON `usuario`
 FOR EACH ROW INSERT INTO bitacora(host, operacion, modificado, tabla, tupla_antes, tupla_despues) 
VALUES (SUBSTRING(USER(), (INSTR(USER(),"@")+1)),"ELIMINAR", NOW(), "USUARIO",CONCAT(OlD.ID,' ', OlD.nombre,' ',OlD.apellido_paterno,' ',OlD.apellido_materno,' ',OlD.telefono, ' ', OlD.email,' ',OlD.fecha_nacimiento,' ',OlD.login),' ')
//
DELIMITER ;
DROP TRIGGER IF EXISTS `biusernew`;
DELIMITER //
CREATE TRIGGER `biusernew` AFTER INSERT ON `usuario`
 FOR EACH ROW INSERT INTO bitacora(host, operacion, modificado, tabla, tupla_antes, tupla_despues) 
VALUES (SUBSTRING(USER(), (INSTR(USER(),"@")+1)),"INSERTAR", NOW(), "USUARIO","",CONCAT(NEW.ID,' ', NEW.nombre,' ',NEW.apellido_paterno,' ',NEW.apellido_materno,' ',NEW.telefono, ' ', NEW.email,' ',NEW.fecha_nacimiento,' ',NEW.login))
//
DELIMITER ;
DROP TRIGGER IF EXISTS `biuserupdate`;
DELIMITER //
CREATE TRIGGER `biuserupdate` AFTER UPDATE ON `usuario`
 FOR EACH ROW INSERT INTO bitacora(host, operacion, modificado, tabla, tupla_antes, tupla_despues) 
VALUES (SUBSTRING(USER(), (INSTR(USER(),"@")+1)),"MODIFICAR", NOW(), "USUARIO",CONCAT(OlD.ID,' ', OlD.nombre,' ',OlD.apellido_paterno,' ',OlD.apellido_materno,' ',OlD.telefono, ' ', OlD.email,' ',OlD.fecha_nacimiento,' ',OlD.login),CONCAT(NEW.ID,' ', NEW.nombre,' ',NEW.apellido_paterno,' ',NEW.apellido_materno,' ',NEW.telefono, ' ', NEW.email,' ',NEW.fecha_nacimiento,' ',NEW.login))
//
DELIMITER ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `vigencia`
--

DROP TABLE IF EXISTS `vigencia`;
CREATE TABLE IF NOT EXISTS `vigencia` (
`id` int(11) NOT NULL,
  `proyecto_id` int(11) NOT NULL,
  `fecha_inicio` date DEFAULT NULL,
  `fecha_fin` date DEFAULT NULL,
  `fecha_actualizado` date DEFAULT NULL,
  `estado_vigencia` varchar(45) DEFAULT NULL COMMENT 'Normal 4 semestres (NO), Prorroga 6 meses  (PR), Postergado 1 nio   (PO)',
  `estado` varchar(2) DEFAULT NULL COMMENT 'Activo sera AC, No activo NC, Eliminado DE'
) ENGINE=InnoDB AUTO_INCREMENT=47 DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `vigencia`
--

INSERT INTO `vigencia` (`id`, `proyecto_id`, `fecha_inicio`, `fecha_fin`, `fecha_actualizado`, `estado_vigencia`, `estado`) VALUES
(1, 1, '2013-11-06', '2015-11-06', '0000-00-00', 'NO', 'AC'),
(2, 2, '2013-11-06', '2015-11-06', '0000-00-00', 'NO', 'AC'),
(3, 3, '2013-11-06', '2015-11-06', '0000-00-00', 'NO', 'AC'),
(4, 4, '2013-11-06', '2015-11-06', '0000-00-00', 'NO', 'AC'),
(5, 5, '2013-11-06', '2015-11-06', '0000-00-00', 'NO', 'AC'),
(6, 6, '2013-11-06', '2015-11-06', '0000-00-00', 'NO', 'AC'),
(7, 7, '2013-11-06', '2015-11-06', '0000-00-00', 'NO', 'AC'),
(8, 8, '2013-11-06', '2015-11-06', '0000-00-00', 'NO', 'AC'),
(9, 9, '2013-11-06', '2015-11-06', '0000-00-00', 'NO', 'AC'),
(10, 10, '2013-11-06', '2015-11-06', '0000-00-00', 'NO', 'AC'),
(11, 11, '2013-11-06', '2015-11-06', '0000-00-00', 'NO', 'AC'),
(12, 12, '2013-11-06', '2015-11-06', '0000-00-00', 'NO', 'AC'),
(13, 13, '2013-11-06', '2015-11-06', '0000-00-00', 'NO', 'AC'),
(14, 14, '2013-11-06', '2015-11-06', '0000-00-00', 'NO', 'AC'),
(15, 15, '2013-11-06', '2015-11-06', '0000-00-00', 'NO', 'AC'),
(16, 16, '2013-11-06', '2015-11-06', '0000-00-00', 'NO', 'AC'),
(17, 17, '2013-11-06', '2015-11-06', '0000-00-00', 'NO', 'AC'),
(18, 18, '2013-11-06', '2015-11-06', '0000-00-00', 'NO', 'AC'),
(19, 19, '2013-11-06', '2015-11-06', '0000-00-00', 'NO', 'AC'),
(20, 20, '2013-11-06', '2015-11-06', '0000-00-00', 'NO', 'AC'),
(21, 21, '2013-11-06', '2015-11-06', '0000-00-00', 'NO', 'AC'),
(22, 22, '2013-11-06', '2015-11-06', '0000-00-00', 'NO', 'AC'),
(23, 23, '2013-11-06', '2015-11-06', '0000-00-00', 'NO', 'AC'),
(24, 24, '2013-11-06', '2015-11-06', '0000-00-00', 'NO', 'AC'),
(25, 25, '2013-11-06', '2015-11-06', '0000-00-00', 'NO', 'AC'),
(26, 26, '2013-11-06', '2015-11-06', '0000-00-00', 'NO', 'AC'),
(27, 27, '2013-11-06', '2007-11-23', '0000-00-00', 'NO', 'AC'),
(28, 28, '2013-11-06', '2015-11-06', '0000-00-00', 'NO', 'AC'),
(29, 29, '2013-11-06', '2015-11-06', '0000-00-00', 'NO', 'AC'),
(30, 30, '2013-11-06', '2015-11-06', '0000-00-00', 'NO', 'AC'),
(31, 31, '2013-11-06', '2015-11-06', '0000-00-00', 'NO', 'AC'),
(32, 32, '2013-11-06', '2015-11-06', '0000-00-00', 'NO', 'AC'),
(33, 33, '2013-11-06', '2015-11-06', '0000-00-00', 'NO', 'AC'),
(34, 34, '2013-11-06', '2015-11-06', '0000-00-00', 'NO', 'AC'),
(35, 35, '2013-11-06', '2016-05-06', '0000-00-00', 'PR', 'AC'),
(36, 36, '2013-11-06', '2016-05-06', '0000-00-00', 'PR', 'AC'),
(37, 37, '2013-11-06', '2016-11-06', '0000-00-00', 'PO', 'AC'),
(38, 38, '2013-11-06', '2016-11-06', '0000-00-00', 'PO', 'AC'),
(39, 39, '2013-11-06', '2015-11-06', '0000-00-00', 'NO', 'AC'),
(40, 40, '2013-11-06', '2016-11-16', '0000-00-00', 'NO', 'AC'),
(41, 41, '2013-11-06', '2015-11-06', '0000-00-00', 'NO', 'AC'),
(42, 42, '2013-11-06', '2015-11-06', '0000-00-00', 'NO', 'AC'),
(43, 43, '2013-11-08', '2015-11-08', '0000-00-00', 'NO', 'AC'),
(44, 44, '2013-11-08', '2015-11-08', '0000-00-00', 'NO', 'AC'),
(45, 40, '2015-10-11', '2017-10-11', '0000-00-00', 'NO', 'AC'),
(46, 43, '2015-10-11', '2017-10-11', '0000-00-00', 'NO', 'AC');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `visto_bueno`
--

DROP TABLE IF EXISTS `visto_bueno`;
CREATE TABLE IF NOT EXISTS `visto_bueno` (
`id` int(11) NOT NULL,
  `proyecto_id` int(11) NOT NULL,
  `fecha_visto_bueno` date DEFAULT NULL,
  `visto_bueno_tipo` varchar(2) DEFAULT NULL COMMENT 'docente (DO), tutor (TU), tribunal (TR)',
  `visto_bueno_id` varchar(45) DEFAULT NULL COMMENT 'id del docente, tutor o tribunal ',
  `estado` varchar(2) DEFAULT NULL COMMENT 'Activo sera AC, No activo NC, Eliminado DE'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `visto_bueno_docente`
--

DROP TABLE IF EXISTS `visto_bueno_docente`;
CREATE TABLE IF NOT EXISTS `visto_bueno_docente` (
`id` int(11) NOT NULL,
  `proyecto_id` int(11) DEFAULT NULL,
  `docente_id` int(11) DEFAULT NULL,
  `visto_bueno` varchar(45) DEFAULT NULL,
  `tipo_proyecto` varchar(10) DEFAULT NULL,
  `fecha` date DEFAULT NULL,
  `descripcion` varchar(100) DEFAULT NULL,
  `estado` varchar(10) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `visto_bueno_docente`
--

INSERT INTO `visto_bueno_docente` (`id`, `proyecto_id`, `docente_id`, `visto_bueno`, `tipo_proyecto`, `fecha`, `descripcion`, `estado`) VALUES
(1, 40, 7, 'DO', 'PE', '0000-00-00', '', 'AC'),
(2, 43, 11, 'DO', 'PR', '0000-00-00', '', 'AC'),
(3, 44, 7, 'DO', 'PE', '0000-00-00', '', 'AC');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `visto_bueno_tutor`
--

DROP TABLE IF EXISTS `visto_bueno_tutor`;
CREATE TABLE IF NOT EXISTS `visto_bueno_tutor` (
`id` int(11) NOT NULL,
  `tutor_id` int(11) DEFAULT NULL,
  `proyecto_id` int(11) DEFAULT NULL,
  `visto_bueno` varchar(45) DEFAULT NULL,
  `tipo_proyecto` varchar(45) DEFAULT NULL,
  `fecha` varchar(45) DEFAULT NULL,
  `descripcion` varchar(100) DEFAULT NULL,
  `estado` varchar(10) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `visto_bueno_tutor`
--

INSERT INTO `visto_bueno_tutor` (`id`, `tutor_id`, `proyecto_id`, `visto_bueno`, `tipo_proyecto`, `fecha`, `descripcion`, `estado`) VALUES
(1, 2, 39, 'AC', '', '10/10/2015', '', 'AC'),
(2, 2, 40, 'AC', '', '11/10/2015', '', 'AC'),
(3, 3, 40, 'AC', '', '11/10/2015', '', 'AC'),
(4, 4, 40, 'AC', '', '11/10/2015', '', 'AC'),
(5, 5, 40, 'AC', '', '11/10/2015', '', 'AC'),
(6, 2, 43, 'AC', 'PR', '01/11/2015', '', 'AC'),
(7, 3, 43, 'AC', 'PR', '01/11/2015', '', 'AC'),
(8, 4, 43, 'AC', 'PR', '01/11/2015', '', 'AC'),
(9, 5, 43, 'AC', 'PR', '01/11/2015', '', 'AC'),
(10, 2, 44, 'AC', '', '21/10/2015', '', 'AC'),
(11, 3, 44, 'AC', '', '21/10/2015', '', 'AC');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `administrador`
--
ALTER TABLE `administrador`
 ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `apoyo`
--
ALTER TABLE `apoyo`
 ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `area`
--
ALTER TABLE `area`
 ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `automatico`
--
ALTER TABLE `automatico`
 ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `avance`
--
ALTER TABLE `avance`
 ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `avance_objetivo_especifico`
--
ALTER TABLE `avance_objetivo_especifico`
 ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `bitacora`
--
ALTER TABLE `bitacora`
 ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `cambio`
--
ALTER TABLE `cambio`
 ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `carrera`
--
ALTER TABLE `carrera`
 ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `carta`
--
ALTER TABLE `carta`
 ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `codigo_grupo`
--
ALTER TABLE `codigo_grupo`
 ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `configuracion_semestral`
--
ALTER TABLE `configuracion_semestral`
 ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `consejo`
--
ALTER TABLE `consejo`
 ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `consejo_estudiante`
--
ALTER TABLE `consejo_estudiante`
 ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `cronograma`
--
ALTER TABLE `cronograma`
 ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `defensa`
--
ALTER TABLE `defensa`
 ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `departamento`
--
ALTER TABLE `departamento`
 ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `dia`
--
ALTER TABLE `dia`
 ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `dicta`
--
ALTER TABLE `dicta`
 ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `docente`
--
ALTER TABLE `docente`
 ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `estudiante`
--
ALTER TABLE `estudiante`
 ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `evaluacion`
--
ALTER TABLE `evaluacion`
 ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `evento`
--
ALTER TABLE `evento`
 ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `fecha_registro`
--
ALTER TABLE `fecha_registro`
 ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `fororespuesta`
--
ALTER TABLE `fororespuesta`
 ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `forotema`
--
ALTER TABLE `forotema`
 ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `grupo`
--
ALTER TABLE `grupo`
 ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `helpdesk`
--
ALTER TABLE `helpdesk`
 ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `hora`
--
ALTER TABLE `hora`
 ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `horario_docente`
--
ALTER TABLE `horario_docente`
 ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `inscrito`
--
ALTER TABLE `inscrito`
 ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `institucion`
--
ALTER TABLE `institucion`
 ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `lugar`
--
ALTER TABLE `lugar`
 ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `materia`
--
ALTER TABLE `materia`
 ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `modalidad`
--
ALTER TABLE `modalidad`
 ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `modelo_carta`
--
ALTER TABLE `modelo_carta`
 ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `modulo`
--
ALTER TABLE `modulo`
 ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `nota`
--
ALTER TABLE `nota`
 ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `nota_tribunal`
--
ALTER TABLE `nota_tribunal`
 ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `notificacion`
--
ALTER TABLE `notificacion`
 ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `notificacion_consejo`
--
ALTER TABLE `notificacion_consejo`
 ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `notificacion_dicta`
--
ALTER TABLE `notificacion_dicta`
 ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `notificacion_estudiante`
--
ALTER TABLE `notificacion_estudiante`
 ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `notificacion_revisor`
--
ALTER TABLE `notificacion_revisor`
 ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `notificacion_tribunal`
--
ALTER TABLE `notificacion_tribunal`
 ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `notificacion_tutor`
--
ALTER TABLE `notificacion_tutor`
 ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `objetivo_especifico`
--
ALTER TABLE `objetivo_especifico`
 ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `observacion`
--
ALTER TABLE `observacion`
 ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `permiso`
--
ALTER TABLE `permiso`
 ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `pertenece`
--
ALTER TABLE `pertenece`
 ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `proyecto`
--
ALTER TABLE `proyecto`
 ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `proyecto_area`
--
ALTER TABLE `proyecto_area`
 ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `proyecto_dicta`
--
ALTER TABLE `proyecto_dicta`
 ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `proyecto_estudiante`
--
ALTER TABLE `proyecto_estudiante`
 ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `proyecto_revisor`
--
ALTER TABLE `proyecto_revisor`
 ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `proyecto_sub_area`
--
ALTER TABLE `proyecto_sub_area`
 ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `proyecto_tutor`
--
ALTER TABLE `proyecto_tutor`
 ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `respaldo`
--
ALTER TABLE `respaldo`
 ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `revision`
--
ALTER TABLE `revision`
 ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `revisor`
--
ALTER TABLE `revisor`
 ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `semestre`
--
ALTER TABLE `semestre`
 ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `sub_area`
--
ALTER TABLE `sub_area`
 ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `titulo_honorifico`
--
ALTER TABLE `titulo_honorifico`
 ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `tooltip`
--
ALTER TABLE `tooltip`
 ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `tribunal`
--
ALTER TABLE `tribunal`
 ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `tutor`
--
ALTER TABLE `tutor`
 ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `usuario`
--
ALTER TABLE `usuario`
 ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `vigencia`
--
ALTER TABLE `vigencia`
 ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `visto_bueno`
--
ALTER TABLE `visto_bueno`
 ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `visto_bueno_docente`
--
ALTER TABLE `visto_bueno_docente`
 ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `visto_bueno_tutor`
--
ALTER TABLE `visto_bueno_tutor`
 ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `administrador`
--
ALTER TABLE `administrador`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT de la tabla `apoyo`
--
ALTER TABLE `apoyo`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `area`
--
ALTER TABLE `area`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT de la tabla `automatico`
--
ALTER TABLE `automatico`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=1017;
--
-- AUTO_INCREMENT de la tabla `avance`
--
ALTER TABLE `avance`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT de la tabla `avance_objetivo_especifico`
--
ALTER TABLE `avance_objetivo_especifico`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT de la tabla `bitacora`
--
ALTER TABLE `bitacora`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=31;
--
-- AUTO_INCREMENT de la tabla `cambio`
--
ALTER TABLE `cambio`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT de la tabla `carrera`
--
ALTER TABLE `carrera`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT de la tabla `carta`
--
ALTER TABLE `carta`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT de la tabla `codigo_grupo`
--
ALTER TABLE `codigo_grupo`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT de la tabla `configuracion_semestral`
--
ALTER TABLE `configuracion_semestral`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=29;
--
-- AUTO_INCREMENT de la tabla `consejo`
--
ALTER TABLE `consejo`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `consejo_estudiante`
--
ALTER TABLE `consejo_estudiante`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `cronograma`
--
ALTER TABLE `cronograma`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `defensa`
--
ALTER TABLE `defensa`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT de la tabla `departamento`
--
ALTER TABLE `departamento`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `dia`
--
ALTER TABLE `dia`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT de la tabla `dicta`
--
ALTER TABLE `dicta`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT de la tabla `docente`
--
ALTER TABLE `docente`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=74;
--
-- AUTO_INCREMENT de la tabla `estudiante`
--
ALTER TABLE `estudiante`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=25;
--
-- AUTO_INCREMENT de la tabla `evaluacion`
--
ALTER TABLE `evaluacion`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=29;
--
-- AUTO_INCREMENT de la tabla `evento`
--
ALTER TABLE `evento`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `fecha_registro`
--
ALTER TABLE `fecha_registro`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT de la tabla `fororespuesta`
--
ALTER TABLE `fororespuesta`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `forotema`
--
ALTER TABLE `forotema`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `grupo`
--
ALTER TABLE `grupo`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT de la tabla `helpdesk`
--
ALTER TABLE `helpdesk`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=252;
--
-- AUTO_INCREMENT de la tabla `hora`
--
ALTER TABLE `hora`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=41;
--
-- AUTO_INCREMENT de la tabla `horario_docente`
--
ALTER TABLE `horario_docente`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `inscrito`
--
ALTER TABLE `inscrito`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=29;
--
-- AUTO_INCREMENT de la tabla `institucion`
--
ALTER TABLE `institucion`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT de la tabla `lugar`
--
ALTER TABLE `lugar`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT de la tabla `materia`
--
ALTER TABLE `materia`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT de la tabla `modalidad`
--
ALTER TABLE `modalidad`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT de la tabla `modelo_carta`
--
ALTER TABLE `modelo_carta`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT de la tabla `modulo`
--
ALTER TABLE `modulo`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=20;
--
-- AUTO_INCREMENT de la tabla `nota`
--
ALTER TABLE `nota`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `nota_tribunal`
--
ALTER TABLE `nota_tribunal`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `notificacion`
--
ALTER TABLE `notificacion`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=64;
--
-- AUTO_INCREMENT de la tabla `notificacion_consejo`
--
ALTER TABLE `notificacion_consejo`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `notificacion_dicta`
--
ALTER TABLE `notificacion_dicta`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=18;
--
-- AUTO_INCREMENT de la tabla `notificacion_estudiante`
--
ALTER TABLE `notificacion_estudiante`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=53;
--
-- AUTO_INCREMENT de la tabla `notificacion_revisor`
--
ALTER TABLE `notificacion_revisor`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `notificacion_tribunal`
--
ALTER TABLE `notificacion_tribunal`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT de la tabla `notificacion_tutor`
--
ALTER TABLE `notificacion_tutor`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=73;
--
-- AUTO_INCREMENT de la tabla `objetivo_especifico`
--
ALTER TABLE `objetivo_especifico`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=17;
--
-- AUTO_INCREMENT de la tabla `observacion`
--
ALTER TABLE `observacion`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT de la tabla `permiso`
--
ALTER TABLE `permiso`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=134;
--
-- AUTO_INCREMENT de la tabla `pertenece`
--
ALTER TABLE `pertenece`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=103;
--
-- AUTO_INCREMENT de la tabla `proyecto`
--
ALTER TABLE `proyecto`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=45;
--
-- AUTO_INCREMENT de la tabla `proyecto_area`
--
ALTER TABLE `proyecto_area`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT de la tabla `proyecto_dicta`
--
ALTER TABLE `proyecto_dicta`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=29;
--
-- AUTO_INCREMENT de la tabla `proyecto_estudiante`
--
ALTER TABLE `proyecto_estudiante`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=45;
--
-- AUTO_INCREMENT de la tabla `proyecto_revisor`
--
ALTER TABLE `proyecto_revisor`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `proyecto_sub_area`
--
ALTER TABLE `proyecto_sub_area`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT de la tabla `proyecto_tutor`
--
ALTER TABLE `proyecto_tutor`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT de la tabla `respaldo`
--
ALTER TABLE `respaldo`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT de la tabla `revision`
--
ALTER TABLE `revision`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT de la tabla `revisor`
--
ALTER TABLE `revisor`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `semestre`
--
ALTER TABLE `semestre`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT de la tabla `sub_area`
--
ALTER TABLE `sub_area`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT de la tabla `titulo_honorifico`
--
ALTER TABLE `titulo_honorifico`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT de la tabla `tooltip`
--
ALTER TABLE `tooltip`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=526;
--
-- AUTO_INCREMENT de la tabla `tribunal`
--
ALTER TABLE `tribunal`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=57;
--
-- AUTO_INCREMENT de la tabla `tutor`
--
ALTER TABLE `tutor`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT de la tabla `usuario`
--
ALTER TABLE `usuario`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=101;
--
-- AUTO_INCREMENT de la tabla `vigencia`
--
ALTER TABLE `vigencia`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=47;
--
-- AUTO_INCREMENT de la tabla `visto_bueno`
--
ALTER TABLE `visto_bueno`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `visto_bueno_docente`
--
ALTER TABLE `visto_bueno_docente`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT de la tabla `visto_bueno_tutor`
--
ALTER TABLE `visto_bueno_tutor`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=12;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
